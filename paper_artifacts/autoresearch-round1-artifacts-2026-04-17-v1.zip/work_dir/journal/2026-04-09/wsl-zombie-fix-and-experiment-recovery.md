# WSL 僵尸进程泄漏修复与 adaptive-ct-1 第二次恢复

> 日期：2026-04-09
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查 / 功能实现
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与恢复](#5-验证与恢复)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

### 第二次中断

`adaptive-ct-1` 在 179–182 迭代期间再次因系统资源耗尽而中断（Windows 被迫重启）。上次中断（2026-04-08，25/200 迭代）的根因就是 **80+ 僵尸 wsl.exe 进程累积导致 WSL2 Hyper-V VM 通信死锁**，当时仅做了应急恢复但未修复根因。

这次重启前 `round_state.json` 记录 179 迭代，实际 `results.tsv` 已写到 182 行（最后 session 完成了 3 次迭代但来不及更新 state）。距离 200 迭代目标仅剩 18 次。

### 必须先修根因

两次中断的根因相同——WSL 进程泄漏。在恢复实验前，必须先修复 `run_experiment.py` 和 `cursor_acp.py` 中的进程管理缺陷，否则下一轮 9 小时以上的长时间运行必然再次崩溃。

---

## 2. 分析过程

### 2.1 泄漏源头

逐一审查代码后，识别出两条泄漏路径：

**路径 A — `run_experiment.py` 的 `wsl_cmd()`**

```python
def wsl_cmd(cmd):
    r = subprocess.run(
        ["wsl", "-d", "Ubuntu-24.04", "--", "bash", "-c", full],
        capture_output=True, text=True, encoding="utf-8",
    )  # ← 无 timeout！WSL 挂死时永久阻塞
```

每次调用创建一个 `wsl.exe` 进程。每个 session 循环调用 4 次（`get_iter_count`、`get_best_bpb`、`backup_results`、`setup_branch`）。无超时保护——WSL 稍有延迟就会阻塞，阻塞的 `wsl.exe` 成为僵尸。

**路径 B — `cursor_acp.py` 的 MCP shell server（主要泄漏源）**

```python
r = subprocess.run(
    cmd, shell=True, capture_output=True, text=True,
    timeout=timeout, cwd=self.cwd,
)  # shell=True → cmd.exe → wsl.exe（孙子进程）
```

Agent 每个 session 通过 MCP 发 10–50 条 WSL 命令。`shell=True` 意味着进程链是 `Python → cmd.exe → wsl.exe`。当 session 结束或超时时：

- Python 的 `subprocess.run` 超时后只杀直接子进程 cmd.exe
- **wsl.exe 作为孙子进程存活下来，变成孤儿**
- MCP handler 运行在 daemon 线程中，线程被回收但 wsl.exe 进程不受影响

### 2.2 累积效应

9 小时运行 ≈ 数十个 session ≈ 数百次 WSL 命令调用。即使只有 10% 的命令因超时或 session 中断未正常退出，也足以积累 80+ 僵尸进程，最终耗尽 WslService 的通信管道导致整个 WSL 子系统死锁。

### 2.3 缺失的防线

| 缺陷 | 影响 |
|------|------|
| `wsl_cmd()` 无超时 | WSL 延迟时阻塞整个 runner |
| MCP 命令用 `shell=True` + `subprocess.run` | 只杀 cmd.exe 不杀 wsl.exe 孙子进程 |
| Session 间无进程清理 | 僵尸进程跨 session 累积 |
| 无 WSL 健康检查 | WSL 已半死不活时仍然继续发 session |
| `atexit` 不清理 WSL 进程 | 异常退出后遗留全部僵尸 |

---

## 3. 方案设计

### 关键决策

| 决策 | 选择 | 理由 |
|------|------|------|
| 清理时机 | 每个 session 结束后立即清理 | session 结束后无合法 wsl.exe 在运行，`taskkill /F /IM wsl.exe` 安全 |
| 健康检查时机 | 每个 session 开始前 | 避免向已死的 WSL 发 session，浪费 Agent 上下文 |
| 健康检查升级策略 | 清理 → 重试 3 次 → `wsl --shutdown` → 放弃 | 渐进式恢复，最大努力自愈 |
| MCP 进程管理 | `Popen` + `CREATE_NEW_PROCESS_GROUP` + `taskkill /T` 树杀 | 从源头阻止孤儿 wsl.exe |
| `wsl_cmd()` 超时 | 60 秒 | 大部分 WSL 命令 <5s，60s 足够覆盖慢操作（git checkout 大仓库） |

---

## 4. 实现要点

### 4.1 `run_experiment.py` 修改

**`wsl_cmd()` 添加超时和异常处理：**

```python
WSL_CMD_TIMEOUT = 60

def wsl_cmd(cmd, timeout=WSL_CMD_TIMEOUT):
    try:
        r = subprocess.run(
            ["wsl", "-d", WSL_DISTRO, "--", "bash", "-c", full],
            capture_output=True, text=True, encoding="utf-8",
            timeout=timeout,
        )
        return r.stdout.strip()
    except subprocess.TimeoutExpired:
        _print(f"[wsl] timeout ({timeout}s): {cmd[:80]}")
        return ""
```

**Session 间 WSL 进程清理：**

```python
def _cleanup_wsl_processes():
    count = _count_wsl_processes()
    if count <= 0:
        return
    _print(f"[cleanup] Killing {count} orphaned wsl.exe process(es)...")
    subprocess.run(["taskkill", "/F", "/IM", "wsl.exe"],
                   capture_output=True, timeout=15)
    time.sleep(2)
```

**Session 前 WSL 健康检查：**

```python
def _wsl_health_check(max_retries=3):
    for attempt in range(1, max_retries + 1):
        r = subprocess.run(
            ["wsl", "-d", WSL_DISTRO, "--", "echo", "ok"],
            capture_output=True, text=True, timeout=30,
        )
        if r.stdout.strip() == "ok":
            return True
        _cleanup_wsl_processes()
        time.sleep(5)
    # 最后手段：wsl --shutdown 后重试
    subprocess.run(["wsl", "--shutdown"], timeout=30)
    time.sleep(10)
    ...
```

**集成到 session 循环：**

```python
for attempt in range(1, MAX_RETRIES + 1):
    if not _wsl_health_check():        # ← 新增：session 前健康检查
        _print("[error] WSL unhealthy, cannot continue.")
        break

    # ... Agent session ...
    stop_reason = cursor_acp.run_prompt(...)

    _cleanup_wsl_processes()            # ← 新增：session 后清理

    new_count = get_iter_count()        # 此时 wsl.exe 全部清理过，新调用干净
    ...
```

**atexit 清理扩展：**

```python
def _atexit_cleanup():
    cursor_acp.cleanup()
    _cleanup_wsl_processes()            # ← 新增
```

### 4.2 `cursor_acp.py` 修改

**新增 `_kill_proc_tree()` 工具函数：**

```python
def _kill_proc_tree(pid):
    """Kill a process and all its children (Windows: taskkill /T)."""
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                       capture_output=True, timeout=10)
    else:
        os.kill(pid, 9)
```

**MCP shell handler 改用 `Popen` + 进程组 + 树杀：**

```python
flags = subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0
proc = subprocess.Popen(
    cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    text=True, encoding="utf-8", errors="replace",
    cwd=self.cwd, creationflags=flags,
)
try:
    stdout, stderr = proc.communicate(timeout=timeout)
except subprocess.TimeoutExpired:
    _kill_proc_tree(proc.pid)   # ← 杀整棵进程树，不只杀 cmd.exe
    proc.wait(timeout=5)
    ...
```

`CREATE_NEW_PROCESS_GROUP` 让 cmd.exe 及其子进程（wsl.exe）归入同一进程组，`taskkill /T` 递归终止整棵树，从源头阻止孤儿 wsl.exe 产生。

### 4.3 防护层次总结

| 层次 | 机制 | 作用 |
|------|------|------|
| **源头** | MCP 进程组 + 树杀 | 阻止 wsl.exe 孤儿产生 |
| **定期清理** | session 间 `taskkill /F /IM wsl.exe` | 清除漏网之鱼 |
| **超时保护** | `wsl_cmd()` 60s timeout | 防止 runner 主线程阻塞 |
| **健康检查** | session 前 echo 测试 + 自动恢复 | 检测 WSL 退化并自愈 |
| **兜底** | atexit 清理 + `wsl --shutdown` 升级 | 退出时清理 / 死锁时重启 VM |

---

## 5. 验证与恢复

### 5.1 代码验证

```
$ python -c "import py_compile; py_compile.compile('run_experiment.py', doraise=True); \
  py_compile.compile('cursor_acp.py', doraise=True); print('Both files compile OK')"
Both files compile OK
```

### 5.2 WSL 状态验证

重启后 WSL 正常响应（~2.7s）。

| 检查项 | 结果 |
|--------|------|
| Git 分支 | `autoresearch/adaptive-ct-1` ✓ |
| Git HEAD | `7a6b776`（未测试 commit）→ reset 到 `81c9e0f`（最佳 BPB 1.094849）✓ |
| results.tsv | 182 有效数据行 ✓ |
| round_state.json | 179 → 更新为 182 ✓ |
| Backup | results.tsv 比 backup 多 3 行 → 同步 ✓ |
| GPU | RTX 5090 D，VRAM 空闲 ✓ |

### 5.3 Git HEAD 修复

```bash
$ git reset --hard 81c9e0f
HEAD is now at 81c9e0f BREAK: FINAL_LR_FRAC 0.031 to 0.0315 (warmdown floor)
```

`7a6b776` 是第 180 迭代的修改（Muon momentum ramp step/480→500），训练未完成，run.log 无结果。安全回退到最佳 commit。

### 5.4 实验恢复

```
$ python run_experiment.py round1
[state] Resumed from round_state.json
[skip] baseline-1 already completed (200 iters)
[skip] static-ct-1 already completed (203 iters)

  Experiment: adaptive-ct-1 | Max iterations: 200
  Started: 2026-04-09 13:21:24

--- Session 1 | Iterations: 182/200 | 13:21:25 ---
[agent] Sending prompt to Cursor Agent...
[cursor_acp] handshake ok
```

Agent 已连接，从第 183 迭代继续。

---

## 6. 后续演化

### 已解决

- WSL 僵尸进程泄漏：从 MCP 源头（进程树 kill）和 runner 层面（session 间清理 + 健康检查 + 超时）双层防护
- 两次中断的数据均完整恢复，无迭代丢失

### 待观察

- **新防护是否有效**：adaptive-ct-1 剩余 18 迭代（~3 小时）是首次验证窗口。如果 `[cleanup]` 日志出现，说明确实在清理泄漏进程
- **后续 6 个 run**（baseline-2 到 adaptive-ct-3）每个 200 迭代，总计 ~60 小时连续运行，是对防护的终极考验

### 可进一步改进

- MCP handler 目前仍用 `shell=True`（经由 cmd.exe），改为直接用 `["wsl", "-d", ...]` 列表形式可完全消除 cmd.exe 中间层
- 考虑加一个 WSL 进程计数的指标日志（每 session 记录清理了多少僵尸），方便事后分析泄漏速率
- `_wsl_health_check` 的 `wsl --shutdown` 兜底目前是同步阻塞的，如果 shutdown 本身也挂死（上次就遇到了），需要有 timeout + 提升权限杀 wslservice 的升级路径

---

<!--
关键时间线：
- 2026-04-09 ~05:00  发现 adaptive-ct-1 再次因系统重启中断（182/200 迭代）
- 2026-04-09 ~05:05  分析根因：与上次相同的 WSL 僵尸进程泄漏
- 2026-04-09 ~05:10  设计修复方案：4 层防护（源头 kill + 定期清理 + 超时 + 健康检查）
- 2026-04-09 ~05:15  实施修改：run_experiment.py（5 处改动）+ cursor_acp.py（2 处改动）
- 2026-04-09 ~05:18  WSL 验证正常 + 数据完整性确认
- 2026-04-09 ~05:19  Git HEAD reset 到最佳 commit 81c9e0f
- 2026-04-09 ~05:20  round_state.json 更新 179→182
- 2026-04-09 ~05:21  实验恢复运行（182/200 迭代）
-->
