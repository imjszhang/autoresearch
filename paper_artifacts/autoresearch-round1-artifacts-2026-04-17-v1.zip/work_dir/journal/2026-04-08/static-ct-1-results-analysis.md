# static-ct-1 实验结果分析（203 迭代完成，与 baseline-1 对比）

> 日期：2026-04-08
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：调研分析
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [总体统计](#2-总体统计)
3. [BPB 改进轨迹](#3-bpb-改进轨迹)
4. [与 baseline-1 对比](#4-与-baseline-1-对比)
5. [发现的问题](#5-发现的问题)
6. [关键观察与结论](#6-关键观察与结论)
7. [后续演化](#7-后续演化)

---

## 1. 背景与动机

static-ct-1 是 Round 1 的第二个 run，使用 **static cyber-taoist** 策略——Agent 按照固定规则集计算 delta 值，根据 delta 区间选择 BREAK（大胆探索）或 SIMPLIFY（代码精简）策略。run 已完成 203 迭代（略超 `--max-iter 200`，为 session 收尾边界效应）。

需要分析 static-ct 策略对 Agent 探索行为的影响，并与无策略指导的 baseline-1 做对照。

数据来源：`experiment_data/results_static-ct-1.tsv`（203 行），从备份读取，不影响正在运行的 adaptive-ct-1。

---

## 2. 总体统计

| 指标 | 值 |
|------|------|
| 总迭代 | 203 |
| keep | 24（11.8%） |
| discard | 155（76.4%） |
| crash | 24（11.8%） |
| 起始 BPB | 1.224576（baseline） |
| 最终最佳 BPB | **1.070910**（commit `bc556a4`） |
| 总改进幅度 | -12.5% |

### 策略分布

| 策略 | 次数 | 占比 |
|------|------|------|
| BREAK | 178 | 87.7% |
| SIMPLIFY | 23 | 11.3% |
| BASELINE | 1 | 0.5% |
| GUARD | 1 | 0.5% |

### Delta 分布

| 区间 | 含义 | 次数 | 占比 |
|------|------|------|------|
| 0 – 0.3 | 低 stagnation | 2 | 1.0% |
| 0.3 – 0.7 | SIMPLIFY 区 | 23 | 11.3% |
| 0.7 – 1.0 | BREAK 区 | 89 | 43.8% |
| = 1.0 | 极端 stagnation | 89 | 43.8% |

**delta = 1.0 占 43.8%**——接近一半的迭代中，Agent 处于最大 stagnation 状态（近 10 次全部 discard/crash），被迫执行最激进的 BREAK。

### BPB 分布（不含 crash）

| 区间 | 数量 | 比例 |
|------|------|------|
| < 1.075 | 50 | 27.9% |
| 1.075 – 1.10 | 25 | 14.0% |
| 1.10 – 1.15 | 75 | 41.9% |
| 1.15 – 1.20 | 14 | 7.8% |
| > 1.20 | 15 | 8.4% |

---

## 3. BPB 改进轨迹

24 次 keep 中有 17 次是真正的 BPB 新高（NEW BEST），7 次是局部改进或工具性 keep：

### 阶段 1：快速突破（#1 – #60，迭代 1–60）

| 迭代 | BPB | 策略 | 描述 |
|------|-----|------|------|
| #1 | 1.224576 | BASELINE | 起点 |
| #9 | 1.103346 | BREAK | torch.compile |
| #19 | 1.088809 | BREAK | perf_counter 计时修复 |
| #28 | 1.084609 | BREAK | ASPECT_RATIO 48 + step dt 上限 |
| #29 | 1.078858 | BREAK | TOTAL_BATCH_SIZE 2^18 |
| #32 | 1.078727 | BREAK | logits softcap 15→12 |
| #33 | 1.077716 | BREAK | WEIGHT_DECAY 0.16 |
| #40 | 1.077005 | BREAK | warmdown 0.55 + final_lr_frac 0.06 |
| #42 | 1.076415 | BREAK | WEIGHT_DECAY 0.14 |
| #47 | 1.073874 | BREAK | RoPE base 50k |
| #52 | 1.073743 | BREAK | RoPE 100k |
| #53 | 1.073533 | BREAK | RoPE 200k |
| #54 | 1.072668 | BREAK | RoPE 400k |
| #60 | 1.072206 | BREAK | RoPE 450k |

**60 迭代从 1.225 降到 1.072**，改进 12.5%，高度高效。RoPE base 连续提升（50k→100k→200k→400k→450k）是核心驱动力。

### 阶段 2：深度停滞（#61 – #114，迭代 61–114）

54 次迭代**零真正改进**。delta 全部 >= 1.0。Agent 在各种方向上穷举（WINDOW_PATTERN 排列、Muon 参数、HEAD_DIM、DEPTH），全部 discard。

值得注意的是：这段期间出现了一个"次优局部最优"现象——#115–#120 的 keep 序列 BPB 在 1.105–1.107 范围，远差于阶段 1 的最佳 1.072，原因可能是 Agent 在某次 crash 后 reset 到了错误的 checkpoint（`dc58996` 而非全局最佳 `da8eba6`）。

### 阶段 3：SDPA 突破与收尾（#155 – #203）

| 迭代 | BPB | 策略 | 描述 |
|------|-----|------|------|
| #155 | 1.072368 | BREAK | 非 Hopper SDPA：恢复 PyTorch 默认 SDP 选择 |
| #156 | 1.072325 | SIMPLIFY | import 合并 + FA3 注释清理 |
| #164 | 1.072094 | BREAK | RoPE 446k→445k |
| #177 | 1.071344 | BREAK | RMSNorm Q/K 在 RoPE 之前 |
| #178 | **1.070910** | BREAK | EMBEDDING_LR 0.6→0.625 |

#155 的 SDPA 修改是关键——移除了对非 Hopper GPU 强制关闭 flash SDP 的限制，让 PyTorch 自动选择最优 kernel，直接带来更高吞吐量和更多训练步数。此后的 RoPE 微调和 QK RMSNorm 顺序调整进一步推低 BPB。

最终 **25 次尾部迭代无改进**（#179–#203），远好于 baseline-1 的 118 次。

---

## 4. 与 baseline-1 对比

### 核心指标

| 指标 | baseline-1 | static-ct-1 | 差异 |
|------|-----------|-------------|------|
| 总迭代 | 200 | 203 | — |
| keep | 8（4.0%） | 24（11.8%） | **3x keep 率** |
| crash | 8（4.0%） | 24（11.8%） | 3x crash 率 |
| 起始 BPB | 1.263888 | 1.224576 | 不同 baseline |
| 最终最佳 BPB | 1.084914 | **1.070910** | **-1.3%** |
| 最后改进迭代 | #82 / 200 | #178 / 203 | — |
| 尾部浪费 | 118 迭代（59%） | 25 迭代（12%） | **显著减少** |

### BPB 里程碑达成速度

| 阈值 | baseline-1 | static-ct-1 | 赢家 |
|------|-----------|-------------|------|
| < 1.10 | 第 6 迭代 | 第 19 迭代 | baseline |
| < 1.09 | 第 78 迭代 | 第 19 迭代 | **static-ct** |
| < 1.085 | 第 82 迭代 | 第 28 迭代 | **static-ct** |
| < 1.08 | 未达到 | 第 29 迭代 | **static-ct** |
| < 1.075 | 未达到 | 第 47 迭代 | **static-ct** |

baseline-1 在前 6 步快速到 1.09 以下（因为起始 baseline 不同且直接命中了 torch.compile），但此后停滞。static-ct-1 用更少迭代达到了 baseline-1 无法企及的 BPB 水平。

### 策略分析

| 策略 | keep / 总数 | keep 率 |
|------|-----------|---------|
| BREAK | 21 / 178 | 11.8% |
| SIMPLIFY | 2 / 23 | 8.7% |

- BREAK 策略贡献了绝大多数改进，成功率约 12%。
- SIMPLIFY 策略（代码精简）仅 2 次 keep，其中 #120 和 #156 都是 import/comment 清理后获得微小改进——可能是因为更短的代码在 torch.compile 下有更快的编译时间。
- 43.8% 的迭代处于 delta=1.0（最大 stagnation），说明 **cyber-taoist 的 delta 信号有效地驱动了探索，但没有阻止 Agent 陷入长时间停滞**。

---

## 5. 发现的问题

### 问题 1：高 crash 率（11.8%，baseline-1 的 3 倍）

24 次 crash，主要原因：

| 类别 | 次数 | 典型案例 |
|------|------|---------|
| MCP/executor 超时 | 12 | RoPE base 微调训练中断 |
| CUDA OOM | 6 | DEVICE_BATCH_SIZE 64、label smoothing、clip_grad_norm |
| 编译错误 | 2 | parallel block、learnable RMSNorm |
| 进程竞争 | 4 | overlapping runs、nohup 竞态 |

MCP executor 超时是最大问题——训练时间超过 MCP shell 命令的等待窗口，导致训练中断。Agent 多次尝试用 `nohup`/`setsid` 解决但效果不稳。

**BREAK 策略的激进性加剧了 crash**：很多 BREAK 改动触发了 OOM 或架构不兼容，而 baseline-1 的无策略探索更保守、crash 更少。

### 问题 2：阶段 2 停滞期的"次优陷阱"

#61–#114（54 次迭代）期间，Agent 似乎在一个 BPB ~1.107 的次优状态中挣扎（远差于阶段 1 的 1.072）。可能是 crash 后的 reset 目标选择不当——`dc58996` 不是全局最佳 commit，导致 Agent 从一个较差的配置重新探索。

#115–#120 的 keep 序列（BPB 1.105–1.107）证实了 Agent 确实在次优分支上建立了一条新的改进路径，但这条路径远不如主干。

### 问题 3：SIMPLIFY 策略收益有限

23 次 SIMPLIFY 中只有 2 次 keep（8.7%），且改进极小：
- #120：strip banners/merge imports → BPB 改进 0.03%
- #156：merge imports/drop comment → BPB 改进 0.004%

SIMPLIFY 的设计意图是通过代码精简让 torch.compile 更高效或减少噪声，但实际上大多数 SIMPLIFY 都被 discard——说明在当前的 300 秒训练预算下，代码行数对 BPB 影响微乎其微。

### 问题 4：重复 BPB 值

18 组重复 BPB，最严重的 `1.071188` 出现 4 次（iter #187–#189）。与 baseline-1 的问题相同，可能是 `run.log` 残留值被解析。

### 问题 5：迭代数超过 max_iter

`round_state.json` 记录 `iterations: 203`，超过了 `--max-iter 200`。原因是 `get_iter_count()` 计数与 `max_iter` 比较的时机——Agent 在一个 session 内可能跑多次迭代，session 结束后才检查是否达标。这不影响数据质量，但说明 `max_iter` 是个软上限。

---

## 6. 关键观察与结论

### static-ct 策略的优势

| 方面 | 观察 |
|------|------|
| 最终 BPB | **1.071 vs 1.085**——static-ct-1 比 baseline-1 低 1.3%（绝对 -0.014） |
| 探索效率 | 47 步达到 <1.075，baseline 从未达到 |
| keep 率 | 11.8% vs 4.0%，发现更多有效改动 |
| 尾部浪费 | 12% vs 59%，Agent 更晚才耗尽改进空间 |
| 关键突破 | RoPE base 连续提升、ASPECT_RATIO 调整、SDPA kernel 修复——都是 BREAK 策略驱动的大胆探索 |

### static-ct 策略的劣势

| 方面 | 观察 |
|------|------|
| crash 率 | 11.8% vs 4.0%——激进探索的代价 |
| 停滞期 | 仍有 54 次连续失败（#61–#114） |
| SIMPLIFY 无效 | 23 次 SIMPLIFY 几乎无贡献 |
| 次优陷阱 | crash 后 reset 到错误 checkpoint 导致在次优分支浪费迭代 |

### 最终配置对比

| 参数 | baseline-1 (`87faa61`) | static-ct-1 (`bc556a4`) |
|------|----------------------|------------------------|
| val_bpb | 1.084914 | **1.070910** |
| memory_gb | 11.4 | 8.8 |
| ASPECT_RATIO | 默认（64） | 48 |
| TOTAL_BATCH_SIZE | 2^19 | 2^18 |
| RoPE base | 10000 | 445000 |
| softcap | 15 | 12 |
| WEIGHT_DECAY | 0.2 | 0.14 |
| WARMDOWN_RATIO | 0.5 | 0.54 |
| EMBEDDING_LR | 0.75 | 0.625 |
| VE gate channels | 44 | 32（默认） |
| SCALAR_LR | 0.45 | 0.5（默认） |
| QK RMSNorm | 默认（after RoPE） | **before RoPE** |
| SDPA | 默认 | **PyTorch 默认选择** |

static-ct-1 找到了一个更紧凑（8.8GB vs 11.4GB）、更高效的配置——通过降低 ASPECT_RATIO 和 BATCH_SIZE 换取更多 optimizer steps，同时大幅提高 RoPE base（445k vs 10k）和调整 attention 规范化顺序。

---

## 7. 后续演化

1. **adaptive-ct-1 对比**：第三个策略变体正在运行（5/200 迭代），预期观察 adaptive 版本是否能避免 #61–#114 的停滞期。
2. **crash 率降低**：考虑在 prompt 中加入 OOM 预检（检查参数量/显存估算），或在 `run_experiment.py` 中加 crash 后自动 reset 到全局最佳 commit 的逻辑。
3. **SIMPLIFY 策略重新评估**：当前实验证据表明 SIMPLIFY 对 BPB 贡献极小，可考虑降低其频率或改为仅在特定条件下触发。
4. **reset 目标选择**：crash/discard 后应 reset 到全局最佳 BPB 的 commit，而非最近的 keep——这可以避免次优陷阱。
5. **max_iter 软上限**：203 > 200 的问题影响不大，但如需严格控制应在 `run_prompt` 返回后立即检查并跳出。
