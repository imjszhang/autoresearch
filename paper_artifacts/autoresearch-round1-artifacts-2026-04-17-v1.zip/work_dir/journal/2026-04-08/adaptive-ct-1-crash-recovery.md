# adaptive-ct-1 实验中断诊断与安全恢复

> 日期：2026-04-08
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [现象描述](#2-现象描述)
3. [排查过程](#3-排查过程)
4. [根因分析](#4-根因分析)
5. [修复与恢复](#5-修复与恢复)
6. [恢复验证](#6-恢复验证)
7. [后续演化](#7-后续演化)

---

## 1. 背景与动机

Round 1 的第三个 run `adaptive-ct-1`（Adaptive Cyber-Taoist 策略，自演化 Guard/Break 阈值）在完成 25/200 迭代后意外中断。前两个 run 已正常完成：

| Run | 策略 | 迭代 | 状态 |
|-----|------|------|------|
| baseline-1 | 无策略 | 200 | completed |
| static-ct-1 | 固定规则 Cyber-Taoist | 203 | completed |
| **adaptive-ct-1** | **自适应 Cyber-Taoist** | **25** | **in_progress → 中断** |

需要诊断中断原因、验证数据完整性、安全恢复实验。

---

## 2. 现象描述

### 2.1 日志末尾

`adaptive-ct-1.log` 末尾（第 3699 行）：

```
Error: S: Connection stalled
```

这是 `cursor_acp.py`（ACP 协议客户端）与 Cursor Agent CLI 之间的连接断开信号。

### 2.2 中断时刻的上下文

从日志分析，中断发生在一个**新 session 刚启动**阶段：

- 前一个 session 在迭代 ~25 处结束，最后的有效工作是启动了 commit `189921c`（Muon momentum ramp）的训练，但因 MCP 超时未等到训练结果
- 新 session 启动后正在读取文件、检查 Git 状态，还没来得及执行训练就断开了
- `round_state.json` 记录 `iterations: 25`，`results.tsv` 有 25 条数据行

### 2.3 WSL 完全无响应

发现时，WSL 处于完全死锁状态：

| 操作 | 结果 |
|------|------|
| `wsl -d Ubuntu-24.04 -- whoami` | 超时（2分钟无输出） |
| `wsl --shutdown` | 挂住 |
| `wsl -t Ubuntu-24.04` | 挂住 |
| `wsl --update` | 挂住 |
| `wsl -l -v` | 正常返回（不需要 VM 通信） |
| `wsl --version` | 正常返回 |

---

## 3. 排查过程

### 3.1 进程检查 — 发现 80+ 僵尸 wsl.exe

```bash
taskkill //F //IM wsl.exe
```

输出显示 **80+ 个 wsl.exe 进程被终止**。这些是实验运行期间积累的僵尸进程——`run_experiment.py` 通过 `wsl -d Ubuntu-24.04 -- bash -c "..."` 调用 WSL 命令（`get_iter_count()`、`get_best_bpb()`、`setup_branch()` 等），每次调用创建一个 wsl.exe 进程，但部分进程未正常退出。

### 3.2 系统资源排除

确认系统资源**不是**瓶颈：

| 资源 | 状态 |
|------|------|
| 内存 | 50.1 GB 空闲 / 95.3 GB 总量 |
| 磁盘 C: | 13.5 GB 空闲 |
| 磁盘 D: | 230.7 GB 空闲 |
| GPU | RTX 5090 D，30.9 GB VRAM 空闲 |
| ext4.vhdx | 17.1 GB，今天有写入，未损坏 |

### 3.3 WSL 服务层死锁

关键发现：

- `wslservice.exe` (PID 22512) 和 `vmmemWSL` (PID 4088) 无法通过普通权限终止（Access Denied）
- `sc.exe stop WslService` 也因权限不足失败（Error 5）
- 即使用 `taskkill` 杀掉所有 wsl.exe，vmmemWSL 和 wslservice 仍会自动重生
- 新生成的 WSL 组件仍然无法建立正常通信

### 3.4 提升权限尝试

```powershell
Start-Process powershell -ArgumentList '-Command',
  'Stop-Process -Id 22512 -Force; Stop-Process -Id 4088 -Force' -Verb RunAs -Wait
```

成功终止了 wslservice 和 vmmemWSL。但重新启动 WSL 后，VM 仍无法正常引导——`wsl -d Ubuntu-24.04 -- whoami` 在干净状态下依然超时。

### 3.5 docker-desktop 交叉验证

```bash
timeout 30 wsl -d docker-desktop -- /bin/sh -c "echo ok"
```

同样超时——排除了单个发行版的问题，确认是 **WSL2 Hyper-V VM 层面的系统性死锁**。

---

## 4. 根因分析

### 直接原因

WSL2 Hyper-V 轻量 VM 的通信管道彻底断裂。wsl.exe（宿主侧代理）与 VM 内的 init 进程之间的 vsock/AF_HYPERV 通道无法建立或已损坏。

### 根本原因

`run_experiment.py` 在长时间运行中通过 `wsl -d Ubuntu-24.04 -- bash -c "..."` 模式频繁调用 WSL 命令，每次调用会：

1. 创建一个 wsl.exe 进程
2. 与 WSL VM 建立 vsock 连接
3. 在 VM 内 fork 一个 bash 进程
4. 等待命令完成并返回

当 Agent 内部的 MCP shell-executor 超时或 ACP 连接中断时，**部分 wsl.exe 进程未被正确清理**，逐渐积累。80+ 个僵尸 wsl.exe 持有的 VM 通信句柄耗尽了 WslService 的连接池或触发了内部死锁，导致整个 WSL 子系统瘫痪。

### 从用户态无法恢复的原因

- wslservice.exe 运行在 SYSTEM 权限下，普通 shell（包括 Git Bash/MINGW）缺少对应令牌
- 提升权限杀进程后，WSL 自动重启但 VM 引导过程本身需要与之前残留的状态协商，仍然无法成功
- **只有 Windows 重启才能彻底重置 Hyper-V 和 WSL 服务的所有内部状态**

---

## 5. 修复与恢复

### 5.1 Windows 重启

唯一有效的修复手段。重启后 WSL 首次命令在 3.8 秒内正常返回。

### 5.2 数据完整性验证

重启后逐项检查：

| 检查项 | 预期 | 实际 | 结果 |
|--------|------|------|------|
| Git 分支 | `autoresearch/adaptive-ct-1` | `autoresearch/adaptive-ct-1` | ✓ |
| results.tsv 行数 | 26（1 header + 25 data） | 26 | ✓ |
| round_state.json iterations | 25 | 25 | ✓ |
| results.tsv vs backup | 一致 | 一致 | ✓ |
| 最佳 BPB | 1.100677 @ `f29a92e` | 确认 | ✓ |
| run.log | 空（未完成的训练） | 空 | 符合预期 |

### 5.3 Git HEAD 修复（关键步骤）

中断时 Git HEAD 停在 `189921c`（BREAK: Muon momentum ramp），这个 commit 的训练**从未完成**，结果未记录到 results.tsv。

```bash
# Before:
# 189921c BREAK: Muon momentum ramp 300- steps to full 0.95  ← HEAD（未验证）
# f29a92e BREAK: global grad clip norm 1.0 before optimizer step  ← 最佳 BPB

git reset --hard f29a92e
# HEAD is now at f29a92e BREAK: global grad clip norm 1.0 before optimizer step
```

决策逻辑：
- `189921c` 的训练未完成（run.log 为空），无法确定其 BPB
- 即使训练曾完成，结果也已丢失
- 安全做法是回退到已知最佳 commit，不计入迭代次数
- results.tsv 保持 25 行不变，round_state.json 无需修改

### 5.4 临时文件清理

清除了 50+ 个残留的 `run_*.log`、`.pid`、`.done` 等临时文件，避免对下次 session 造成干扰。

### 5.5 恢复实验

```bash
cd d:/github/fork/autoresearch/work_dir/experiment
python run_experiment.py round1
```

`run_round1()` 从 `round_state.json` 恢复：
- 跳过 `baseline-1`（completed, 200 iters）
- 跳过 `static-ct-1`（completed, 203 iters）
- 继续 `adaptive-ct-1`（in_progress, 25/200 iters）

---

## 6. 恢复验证

启动后确认输出：

```
[state] Resumed from round_state.json
[round1] Remaining: 7 runs — adaptive-ct-1, baseline-2, ...
[skip] baseline-1 already completed (200 iters)
[skip] static-ct-1 already completed (203 iters)

  Experiment: adaptive-ct-1
  Max iterations: 200

[setup] On branch: autoresearch/adaptive-ct-1
--- Session 1 | Iterations: 25/200 | 13:17:04 ---
[agent] Sending prompt to Cursor Agent...
[cursor_acp] handshake ok
```

Agent 已连接，从第 26 迭代开始继续实验。

### adaptive-ct-1 中断时的实验状态

| 指标 | 值 |
|------|------|
| 已完成迭代 | 25 |
| keep 次数 | 6（24%） |
| crash 次数 | 5（20%） |
| 最佳 BPB | 1.100677 @ `f29a92e` |
| 当前阈值 | θ_guard=0.3, θ_break=0.7（未到第 50 迭代的 ADAPT） |
| 主要发现 | torch.compile + DEVICE_BATCH_SIZE 64 + RoPE 50k + grad clip norm |

---

## 7. 后续演化

### 7.1 WSL 僵尸进程泄漏防护

**根本问题**：`run_experiment.py` 中的 `wsl_cmd()` 函数通过 `subprocess.run()` 调用 WSL，但没有对超时和僵尸进程进行防护。当 ACP 连接中断导致 Python 进程异常退出时，子进程的 wsl.exe 可能成为僵尸。

**建议方案**：

1. 在 `wsl_cmd()` 中添加 `timeout` 参数（默认 60 秒）
2. 在 session 间隔（`run_single` 的 for 循环中）添加 WSL 进程清理：
   ```python
   subprocess.run(["taskkill", "/F", "/IM", "wsl.exe"], 
                  capture_output=True, timeout=10)
   ```
3. 在 `_atexit_cleanup()` 中也加入 WSL 进程清理
4. 考虑用 `wsl --exec` 替代 `wsl -- bash -c "..."`，减少进程开销

### 7.2 WSL 健康检查

在每个 session 开始前做一次 WSL 快速健康检查：

```python
def wsl_health_check():
    try:
        r = subprocess.run(
            ["wsl", "-d", "Ubuntu-24.04", "--", "echo", "ok"],
            capture_output=True, text=True, timeout=30
        )
        return r.stdout.strip() == "ok"
    except subprocess.TimeoutExpired:
        return False
```

如果检查失败，尝试 `wsl --shutdown` + 等待 + 重试，而不是直接进入无响应的 session。

### 7.3 实验数据安全

当前的 backup 机制（`experiment_data/results_*.tsv`）被验证有效——中断恢复时 backup 与 results.tsv 完全一致。但建议增加：

- 在 results.tsv 写入后立即同步 backup（当前是 session 结束后才 backup）
- 在 round_state.json 中记录最佳 commit hash，避免恢复时需要解析 results.tsv

---

<!--
关键时间线：
- 2026-04-08 ~03:00  adaptive-ct-1 运行到 25 迭代时 ACP 连接断开
- 2026-04-08 ~04:38  发现问题，开始诊断
- 2026-04-08 ~04:40  发现 80+ 僵尸 wsl.exe，WSL 完全死锁
- 2026-04-08 ~04:50  确认从用户态无法恢复，建议 Windows 重启
- 2026-04-08 ~05:08  Windows 重启完成
- 2026-04-08 ~05:08  WSL 验证正常（3.8s 响应）
- 2026-04-08 ~05:12  数据完整性验证通过
- 2026-04-08 ~05:14  git reset --hard f29a92e（修复 HEAD）
- 2026-04-08 ~05:17  run_experiment.py round1 恢复运行
-->
