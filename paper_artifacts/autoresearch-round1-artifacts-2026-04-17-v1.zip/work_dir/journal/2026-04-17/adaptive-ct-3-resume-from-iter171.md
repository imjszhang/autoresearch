# adaptive-ct-3 意外中断：HEAD 对齐与 171/200 断点续跑

> 日期：2026-04-17
> 项目：autoresearch（Round 1 · run 9/9 adaptive-ct-3）
> 类型：问题排查 / 升级迁移（断点续跑）
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [现象与诊断](#2-现象与诊断)
3. [根因分析](#3-根因分析)
4. [恢复方案](#4-恢复方案)
5. [执行步骤](#5-执行步骤)
6. [验证结果](#6-验证结果)
7. [后续演化](#7-后续演化)

---

## 1. 背景与动机

Round 1 的最后一个 run `adaptive-ct-3` 在 2026-04-15 首次恢复后继续推进，但再次意外停止。用户要求：不重跑已有数据，定位中断点并安全续跑到 200 iter，完成整个 Round 1。

关键约束：

- 不能重算已写入 `results.tsv` 的迭代。
- Git HEAD 必须与 `results.tsv` 最后一次 `keep` 对齐（协议：discard 后立刻 reset 回最近的 keep）。
- 若存在上次中断遗留的 `run.log` 或 PID 文件，必须清理以免干扰下一次 agent 决策。

## 2. 现象与诊断

### 进程/状态快照

| 项 | 期望 | 实际 | 结论 |
| --- | --- | --- | --- |
| runner `python.exe` | 1 个在跑 | 无（只有 ComfyUI 的 9188） | runner 已退出 |
| `wsl.exe` | 少量或无 | 0 | 无卡住的 WSL 调用 |
| `round_state.adaptive-ct-3` | in_progress + 正确 iter | `in_progress, iterations: 171` | 与 tsv 一致 |
| WSL `results.tsv` 数据行 | 171 | 171 | ✓ |
| 备份 `experiment_data/results_adaptive-ct-3.tsv` | 172 行（含 header） | 172 | ✓ |
| 分支 | `autoresearch/adaptive-ct-3` | 同 | ✓ |
| HEAD | `d9c0073`（最后 keep） | `a264260`（新的 BREAK 提交） | ✗ 不一致 |

### 日志线索（`logs/adaptive-ct-3.log` 尾部）

- 上一 keep：`d9c0073`（`VE_GATE_CHANNELS 32→48`，`val_bpb 1.066786`）。
- 其后 `eda5705` BREAK `LOGIT_SOFTCAP 10.5→10.42` → `discard`。
- 更晚 agent 新建 `a264260` BREAK `VE_GATE_CHANNELS 48→56`，训练中明确写着：

  > 训练因 MCP 请求超时被中断（约 step 70）…… 正以更长超时重跑完整训练

  但该轮未产出 `val_bpb`，也未写入 `results.tsv` 即退出。

## 3. 根因分析

这是一起「**迭代尚未写入 tsv，Git 却已提交**」的中断：

1. Agent 先做 `git commit`（候选改动 `a264260`）再启动训练；
2. 训练被 MCP/会话层超时打断，`results.tsv` 未追加；
3. 进程整体退出后，HEAD 停留在 `a264260`，而数据层仍是 171 行以 `eda5705 discard` 结尾。

按 `program.md`，discard 行后 HEAD 应指向最近的 keep（`d9c0073`），所以下一次 runner 启动时若从 `a264260` 接着跑，会误以为「当前 HEAD 就是基线」从而污染 δ 计算与后续 BREAK/SIMPLIFY 决策。

## 4. 恢复方案

| 决策 | 选择 | 理由 |
| --- | --- | --- |
| 是否重算 iter 172? | 不重算 | `results.tsv` 未追加，等同该轮从未发生，重算即可 |
| HEAD 对齐到? | `d9c0073` | 最近一次 `keep`，协议要求的基线 |
| 是否清 `run.log` | 清 | 残留会让下一轮 agent 误读旧 step 信息 |
| 历史 `run_iter*.log` | 保留 | 仅供回顾，不影响协议 |
| 是否改 `round_state.json`? | 不改 | 已与 tsv 一致（171） |
| 启动方式 | 直接 `python run_experiment.py round1` | runner 内置跳过已完成 run 与 resume 逻辑 |

## 5. 执行步骤

### 5.1 修正 WSL Git/数据层

```bash
wsl -d Ubuntu-24.04 -- bash -lc '
  cd /root/projects/autoresearch
  git reset --hard d9c0073
  rm -f run.log nohup.out
  cp results.tsv experiment_data/results_adaptive-ct-3.tsv
'
```

### 5.2 确认断点

```text
HEAD = d9c0073 BREAK VE_GATE_CHANNELS 32 to 48 for value-embedding gates
data_rows = 171
last tsv row = eda5705  1.066913  8.3  discard
round_state.adaptive-ct-3 = {status: in_progress, iterations: 171}
PAUSE_REQUEST / *.pid = 无
```

### 5.3 启动 runner

```bash
cd work_dir/experiment && python run_experiment.py round1
```

## 6. 验证结果

runner 输出（`terminals/825091.txt` 摘录）：

```text
[state] Resumed from .../round_state.json
[round1] Remaining: 1 runs - adaptive-ct-3
[skip] baseline-1 .. adaptive-ct-2 .. static-ct-3 已跳过
--- Session 1 | Iterations: 171/200 | 03:25:21 ---
[agent] Sending prompt to Cursor Agent...
[cursor_acp] MCP server on port 8796
[cursor_acp] agent pid=22328
[cursor_acp] handshake ok
[cursor_acp] session: 4b940de8-0699-47...
```

- 仅剩 `adaptive-ct-3` 未完成，其余 8 个 run 按 `round_state` 全部 skip。
- 从 `171/200` 正确断点继续，MCP/ACP 握手成功，agent 会话已建立。
- 启动后 25s 时 `wsl.exe` 数为 0、`python.exe` 仅 runner + 预留后台（ComfyUI 不计），无僵尸累积。

## 7. 后续演化

- **协议层小改进建议**：让 agent 采用「**先训练、拿到 val_bpb 再 git commit**」的顺序，可彻底消除本次这种「HEAD 领先 tsv 一步」的不一致。当前是靠恢复协议兜底。
- **runner 侧自动对齐**：启动 `run_single` 时，可以加一次「检查 HEAD 是否等于最后一行 tsv 对应的 `keep` 提交；否则自动 `git reset --hard <last_keep>`」的自检，减少人工干预。
- **Round 1 收尾**：本轮结束后汇总 9 个 run 的 BPB/VRAM/ΔC，进入 Round 2 前可决定是否继承 `d9c0073`（adaptive-ct-3 当前最佳）为共用基线。

---

<!-- 关联：
- 上一次恢复：work_dir/journal/2026-04-15/adaptive-ct-3-interruption-and-recovery.md
- Round 1 中间检查点：work_dir/journal/2026-04-10/round1-first-three-runs-checkpoint.md
- WSL 僵尸进程修复：work_dir/journal/2026-04-09/wsl-zombie-fix-and-experiment-recovery.md
-->
