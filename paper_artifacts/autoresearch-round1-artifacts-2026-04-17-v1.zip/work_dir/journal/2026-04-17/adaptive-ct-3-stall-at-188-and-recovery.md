# adaptive-ct-3 在 188/200 空转卡死：安全恢复并续跑

> 日期：2026-04-17
> 项目：autoresearch（Round 1 · run 9/9 adaptive-ct-3）
> 类型：问题排查 / 升级迁移（断点续跑）
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

同日早些时候，`adaptive-ct-3` 已从 `171/200` 的中断点恢复，并继续推进到 `188/200`。随后用户再次要求检查实验状态，发现 runner 进程虽然仍存活，但实验没有继续前进，表现为会话层反复重试、数据层完全不增长。

本次工作的目标不是重跑，而是把状态重新修正为一个**数据、Git HEAD、runner 会话三者一致**的可续跑断点，并在不污染 `results.tsv` 的前提下继续完成 Round 1 最后一个 run。

关键约束：

- 不能丢失 `188` 之前已经写入 `results.tsv` 的实验结果。
- 必须保证 WSL 仓库 HEAD 与 `results.tsv` 最后一条 `keep` 记录一致。
- 必须先结束“假活”的 runner，再重启；否则只会继续空转重试。

## 2. 分析过程

### 现象确认

| 检查项 | 实际结果 | 结论 |
| ---- | ---- | ---- |
| `round_state.json` | `adaptive-ct-3: in_progress, iterations: 188` | 断点记录在 188 |
| WSL `results.tsv` | `data_rows=188` | 数据层停在 188 |
| WSL HEAD | `be4e9c4` | 与最后一条 `keep` 一致 |
| `wsl.exe` 进程 | 0 | 没有真实训练在跑 |
| Windows runner | `python.exe 8364 = run_experiment.py round1` | runner 还活着，但是假活 |

### runner 终端中的异常特征

从后台 runner 终端与 `adaptive-ct-3.log` 可见，实验在 `188/200` 之后进入了持续空转：

- 多次出现 `RPC session/new: Internal error`
- 多次出现 `Error: S: Connection stalled`
- 多次出现 `WinError 10038`
- Session 编号持续增长，但每次都是 `+0 iterations`

这说明问题不在训练指标本身，而是在 **Cursor ACP / MCP 会话层**。具体表现为：

1. runner 还能继续拉起新 session；
2. agent 有时甚至能完成握手；
3. 但后续 socket/server 状态异常，导致会话很快结束；
4. `round_state` 和 `results.tsv` 都不会增加新行。

### 关键数据校验

为避免误修复，恢复前做了三层校验：

| 层级 | 校验内容 | 结果 |
| ---- | ---- | ---- |
| 状态文件 | `work_dir/experiment/logs/round_state.json` | `188` |
| 数据文件 | `/root/projects/autoresearch/results.tsv` | `188` 条数据 |
| Git 工作树 | branch=`autoresearch/adaptive-ct-3`，HEAD=`be4e9c4` | 与最后 `keep` 一致 |

其中最后一条 `results.tsv` 记录为：

```text
be4e9c4    1.066517    8.3    keep
```

因此这次恢复不需要改写 `round_state.json`，只需要把会话层重新拉直。

## 3. 方案设计

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 是否保留当前 runner | 否，先杀掉 | 它已处于假活空转状态，继续保留没有收益 |
| 是否改 `round_state.json` | 否 | `round_state` 与 `results.tsv` 一致，都停在 188 |
| 是否回退 HEAD | 不需要额外回退，只需强制对齐到 `be4e9c4` | 当前 HEAD 已与最后 `keep` 一致，但重启前再显式对齐更稳妥 |
| 是否清理残留文件 | 是 | `run.log`、`nohup.out`、`PAUSE_REQUEST`、`.pid` 会干扰新会话 |
| 重启方式 | 重新启动 `python run_experiment.py round1` | 复用 runner 的内置 resume 逻辑 |

恢复策略选择了**最小修复面**：

- 不碰历史实验数据；
- 不修改策略参数；
- 只修 runner、会话和工作树一致性；
- 重启后再观察是否恢复到正常 MCP 调用链。

## 4. 实现要点

### 项目结构

```text
autoresearch/
├── work_dir/
│   ├── experiment/
│   │   ├── logs/
│   │   │   ├── round_state.json
│   │   │   └── adaptive-ct-3.log
│   │   └── run_experiment.py
│   └── journal/
│       └── 2026-04-17/
├── results.tsv
└── experiment_data/
    └── results_adaptive-ct-3.tsv
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/experiment/run_experiment.py` | Round 1 主 runner，负责 resume、切换 run、启动 agent |
| `work_dir/experiment/logs/round_state.json` | 记录当前 run 的迭代数与状态 |
| `work_dir/experiment/logs/adaptive-ct-3.log` | 单 run 的详细会话日志 |
| `/root/projects/autoresearch/results.tsv` | 实验主结果表 |
| `/root/projects/autoresearch/experiment_data/results_adaptive-ct-3.tsv` | 当前 run 的备份结果表 |

### 实际执行步骤

#### 4.1 停止假活 runner

先识别 Windows 宿主上的 runner：

```text
python.exe 8364 = run_experiment.py round1
```

随后结束整棵进程树：

```bash
taskkill /F /T /PID 8364
```

#### 4.2 对齐 WSL 断点

在 WSL 中重新显式对齐 branch / HEAD / 数据文件：

```bash
wsl -d Ubuntu-24.04 -- bash -lc '
  cd /root/projects/autoresearch
  git checkout autoresearch/adaptive-ct-3
  git reset --hard be4e9c4
  rm -f run.log nohup.out
  cp results.tsv experiment_data/results_adaptive-ct-3.tsv
  rm -f /mnt/d/github/fork/autoresearch/work_dir/experiment/logs/PAUSE_REQUEST
  rm -f /mnt/d/github/fork/autoresearch/work_dir/experiment/logs/*.pid
'
```

对齐后的真实状态：

```text
branch=autoresearch/adaptive-ct-3
head=be4e9c4
data_rows=188
last_row=be4e9c4    1.066517    8.3    keep
```

#### 4.3 重启实验

```bash
cd work_dir/experiment && python run_experiment.py round1
```

## 5. 验证与测试

### 启动验证

重启后的 runner 日志显示：

```text
[round1] Remaining: 1 runs - adaptive-ct-3
[setup] Restored results.tsv for adaptive-ct-3
[setup] On branch: autoresearch/adaptive-ct-3
--- Session 1 | Iterations: 188/200 | 12:04:45 ---
[cursor_acp] MCP server on port 8796
[cursor_acp] handshake ok
[cursor_acp] session: e09c407c-ec4d-40...
```

和卡死前最大的差异在于：恢复后的新 session 不再在握手后立即掉进 `RPC session/new: Internal error` / `WinError 10038` 的空转循环，而是继续进入了正常的 agent 工作流：

- 读取 `program.md` / `results.tsv`
- 调用 MCP shell 命令检查 WSL 环境
- 继续计算下一轮策略

### 运行态验证

恢复后的 `adaptive-ct-3.log` 已再次出现有效推进信号：

- agent 重新计算了 `δ`
- 判定 `δ≈0.914 > θ_break(0.7)`，继续走 BREAK
- 开始尝试新的 AdamW `beta2` 微调
- 训练超时后已切回“后台训练 + 轮询结果”的常规恢复路径

这说明 runner 已重新回到“**能读状态 -> 能做决策 -> 能发起训练**”的正常流程，不再是之前的纯空转重试。

## 6. 后续演化

- **会话层防呆**：当连续多次出现 `+0 iterations` 且伴随 `session/new` / `10038` 错误时，runner 可以直接判定为假活，自杀后由外层守护拉起，避免空转数小时。
- **启动自检**：`run_experiment.py` 可以在每次新 session 前加入一条“`results.tsv` 行数在过去 N 次 session 中是否完全不变”的检测，若不变则主动重启 ACP/MCP 层。
- **WSL 状态回显方式**：涉及 `$(...)`、`$var` 或复杂引号时，优先用内嵌 Python 输出 branch / head / rows，避免 Windows 外层 shell 提前展开变量，造成误判。
- **Round 1 收尾**：当前只差 `adaptive-ct-3` 的最后 12 轮。待其完成后，应立即汇总 9 个 run 的最终 BPB、VRAM、keep/discard 比例，并整理进入下一轮实验基线。

---

<!-- 关联：
- 本日早些时候的首次恢复：work_dir/journal/2026-04-17/adaptive-ct-3-resume-from-iter171.md
- 上一次中断恢复：work_dir/journal/2026-04-15/adaptive-ct-3-interruption-and-recovery.md
- WSL 僵尸进程修复：work_dir/journal/2026-04-09/wsl-zombie-fix-and-experiment-recovery.md
-->
