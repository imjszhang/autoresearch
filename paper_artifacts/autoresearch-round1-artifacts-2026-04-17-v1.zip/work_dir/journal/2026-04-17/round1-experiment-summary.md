# Round 1 实验总结：baseline / static-ct / adaptive-ct 9 轮运行复盘

> 日期：2026-04-17
> 项目：autoresearch（Cyber-Taoist 守破框架实证实验）
> 类型：调研分析 / 问题排查（阶段总结）
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

本轮（Round 1）目的是在受控条件下初步验证 `work_dir/research_design/` 与 `work_dir/experiment/programs/` 中给出的三大假设：

| 假设 | 内容 | 预期 |
| ---- | ---- | ---- |
| **H1 框架有效性** | CT 组（static-ct / adaptive-ct）的最终 val_bpb 显著低于 baseline | CT 组更低 |
| **H2 自进化优势** | adaptive-ct 在第 101–200 迭代的改进速率高于 static-ct | adaptive-ct 更强 |
| **H3 复杂度管理** | CT 组 crash 更少、代码更简洁 | CT 组更稳 |

Round 1 的规模约定为每组 3 个独立 run、每个 run 目标 200 iteration，共 9 × 200 ≈ 1800 次候选训练。这是走向论文设定的 10 × 3 = 30 run 完整实验前的**首轮探针**，目的是：

- 打通 agent × WSL × Cursor ACP/MCP 的长跑链路；
- 观察三种 `program.md` 在相同 5 分钟训练预算下的行为差异；
- 评估基础设施可靠性，为后续扩大样本量打基础。

## 2. 分析过程

### 2.1 实验设置

共性约束（三种 `program.md` 一致）：

- 只允许修改 `train.py`，其余文件只读；
- 每轮训练固定 5 分钟墙钟预算（由 `prepare.py` 控制）；
- 单 GPU；
- 评估指标：`val_bpb`（越低越好），VRAM 为软约束；
- 结果表：`results.tsv`，每行含 commit、val_bpb、memory_gb、status（keep / discard / crash / adapt）等。

三组差异：

| 组 | 决策方式 | 关键参数 |
| ---- | ---- | ---- |
| **baseline** | 完全自主，不强制任何守破规则 | 无 |
| **static-ct** | 固定阈值 δ 规则：δ<0.3 GUARD；0.3≤δ≤0.7 SIMPLIFY；δ>0.7 BREAK | θ_guard=0.3, θ_break=0.7（固定） |
| **adaptive-ct** | 同 static-ct，但每 50 iter 基于历史 δ 桶的 GUARD/BREAK 成功率重算阈值 | θ_guard、θ_break 自演化 |

### 2.2 执行实际情况

9 个 run 均**全部跑满并达到 200 iteration 目标**，最终 `round_state.json` 全部为 `completed`：

| run | 写入行数 | keep | discard | crash | adapt | 最佳 `val_bpb` | 最佳 commit |
| ---- | ---- | ---- | ---- | ---- | ---- | ---- | ---- |
| baseline-1 | 200 | 8 | 184 | 8 | 0 | 1.084914 | `87faa61` |
| baseline-2 | 200 | 38 | 161 | 1 | 0 | 1.106892 | `dc65330` |
| baseline-3 | 201 | 21 | 174 | 6 | 0 | 1.071198 | `4376f7b` |
| static-ct-1 | 203 | 24 | 155 | 24 | 0 | 1.070910 | `bc556a4` |
| static-ct-2 | 202 | 25 | 154 | 23 | 0 | 1.076708 | `33467ae` |
| static-ct-3 | 202 | 10 | 182 | 10 | 0 | 1.080227 | `826c359` |
| adaptive-ct-1 | 201 | 26 | 161 | 10 | 4 | 1.088484 | `f019769` |
| adaptive-ct-2 | 203 | 41 | 137 | 21 | 4 | 1.078147 | `d1fad32` |
| adaptive-ct-3 | 203 | 29 | 156 | 14 | 4 | **1.066517** | `be4e9c4` |

> 说明：部分 run 超过 200 行是因为 agent 在策略循环中追加了若干补写记录；runner 的完成判定基于「总行数 ≥ 200」而非严格等号，不影响最终结论。

### 2.3 运行代价与稳定性

本轮运行横跨数天（`work_dir/journal/` 中 2026-04-04 至 2026-04-17 均有对应记录），期间发生多次中断与恢复。主要工程事件：

| 事件 | 影响 | 处理 |
| ---- | ---- | ---- |
| WSL 僵尸 `wsl.exe` 累积 | 会话层失联、实验停滞 | 改造 `cursor_acp.py` + `run_experiment.py` 做进程树清理 |
| Cursor ACP 偶发 `RPC session/new: Internal error` / `WinError 10038` | runner 空转重试、`+0 iterations` | 引入假活检测与人工断点重启协议 |
| agent 提交顺序问题（commit 先于 `results.tsv` 追加） | HEAD 领先结果表，恢复时有歧义 | 约定「HEAD 向 `results.tsv` 收敛」，必要时 `git reset --hard <last_keep>` |
| 单次训练被 MCP 超时打断 | 日志中出现未落表的候选提交 | 切换「`nohup setsid` 独立日志 + 轮询」模式 |

详细记录见 `work_dir/journal/2026-04-08` ~ `2026-04-17` 下的 `wsl-zombie-fix-and-experiment-recovery.md`、`adaptive-ct-3-resume-from-iter171.md`、`adaptive-ct-3-stall-at-188-and-recovery.md`、`adaptive-ct-3-final-state-reconciliation.md` 等条目。

## 3. 方案设计

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 每组样本量 | Round 1 固定 3 run | 小样本先通链路，大样本留给 Round 2+ |
| 结果表 vs 工作树孰为准 | 以 `results.tsv` + `round_state.json` 为准 | 两者是后续统计分析的唯一入口 |
| 中断恢复策略 | 断点对齐（branch / HEAD / rows 三位一体）而非重跑 | 保护已完成迭代的时间成本 |
| 对 `ADAPT` 行的处理 | 计入总行数，但不参与 best keep 选择 | 统计口径与 `programs/adaptive_ct.md` 一致 |
| 未入表的 post-ADAPT 候选提交 | 不补写，HEAD 收敛回最佳 keep | 保持结果表与 round_state 的收尾一致性 |

## 4. 实现要点

### 项目结构

```text
work_dir/
├── foundations/                     # 理论原文
├── research_design/                 # 研究问题、假设、评判维度
├── manuscript/                      # paper 正稿与 supplementary
├── experiment/
│   ├── run_experiment.py            # Round 主 runner
│   ├── cursor_acp.py                # ACP/MCP shell 客户端 + 服务端
│   ├── programs/                    # baseline.md / static_ct.md / adaptive_ct.md
│   ├── docs/                        # runbook / design_rationale / expected_results
│   └── logs/
│       ├── round_state.json         # Round 进度
│       └── <run>.log                # 每个 run 的 agent 会话详单
└── journal/
    └── YYYY-MM-DD/                  # 事件化日记（恢复 / 总结 / 反思）
```

配套的实验数据在 WSL 下：

```text
/root/projects/autoresearch/
├── results.tsv                       # 当前 run 的正式结果表
├── experiment_data/
│   └── results_<run>.tsv             # 9 个 run 的冷备份（Round 1 全量）
├── train.py                          # agent 唯一可改文件
└── prepare.py                        # 固定训练 / 评估 harness（只读）
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/experiment/run_experiment.py` | Round 调度、断点续跑、WSL 进程管理、会话健康检查 |
| `work_dir/experiment/cursor_acp.py` | 与 Cursor Agent 建立 ACP 会话 + 本地 MCP shell 服务端 |
| `work_dir/experiment/programs/{baseline,static_ct,adaptive_ct}.md` | 三种 `program.md` 决策框架 |
| `work_dir/experiment/docs/agent_runbook.md` | 人机协作操作手册 |
| `work_dir/experiment/docs/expected_results.md` | 预期假设与评判维度 |
| `experiment_data/results_<run>.tsv` | 每个 run 的结果表冷备份，供事后对比 |

## 5. 验证与测试

### 5.1 组聚合指标（Round 1，n = 3 / 组）

| 组 | 最佳 val_bpb（组内最低） | 最佳 val_bpb（3 run 平均） | keep 率（非 adapt 行）平均 | 平均 crash 次数 | ADAPT 行数 |
| ---- | ---- | ---- | ---- | ---- | ---- |
| **baseline** | 1.071198 | 1.087668 | 11.1% | 5.0 | 0 |
| **static-ct** | 1.070910 | 1.075948 | 9.7% | 19.0 | 0 |
| **adaptive-ct** | **1.066517** | 1.077716 | **16.1%** | 15.0 | 12 |

### 5.2 针对三大假设的初步评估

| 假设 | Round 1 证据 | 初步结论 |
| ---- | ---- | ---- |
| **H1 CT 组优于 baseline** | CT 组平均最佳 `val_bpb` 1.0759 / 1.0777 均低于 baseline 1.0877；组内最低点 adaptive-ct-3 = 1.066517 刷新全场最佳 | 方向与预期一致，但仅 3 run / 组，统计意义弱 |
| **H2 adaptive-ct 优于 static-ct** | 绝对最佳值 adaptive-ct 胜（1.0665 vs 1.0709）且 keep 率显著更高（16.1% vs 9.7%）；但 3 run 平均最佳反而 static-ct 略低（1.0759 vs 1.0777） | **存在正向信号（极值 + keep 率），但均值尚未见优势** |
| **H3 CT 组 crash 更少** | baseline 平均仅 5 次 crash；CT 组平均 15–19 次 crash，明显更多 | **与预期相反**，可能原因：CT 组 BREAK 触发了更激进的架构尝试 |

### 5.3 直接观察到的结构性规律

- **adaptive-ct 的 keep 率最高**：与 H2 自进化预期一致——每 50 iter 的 θ_guard / θ_break 调整带来更"能落地"的策略组合。
- **static-ct 的 crash 最多**：固定阈值在后期（δ 长期接近 1.0）会连续触发 BREAK，而缺乏自调节机制。
- **baseline 组内方差最大**：没有任何结构化规则时，agent 的探索方差最大——既出过 `baseline-3 = 1.0712` 的亮点，也出过 `baseline-2 = 1.1069` 的拖尾。
- **绝对最佳出现在 adaptive-ct-3**：连续的 `Muon momentum ramp start 0.85 → 0.852` 微调（`be4e9c4`）稳定取得 `val_bpb = 1.066517`，同时 VRAM 保持在 8.3 GB。

## 6. 后续演化

### 6.1 理论与论文侧

- **H1 / H2 需要扩样**：Round 1 每组仅 3 run，论文设计要求 10 run / 组。建议进入 Round 2+，把样本量补齐后再做 Kruskal-Wallis / Mann-Whitney 检验。
- **H3 的反向信号需要解释**：CT 组 crash 多可能来自"更敢于破"，并非 bug，但需要在 paper discussion 中单独讨论，并在 Round 2 为 crash 加上原因分类（OOM vs 数值爆炸 vs 语法错误）。
- **ADAPT 行为可视化**：已有 12 行 ADAPT 记录（adaptive-ct × 3 × 4 checkpoint），下一步应画出 θ_guard / θ_break 在 50 / 100 / 150 / 200 的轨迹图。
- **最佳基线迁移**：若沿用同一物理环境，可考虑把 `adaptive-ct-3 / be4e9c4` 的 `train.py` 作为新通用起点——前提是为保持假设比较公平，需要在 Round 2 明确记录这一变更。

### 6.2 工程与基础设施侧

- **runner 自检**：`run_experiment.py` 在启动每个 run 前应自动校验 HEAD 是否等于 `results.tsv` 最后一条 keep，不一致则自动 reset。
- **假活检测**：当连续 N 个 session 都 `+0 iterations` 且伴随 `WinError 10038` / `RPC session/new` 时，runner 应主动重启 ACP / MCP，避免长时间空转。
- **MCP 长时训练的统一模式**：本轮逐步收敛到「`nohup setsid uv run train.py > run_iter*.log` + `grep '^val_bpb:'` 轮询」的写法，应升级为 `adaptive_ct.md` / `static_ct.md` 中的官方指引，避免 agent 临场发明脆弱命令。
- **日志分级**：`adaptive-ct-3.log` 单文件已达 2 万行以上，Round 2 前值得拆为按 run + 按 session 的子文件。

### 6.3 本轮最终状态

| 项目 | 值 |
| ---- | ---- |
| Round 1 状态 | **已完成（9 / 9）** |
| Round 1 绝对最佳 | `adaptive-ct-3 / be4e9c4` · `val_bpb = 1.066517` · VRAM 8.3 GB |
| `round_state.json` | 全部 run `completed` |
| 当前 WSL 分支 | `autoresearch/adaptive-ct-3` |
| 当前 HEAD | `be4e9c4`（已收敛回最佳 keep） |
| 备份 | `experiment_data/results_<run>.tsv` 全 9 份齐全，与主结果表一致 |

Round 1 的核心价值不仅是数据本身，更重要的是**已经在真实长跑条件下打通了 Cursor ACP + WSL + 实验协议这条链路**，并沉淀出一套可复用的中断恢复规程（见 2026-04-08 至 2026-04-17 的 journal 系列）。这让后续 Round 2+ 可以在明显更低的运维成本下进行。

---

<!-- 关联：
- 研究设计与评判维度：work_dir/experiment/docs/expected_results.md
- 三种 program.md：work_dir/experiment/programs/{baseline,static_ct,adaptive_ct}.md
- Round 中间 checkpoint：work_dir/journal/2026-04-10/round1-first-three-runs-checkpoint.md
- 最后一个 run 的多次恢复：
  - work_dir/journal/2026-04-17/adaptive-ct-3-resume-from-iter171.md
  - work_dir/journal/2026-04-17/adaptive-ct-3-stall-at-188-and-recovery.md
  - work_dir/journal/2026-04-17/adaptive-ct-3-final-state-reconciliation.md
-->
