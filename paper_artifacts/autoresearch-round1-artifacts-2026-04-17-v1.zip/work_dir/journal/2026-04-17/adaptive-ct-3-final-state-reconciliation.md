# adaptive-ct-3 完成后的最终收尾对齐

> 日期：2026-04-17
> 项目：autoresearch（Round 1 · run 9/9 adaptive-ct-3）
> 类型：问题排查 / 升级迁移（最终收尾修正）
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

`adaptive-ct-3` 在 `188/200` 卡死后已被恢复，并最终把 Round 1 跑完。runner 正常退出，`round_state.json` 也显示 `completed`。但在最终收尾检查时发现：**Git HEAD 与 `results.tsv` 的尾部状态不一致**。

具体来说：

- `round_state.json` 已完成：`iterations=203`
- `results.tsv` 已收尾：最后一条是 `ADAPT`
- 但 WSL 当前 HEAD 却停在一个额外的 post-ADAPT 提交 `4467511`

如果不处理，这会导致“**实验数据认为已经结束，工作树却停在一个未入表的临时候选提交**”的歧义，给后续 Round 2 基线选择和结果复盘带来风险。

## 2. 分析过程

### 2.1 状态检查

收尾前观察到的状态如下：

| 项目 | 实际值 | 判断 |
| ---- | ---- | ---- |
| `round_state.json` | `adaptive-ct-3: completed, iterations: 203` | Round 1 已完成 |
| `results.tsv` | `203` 条数据 | 数据层完整 |
| `results.tsv` 最后一条 | `ADAPT` | 结果表以适配记录收尾 |
| 当前 HEAD | `4467511` | 与结果表尾部不一致 |
| 当前最佳 keep | `be4e9c4` / `1.066517` | 最佳提交明确 |

### 2.2 追踪 `4467511`

为确认 `4467511` 是否只是脏状态，还是一次真实已完成的实验，进一步检查了：

- `git log --oneline -5`
- `run_iter200_b9268.log`
- `adaptive-ct-3.log`
- 完成 runner 的终端输出

最终确认：

1. `4467511` 对应一次真实训练；
2. 训练日志 `run_iter200_b9268.log` 完整存在；
3. 该次训练已跑满并产出结果：

```text
val_bpb:      1.149323
peak_vram_mb: 8522.2
```

4. 这个结果显著劣于当前最佳 `be4e9c4 = 1.066517`；
5. 但它**没有被写进 `results.tsv`**，而 `results.tsv` 已经用 `ADAPT` 行作为第 203 条记录收尾。

### 2.3 风险判断

这里存在两种可能的修法：

| 修法 | 优点 | 风险 |
| ---- | ---- | ---- |
| 把 `4467511` 追加进 `results.tsv` | 数据和 HEAD 完全对齐 | 会把总行数从 203 推到 204，破坏现有完成态 |
| 把 HEAD 重置回最佳 `be4e9c4` | 保持 `round_state` / `results.tsv` / 备份文件一致 | `4467511` 的结果只保留在日志中，不进入正式表 |

考虑到 runner 已宣告完成、`results.tsv` 与备份文件已经一致收尾，最小修正面是第二种方案。

## 3. 方案设计

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 是否把 `4467511` 补写入 `results.tsv` | 否 | 会改变当前完成态的总条数与尾部语义 |
| 最终 HEAD 应指向哪里 | `be4e9c4` | 它是正式记录中的最佳 `keep` |
| 是否同步备份文件 | 是 | 防止主 `results.tsv` 与备份再次分叉 |
| 是否修改 `round_state.json` | 否 | 其完成态已与正式结果表一致 |

最终原则是：**以正式结果表为准，HEAD 向结果表收敛，而不是反过来强行扩展结果表。**

## 4. 实现要点

### 项目结构

```text
autoresearch/
├── work_dir/
│   ├── experiment/
│   │   └── logs/
│   │       ├── round_state.json
│   │       └── adaptive-ct-3.log
│   └── journal/
│       └── 2026-04-17/
├── results.tsv
└── experiment_data/
    └── results_adaptive-ct-3.tsv
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `results.tsv` | 当前 run 的正式实验结果表 |
| `experiment_data/results_adaptive-ct-3.tsv` | 当前 run 的备份结果表 |
| `work_dir/experiment/logs/round_state.json` | Round 1 的完成状态 |
| `work_dir/experiment/logs/adaptive-ct-3.log` | 最终几轮决策、异常和收尾日志 |
| `run_iter200_b9268.log` | `4467511` 对应的完整训练输出 |

### 执行步骤

#### 4.1 确认无活跃实验进程

在 Windows 宿主上确认：

- 没有 `run_experiment.py` runner
- 没有活跃 `wsl.exe`

这样可以确保收尾修正不会影响进行中的训练。

#### 4.2 对齐最终 HEAD 并同步备份

执行以下命令：

```bash
wsl -d Ubuntu-24.04 -- bash -lc '
  cd /root/projects/autoresearch
  git reset --hard be4e9c4
  cp results.tsv experiment_data/results_adaptive-ct-3.tsv
'
```

## 5. 验证与测试

修正后再次验证：

```text
branch=autoresearch/adaptive-ct-3
head=be4e9c4 BREAK iter185: Muon momentum start 0.85 to 0.852
data_rows=203
last_row=ADAPT    0.000000    0.0    adapt    parameter adaptation at iter 200    0.000
backup_rows=203
backup_last=ADAPT    0.000000    0.0    adapt    parameter adaptation at iter 200    0.000
```

最终确认：

- `round_state.json`：完成
- `results.tsv`：203 条
- 备份 `results_adaptive-ct-3.tsv`：203 条
- HEAD：`be4e9c4`
- 正式最佳结果：`be4e9c4 / val_bpb=1.066517`

这意味着 Round 1 现在已经处于一个**完成且收尾一致**的状态。

## 6. 后续演化

- **避免 post-ADAPT 尾提交悬空**：在 `run_experiment.py` 收尾前，可增加一条检查，如果最后一轮提交没有正式写入 `results.tsv`，则自动 reset 回最近的 `keep`。
- **明确“正式结果表优先”原则**：将“正式完成态以 `results.tsv` 与 `round_state.json` 为准，HEAD 必须向其收敛”写进恢复协议。
- **Round 2 基线建议**：如果后续进入下一轮实验，推荐直接以 `be4e9c4` 作为 `adaptive-ct-3` 的稳定基线，而不是使用日志里存在但未正式入表的 `4467511`。

---

<!-- 关联：
- 171/200 首次恢复：work_dir/journal/2026-04-17/adaptive-ct-3-resume-from-iter171.md
- 188/200 卡死恢复：work_dir/journal/2026-04-17/adaptive-ct-3-stall-at-188-and-recovery.md
- 上一次中断恢复：work_dir/journal/2026-04-15/adaptive-ct-3-interruption-and-recovery.md
-->
