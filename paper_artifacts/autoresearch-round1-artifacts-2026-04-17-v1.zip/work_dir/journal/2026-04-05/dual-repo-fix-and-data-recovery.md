# 双仓库问题修复、数据事故恢复与 Round 1 重启

> 日期：2026-04-05
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查 / 功能实现
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [问题发现](#2-问题发现)
3. [根因分析](#3-根因分析)
4. [修复方案](#4-修复方案)
5. [验证测试与数据事故](#5-验证测试与数据事故)
6. [数据恢复与重启](#6-数据恢复与重启)
7. [经验教训](#7-经验教训)

---

## 1. 背景与动机

Round 1 正式实验已启动（`baseline-1`，14:31），运行约 2 小时后跑到 14/200 迭代。此时发现 Windows 仓库的 `D:\github\fork\autoresearch\train.py` 被 Agent 改动了——出现了一处 `MATRIX_LR 0.04 → 0.035` 的修改。

实验的设计意图是所有改动只发生在 WSL 仓库 `/root/projects/autoresearch` 内，Windows 仓库不应被触碰。

---

## 2. 问题发现

### 现象

```
> cd "D:\github\fork\autoresearch" && git diff HEAD train.py
-MATRIX_LR = 0.04
+MATRIX_LR = 0.035       # — exp: slightly lower for generalization
```

Windows 仓库停在 `master`（`80b98d7`），但 `train.py` 有未提交的脏改动。

### 两个仓库的状态对比

| 对比项 | Windows 仓库 | WSL 仓库 |
|--------|-------------|----------|
| HEAD | `80b98d7`（master） | `20e49ab`（baseline-1 分支，14 次实验后） |
| train.py | 有 1 行脏改动（`MATRIX_LR`） | 干净，和 HEAD 一致 |
| results.tsv | 不存在 | 14 行实验数据 |
| git branch | `githubforker` | `autoresearch/baseline-1` |

### 关键发现：实验数据有效

Agent 日志第 687 行自己写道：

> **说明**：你本机 Cursor 里的 `D:\github\fork\autoresearch` 与 WSL 的 `/root/projects/autoresearch` 若为两套目录，需要自行同步 `train.py`；当前改动与提交仅在 **WSL 仓库** 中完成。

训练、git commit、git reset 全部在 WSL 闭环完成。Windows 侧的改动是 Agent 用 Cursor 内置 Edit File 探查工作区时的副作用，**未被训练使用**。

---

## 3. 根因分析

### 架构问题：两套仓库、一个 cwd

```
run_experiment.py
  └─ cursor_acp.run_prompt(agent_cmd, model, WIN_CWD, prompt_text)
       └─ _Context.__init__(cwd = "D:\github\fork\autoresearch")
            ├─ Popen(cwd = WIN_CWD)           ← node.exe 启动目录
            └─ session/new(cwd = WIN_CWD)      ← Agent 工作区（Read/Edit 的根）
```

`run_prompt()` 只有一个 `cwd` 参数，同时用于：
1. **node.exe 进程启动目录**（必须是 Windows 原生路径）
2. **ACP session/new 的工作区**（决定 Agent 内置文件工具解析路径的根）

Agent 的 Read File / Edit File 以 `D:\github\fork\autoresearch` 为工作区，自然就改了 Windows 侧的文件。

---

## 4. 修复方案

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 拆分 cwd | `run_prompt()` 新增 `session_cwd` 参数 | node.exe 必须用 Windows 路径启动，但 Agent 工作区应指向 WSL |
| Agent 工作区 | `\\wsl$\Ubuntu-24.04\root\projects\autoresearch` | UNC 路径让 Cursor 内置文件工具直接操作 WSL 文件系统 |
| 是否立即改 | 改文件不影响运行中的进程 | Python 模块级变量已加载到内存，磁盘改动下次启动才生效 |

### 改动内容

**`cursor_acp.py`** — `run_prompt()` 签名变更：

```python
def run_prompt(agent_cmd, model, cwd, prompt_text, *, session_cwd=None, ...):
    ctx = _Context(agent_cmd, model, cwd, session_cwd or cwd, on_text, on_tool)
```

- `cwd` → Popen 启动目录（保持 `D:\github\fork\autoresearch`）
- `session_cwd` → ACP `session/new` 的工作区（改为 UNC 路径）

**`_Context.__init__`** 新增 `_session_cwd` 字段，`create_session()` 用 `_session_cwd`。

**`run_experiment.py`** — 新增常量和传参：

```python
WSL_UNC = r"\\wsl$\Ubuntu-24.04\root\projects\autoresearch"

cursor_acp.run_prompt(
    AGENT_CMD, MODEL, WIN_CWD, prompt_text,
    session_cwd=WSL_UNC,
    on_text=on_text, on_tool=on_tool,
)
```

**`prompt_template.txt`** — 更新环境描述，告知 Agent 工作区就是 WSL 文件系统，`train.py`、`program.md` 可按文件名直接读写。

---

## 5. 验证测试与数据事故

### 测试流程

1. Ctrl+C 中断正在跑的实验（强杀进程树 + 清理残留）
2. 执行 `python run_experiment.py run baseline test-unc --max-iter 1`
3. 观察 Agent 行为

### 测试结果

| 检查项 | 结果 |
|--------|------|
| Agent 读 WSL 文件 | 5 次 Read File 均成功 |
| Agent 改 WSL 文件 | commit `045b00f` 证明在 WSL 仓库编辑并提交了 train.py |
| 训练正常完成 | `val_bpb=1.224425`，记录到 results.tsv |
| **Windows 侧 train.py** | **`git diff` 为空 — 未被改动** |
| 进程退出 | `exit_code: 0` |

UNC 路径修复验证通过。

### 数据事故

测试完成后清理测试分支时，执行了：

```bash
git checkout autoresearch/baseline-test-unc   # 查看测试结果
# ... 确认后 ...
git checkout autoresearch/baseline-1          # 切回正式分支
git branch -D autoresearch/baseline-test-unc  # 删除测试分支
```

**结果**：`results.tsv` 从 14 行变成了 1 行，内容是测试 run 的数据（`1.224425`）而非原始数据。

**原因**：`results.tsv` 是 **untracked 文件**（按实验协议不纳入 git）。`git checkout` 切分支时，untracked 文件**不受 git 保护**。当从 `baseline-test-unc`（有 1 行 results.tsv）切回 `baseline-1` 时，工作目录中的 `results.tsv` 保持了 `test-unc` 的版本。

更准确地说：`baseline-test-unc` 的 `results.tsv` 是 `setup_branch()` 用 `printf` 新建的，Agent 写了 1 行。切回 `baseline-1` 后这个 1 行文件留在了工作目录，覆盖了原来的 14 行。

---

## 6. 数据恢复与重启

### 恢复来源

| 来源 | 覆盖范围 |
|------|---------|
| `experiment_data/results_baseline-1.tsv`（860字节，16:08） | 前 11 行（session 5 时自动备份） |
| Agent 日志 + 中断前的终端记录 | 后 3 行的 commit hash、BPB、描述 |

### 恢复操作

```bash
# 1. 从备份恢复前 11 行
cp experiment_data/results_baseline-1.tsv results.tsv

# 2. 追加缺失的 3 行（从中断前终端记录中提取）
cat >> results.tsv << 'EOF'
20e49ab	1.148341	11.4	discard	MATRIX_LR 0.04->0.035 (worse vs best 1.092322)
bf7ae08	1.148341	11.4	discard	WEIGHT_DECAY 0.2->0.18 (worse vs best 1.092322)
065c5ad	1.148341	11.4	discard	EMBEDDING_LR 0.75->0.65 (same/worse val vs best 1.092322)
EOF

# 3. 验证
awk -F'\t' 'NR>1 && NF>=4' results.tsv | wc -l  # → 14

# 4. Reset HEAD 到最佳 commit（中断时有一个未完成的 DEPTH 实验）
git reset --hard 3b82faa

# 5. 更新备份
cp results.tsv experiment_data/results_baseline-1.tsv
```

### 重启确认

```
[state] Resumed from round_state.json
[round1] Remaining: 9 runs
[setup] Switching to autoresearch/baseline-1...

--- Session 1 | Iterations: 14/200 | 16:46:51 ---
[agent] Sending prompt to Cursor Agent...
[cursor_acp] session: ac6b9d94-d3a0-47...
[tool] Read File (pending)        ← Agent 通过 UNC 路径直接读 WSL 文件
[tool] MCP: tool (pending)        ← run_command 在 WSL 中执行
```

`14/200` — 正确读到恢复后的 14 行，从断点继续。

---

## 7. 经验教训

### 根本问题

| 问题 | 影响 | 修复 |
|------|------|------|
| ACP session 的 cwd 指向 Windows 仓库 | Agent 内置文件工具改 Windows 侧文件 | 拆分 `cwd`/`session_cwd`，后者指向 WSL UNC 路径 |
| `results.tsv` 是 untracked 文件 | git checkout 切分支时不受保护，可被覆盖 | 下次测试用独立工作目录或先手动备份 |
| 自动备份间隔（每 5 个 session）不够密 | 中断时丢失 3 行数据 | 考虑每次 session 结束都备份 |

### 操作规范（新增）

1. **不要在实验进行中切换 WSL 仓库的分支**——untracked 文件（results.tsv、run.log）会被覆盖或遗留
2. **测试新功能时用独立路径**，或先 `cp results.tsv results.tsv.bak`
3. **强杀进程后必查残留**：MCP 端口 8796、node.exe、WSL 训练进程
4. **恢复数据后核对**：`results.tsv` 行数、HEAD commit、备份一致性

### 最终状态

| 项目 | 值 |
|------|------|
| baseline-1 进度 | 14/200 迭代 |
| 当前最佳 | `3b82faa`，val_bpb = 1.092322 |
| HEAD | `3b82faa`（已 reset，干净） |
| 进程 | Round 1 已重新启动，PID 23204 |
| Agent 工作区 | `\\wsl$\Ubuntu-24.04\root\projects\autoresearch`（修复后） |
| Windows 侧 train.py | 干净，不再被 Agent 触碰 |
