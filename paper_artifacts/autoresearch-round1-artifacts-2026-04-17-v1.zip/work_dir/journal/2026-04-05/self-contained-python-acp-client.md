# 自包含 Python ACP 客户端：实现、调试与 Dry-run 验证

> 日期：2026-04-05
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：功能实现 / 问题排查
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [问题排查记录](#6-问题排查记录)
7. [目录整理](#7-目录整理)
8. [后续演化](#8-后续演化)

---

## 1. 背景与动机

前一天（04-04）完成了实验设计、三组 program.md 编写和 pilot 预实验。当时使用的 `js-cursor-agent` 是外部 Node.js 项目，存在以下问题：

- 额外的 npm 依赖（需要 `node_modules`）
- 进程管理复杂（Node 包装 → Cursor Agent CLI）
- 对 ACP 协议的封装不透明，排查问题困难

目标：用纯 Python（零外部依赖）直接与 Cursor Agent CLI 的 ACP 协议通信，实现全自动无人值守实验执行。

---

## 2. 分析过程

### ACP 协议要素

ACP（Agent Communication Protocol）是 Cursor Agent CLI 的 headless 通信协议：

- 传输层：JSON-RPC 2.0 over NDJSON（stdin/stdout）
- 启动命令：`agent.cmd --model composer-2 acp`
- 握手流程：`initialize` → `authenticate` → `session/new` → `session/prompt`
- 权限模型：Agent 通过 `session/request_permission` 请求客户端批准工具调用
- 事件流：Agent 通过 `session/update` 通知推送文本输出和工具调用状态

### 关键发现：Terminal 工具在 headless 模式下不可用

调试过程中发现 Cursor Agent 的内置 Terminal/Shell 工具在 Windows headless ACP 模式下**完全无法工作**：

- Agent 尝试创建 ConPTY（Windows Console Pseudo-Console）
- `conhost.exe` 被创建但内部没有实际 shell 进程
- 工具调用永久卡在 "pending" 状态
- 设置 `terminal: false` 客户端能力并不能阻止 Agent 尝试使用

这是 Cursor Agent 在 Windows 上的已知限制，需要替代方案。

---

## 3. 方案设计

### 最终架构

```
run_experiment.py  (实验编排器：分支管理、session 重启循环)
       │
       ▼
cursor_acp.py      (ACP 客户端 + 内嵌 MCP Shell 服务器)
       │
       ├── JSON-RPC/NDJSON ──► Cursor Agent CLI (agent.cmd acp)
       │                        ├── Read/Write/Edit File (内置)
       │                        └── MCP: run_command ──► 内嵌 HTTP 服务器
       │
       └── HTTP/SSE MCP Server (ThreadingHTTPServer, port 8796)
            └── run_command → subprocess.run(shell=True) → WSL 命令
```

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| ACP 客户端语言 | Python（stdlib only） | 零依赖，与编排器同语言，调试方便 |
| Terminal 替代 | 内嵌 MCP HTTP/SSE 服务器 | Agent 原生支持 MCP 工具，透明替换 Terminal |
| MCP 传输协议 | HTTP/SSE（非 stdio） | ACP `session/new` 的 `mcpServers` 参数只接受 `type: "sse"` 或 `type: "http"` |
| HTTP 服务器 | ThreadingHTTPServer | SSE 长连接需要多线程，否则 `shutdown()` 会死锁 |
| Terminal 挂起处理 | 30 秒检测 + 自动 kill | Agent 偶尔仍会尝试 Terminal，快速恢复比完全阻止更实际 |
| 分支创建 | 从模板分支（非 master） | 模板分支包含各组专用 `program.md`，从 master 创建会丢失 |

---

## 4. 实现要点

### 项目结构（整理后）

```
work_dir/experiment/
├── cursor_acp.py           # ACP 客户端 + MCP Shell 服务器（~506 行）
├── run_experiment.py        # 实验编排器（~199 行）
├── run_experiment.sh        # bash 薄壳入口
├── prompt_template.txt      # Agent 提示词模板
│
├── programs/                # 三组实验协议
│   ├── baseline.md
│   ├── static_ct.md
│   └── adaptive_ct.md
│
├── docs/                    # 文档
│   ├── README.md
│   ├── agent_runbook.md
│   ├── design_rationale.md
│   └── expected_results.md
│
├── pilot/                   # Pilot 阶段存档
│
├── logs/                    # 运行时：Agent 对话日志
└── experiment_data/         # 运行时：results.tsv 备份
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `cursor_acp.py` | ACP JSON-RPC 通信、MCP Shell 服务器、工具权限审批、Terminal 检测、idle 超时 |
| `run_experiment.py` | CLI 入口、分支管理（从模板分支创建 + results.tsv 初始化）、session 重启循环、迭代计数、备份 |
| `prompt_template.txt` | 指示 Agent 使用 MCP `run_command` 而非 Terminal，包含 WSL 命令模板 |

### cursor_acp.py 核心机制

**MCP Shell 服务器**（内嵌，`ThreadingMixIn + HTTPServer`）：
- GET `/sse`：SSE 端点，发送 `{"endpoint": "http://127.0.0.1:8796/message"}` 后保持长连接
- POST：处理 `initialize`、`tools/list`、`tools/call`（run_command）、`ping`
- `run_command`：`subprocess.run(shell=True)` 执行命令，600 秒超时
- 连接异常（`ConnectionAbortedError` 等）在 `do_POST` 外层统一捕获

**ACP 客户端**：
- `_resolve_agent_args`：绕过 `cmd /c powershell`，直接调用 `node.exe index.js`
- `_send`：带 24 小时超时的同步 RPC 调用（`threading.Event` 等待响应）
- `_teardown`：Agent 进程退出时解锁所有 pending 请求
- Terminal 工具检测：`tool_call` 事件中匹配 "terminal"/"shell"（排除 MCP 工具名）
- idle 超时：300 秒无事件自动终止 session
- Terminal 挂起：检测后 30 秒自动 kill

**权限审批**：
- MCP 工具（`shell-executor-*`）：自动批准
- Terminal/Shell 内置工具：自动拒绝（`outcome: cancelled`）
- 其他工具（Read File、Edit File 等）：自动批准
- 问题回答（`cursor/ask_question`）：选第一个选项
- 计划创建（`cursor/create_plan`）：自动批准

### run_experiment.py 核心机制

**分支管理**（`setup_branch`）：
- 新 run：从模板分支（`autoresearch/baseline` 等）创建，初始化 `results.tsv`（含正确的列头）
- 已有 run：直接 `git checkout`，Agent 读取已有 `results.tsv` 从断点恢复

**session 重启循环**：
- 最多 50 次重试
- 每次 session 后检查迭代增量
- 零增量 → 30 秒等待后重试
- 每 5 个 session 备份 `results.tsv`

---

## 5. 验证与测试

### Dry-run 结果

命令：`python run_experiment.py run baseline e2e-test --max-iter 2`

| 指标 | 结果 |
| ---- | ---- |
| 总耗时 | ~36 分钟 |
| 完成迭代 | 3 次（超额完成 max-iter=2 目标） |
| Session 数 | 3（前 2 个因 Terminal hang 被 kill，第 3 个完成所有迭代） |
| 退出码 | 0 |

### 迭代记录

| 迭代 | Commit | Val BPB | 状态 | 描述 |
| ---- | ------ | ------- | ---- | ---- |
| 1 | f399129 | **1.178** | keep | baseline (DEVICE_BATCH_SIZE=64) |
| 2 | 025a0f0 | 1.227 | discard | WARMDOWN_RATIO 0.5→0.4 |
| 3 | 251e01d | 1.227 | discard | MATRIX_LR 0.04→0.045 |

### Agent 行为观察

Agent 在 session 中展现了完整的实验循环能力：
1. 读取 `program.md` → 理解实验协议
2. `git status` + 检查 `results.tsv` → 确定当前状态
3. 运行训练 → 遇到 OOM → 自主调整 DEVICE_BATCH_SIZE → git commit
4. 使用 `nohup` 后台运行训练 + 轮询 `train_done.flag` → 智能处理长时间训练
5. 记录结果到 `results.tsv` → 尝试超参数变化 → 比较 BPB

---

## 6. 问题排查记录

本次实现涉及大量调试，按时间顺序记录关键问题：

### 6.1 Agent 进程挂起（`_send` 阻塞 24 小时）

**现象**：Agent 进程意外退出后，`_send` 方法的 `Event.wait()` 永远不返回。

**根因**：`_reader_loop` 退出时没有解锁 pending 请求。

**修复**：添加 `_teardown` 方法，遍历所有 `_pending` 条目设置 error 并 `set()` event。在 `_reader_loop` 的 `finally` 块中调用。

### 6.2 Terminal 工具卡死

**现象**：Agent 调用内置 Terminal 工具后，工具状态永久停留在 "pending"。

**根因**：Windows headless ACP 模式下，ConPTY 无法正常创建 shell 进程。这是 Cursor Agent 的已知限制。

**修复**：实现内嵌 MCP HTTP/SSE 服务器提供 `run_command` 替代工具。通过 `session/new` 的 `mcpServers` 参数注册到 Agent。

### 6.3 MCP 工具被误拦截

**现象**：MCP 的 `run_command` 工具被权限系统拒绝。

**根因**：Terminal 拦截逻辑检查 `"shell" in tool_title.lower()`，而 MCP 工具标题为 `"shell-executor-run_command: run_command"`，包含 "shell"。

**修复**：先检查 `title.startswith(("shell-executor", "mcp:", "MCP:"))` 识别 MCP 工具，仅对非 MCP 工具执行 Terminal 关键字匹配。

### 6.4 端口 8796 残留

**现象**：重启实验后 MCP 服务器无法绑定端口，Agent 找不到 MCP 工具。

**根因**：前一次运行被 `taskkill` 强杀后，MCP 服务器的 daemon 线程未正常退出，多个 Python 进程仍监听 8796。

**修复**：
- `_ReuseHTTPServer` 使用 `allow_reuse_address = True`
- `_stop_mcp_server()` 在每次 `run_prompt` 结束后调用
- `server_close()` 立即关闭 socket，`shutdown()` 在后台线程执行

### 6.5 `shutdown()` 死锁

**现象**：Session 结束后，Python 进程在 `_stop_mcp_server()` 中卡死，无法进入下一个 session。

**根因**：`HTTPServer`（单线程）的 `serve_forever` 循环被 SSE handler 的无限 `while True: sleep(30)` 阻塞。`shutdown()` 设置标志后等待 `serve_forever` 退出，但后者永远无法检查该标志。

**修复**：
- 改用 `ThreadingMixIn`（`class _ReuseHTTPServer(ThreadingMixIn, HTTPServer)`），SSE handler 在独立线程中运行
- 设置 `daemon_threads = True`
- `_stop_mcp_server` 先调 `server_close()` 关 socket，再在后台线程调 `shutdown()`

### 6.6 分支创建逻辑缺陷

**现象**：`setup_branch` 从 `master` 创建 run 分支，导致 run 分支没有各组专用的 `program.md`。

**根因**：原 `init_run.sh` 从模板分支（`autoresearch/baseline` 等）创建分支并初始化 `results.tsv`。`run_experiment.py` 替代该脚本时遗漏了这两个逻辑。

**修复**：`setup_branch` 改为从 `autoresearch/{group}` 模板分支创建，并根据组类型初始化 `results.tsv` 列头（baseline 5 列，CT 组 8 列）。

---

## 7. 目录整理

原 `work_dir/experiment/` 目录有 20+ 个文件混杂在一起，分属三个"时代"。按以下方案整理：

| 操作 | 文件 | 目标 |
| ---- | ---- | ---- |
| 保留根目录 | `cursor_acp.py`、`run_experiment.py`、`run_experiment.sh`、`prompt_template.txt` | 核心代码，开箱即用 |
| 移动 + 重命名 | `program_baseline.md` 等 | `programs/baseline.md` 等 |
| 移动 | `README.md`、`agent_runbook.md` 等 | `docs/` |
| 移动 | pilot 相关 7 个文件 | `pilot/` |
| 删除 | `init_run.sh`、`run_iter.sh` | 逻辑已内化到 `run_experiment.py` |
| 删除 | `12`、`shell_mcp.py`、`test_acp.py`、`logs/*.log`、`__pycache__/` | 调试残留物 |

同步更新了 `docs/agent_runbook.md` 和 `docs/README.md` 中的路径引用。

---

## 8. 后续演化

### 近期

- **正式实验**：`python run_experiment.py round1 --max-iter 200` 启动 Round 1（3 组 × 3 次 = 9 runs，预计 ~7 天）
- **Terminal 频率监控**：如果 Agent 频繁触发 Terminal（浪费 30 秒/次），可考虑进一步加强 prompt 或尝试不同 model
- **训练超时**：当前 MCP `run_command` 超时 600 秒，训练 5 分钟 + 开销通常够用，但极端情况可能需要调整

### 长期

- **MCP stdio 传输**：如果 Cursor Agent 未来支持 `type: "stdio"` 的 MCP 服务器，可简化为进程内通信
- **多 GPU 并行**：当前架构是单 GPU 串行，如果有多卡可改为并行运行多个 run
- **结果分析自动化**：Round 1 完成后需要跨组统计分析，`analyze_pilot.py` 可扩展为正式分析脚本
