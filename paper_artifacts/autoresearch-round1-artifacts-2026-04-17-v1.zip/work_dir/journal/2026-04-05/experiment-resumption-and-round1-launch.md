# 实验断点续接加固与 Round 1 正式启动

> 日期：2026-04-05
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：功能实现 / 问题排查
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [问题分析](#2-问题分析)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [启动前检查](#5-启动前检查)
6. [Round 1 正式启动](#6-round-1-正式启动)
7. [后续演化](#7-后续演化)

---

## 1. 背景与动机

前序工作（同日另一篇日志 `self-contained-python-acp-client.md`）完成了：

- 纯 Python ACP 客户端 `cursor_acp.py`（替代 Node.js 版本）
- 内嵌 MCP Shell 服务器（绕过 Windows headless Terminal 不可用问题）
- 实验编排器 `run_experiment.py`
- Dry-run 验证通过（baseline 组 3 次迭代，~36 分钟）

**接下来的目标是启动正式 Round 1 实验**（3 组 × 3 次 = 9 runs，每 run 200 迭代，预计 ~7 天）。

在审视启动前的准备时，发现一个关键缺口：**中途中断后的断点续接机制不完善**。对于 7 天的长跑实验，中途中断几乎是必然会发生的（Windows 更新、电源故障、手动 Ctrl+C 调试等）。

---

## 2. 问题分析

### 已有的续接能力

| 层级 | 机制 | 可靠性 |
| ---- | ---- | ------ |
| Agent 层 | `program.md` 指示 Agent 读 `results.tsv` 确定当前状态 | 可靠 |
| Session 层 | `run_single()` 每次 session 前读 `results.tsv` 行数 | 可靠 |
| 分支层 | `setup_branch()` 检测分支是否存在，已有则 checkout | 可靠 |
| 日志 | `open(log_path, "a")` 追加模式 | 可靠 |

### 发现的缺口

**缺口 1：Round 级别编排无状态持久化**

`run_round1()` 是一个硬编码双层循环：

```python
for run_num in [1, 2, 3]:
    for group in ["baseline", "static-ct", "adaptive-ct"]:
        run_single(group, run_num, max_iter)
```

进程被杀后重启，会从头遍历全部 9 个 run。虽然已完成的 run 会因 `iter_count >= max_iter` 快速跳过，但没有显式的状态文件记录"跑到哪了"。

**缺口 2：无信号处理**

没有 `SIGINT` / `atexit` 处理。Ctrl+C 会导致：
- Agent 子进程变成孤儿
- MCP 服务器端口 8796 被占用
- `results.tsv` 可能写入半行数据

**缺口 3：无启动时清理**

重启实验时，上一次的残留进程（node.exe、Python MCP server）可能仍在运行，导致端口冲突或资源泄漏。

**缺口 4：`get_iter_count()` 不够健壮**

原实现用 `grep -c .` 计数，不完整行也会被计入。

---

## 3. 方案设计

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 状态持久化格式 | `round_state.json`（JSON） | 可读性好，stdlib 支持，原子写入简单 |
| 写入策略 | write-to-tmp + `os.replace()` | 原子替换，断电不会损坏 |
| 信号处理 | `SIGINT` + `atexit` | Windows 不支持 `SIGTERM`，两层防护 |
| 双击 Ctrl+C | 第二次强制 `os._exit(1)` | 防止卡死 |
| 残留清理 | `netstat -ano` 找端口 → `taskkill` | 保守策略，只杀占用 8796 的进程 |
| TSV 校验 | `awk -F'\t' 'NR>1 && NF>=4'` | 最少 4 列才算有效行 |

### 改动范围

仅涉及两个文件：

- `work_dir/experiment/run_experiment.py` — 主要改动（新增 ~129 行，200→329 行）
- `work_dir/experiment/cursor_acp.py` — 少量改动（新增 ~41 行，506→547 行）

---

## 4. 实现要点

### 4.1 Round 状态文件

新增三个函数：`load_round_state()`、`save_round_state()`、`update_run_status()`。

状态文件位于 `work_dir/experiment/logs/round_state.json`，结构：

```json
{
  "round": "round1",
  "max_iter": 200,
  "started_at": "2026-04-05T14:31:23",
  "run_order": ["baseline-1", "static-ct-1", "adaptive-ct-1", ...],
  "runs": {
    "baseline-1": {"status": "completed", "iterations": 200},
    "static-ct-1": {"status": "in_progress", "iterations": 87},
    "adaptive-ct-1": {"status": "pending", "iterations": 0}
  }
}
```

状态流转：`pending` → `in_progress` → `completed` / `interrupted`。

重启时加载状态文件，跳过 `completed` 的 run，从第一个非完成的 run 继续。

### 4.2 信号处理

```
Ctrl+C (SIGINT)
  → _on_shutdown() 设置 _shutdown_requested = True
  → run_single() 循环下一轮检查标志 → break
  → backup_results() + save_round_state()
  → finally 块正常清理

再次 Ctrl+C
  → _on_shutdown() 检测到已请求过 → os._exit(1) 强制退出

atexit
  → cursor_acp.cleanup() 兜底清理 agent 进程 + MCP 服务器
```

### 4.3 `cursor_acp.py` 新增内容

**残留进程清理**（`_cleanup_stale_processes()`）：

在 MCP 服务器启动前调用，用 `netstat -ano` 检测 LISTENING 在端口 8796 的进程，`taskkill /F /PID` 杀掉（排除自身 PID）。

**公开 cleanup() 函数**：

新增 `_Context._active` 类变量追踪当前活跃的上下文，`cleanup()` 函数停止 agent 进程和 MCP 服务器，供 `atexit` 调用。

**`run_prompt()` 改动**：

进入时设置 `_Context._active = ctx`，退出时清除。

### 4.4 可续接的 `run_round1()`

```python
def run_round1(max_iter=200):
    state = load_round_state("round1", max_iter, ROUND1_RUN_ORDER)
    pending = [k for k in state["run_order"]
               if state["runs"][k]["status"] != "completed"]
    _print(f"[round1] Remaining: {len(pending)} runs")

    for run_key in state["run_order"]:
        if _shutdown_requested:
            break
        if state["runs"][run_key]["status"] == "completed":
            _print(f"[skip] {run_key} already completed")
            continue
        group, run_num = run_key.rsplit("-", 1)
        update_run_status(state, run_key, "in_progress")
        completed = run_single(group, run_num, max_iter,
                               round_state=state, run_key=run_key)
        if completed:
            _print(f"Completed {run_key}")
        if _shutdown_requested:
            break
        time.sleep(10)
```

### 4.5 TSV 完整性校验

`get_iter_count()` 从 `grep -c .`（计任意非空行）改为 `awk -F'\t' 'NR>1 && NF>=4'`（只计至少 4 列的有效行），忽略空行和不完整行。

---

## 5. 启动前检查

在正式启动前，对全部关键依赖做了逐项验证：

| 检查项 | 状态 | 详情 |
| ------ | ---- | ---- |
| 模板分支 | PASS | WSL 仓库中 `autoresearch/baseline`、`autoresearch/static-ct`、`autoresearch/adaptive-ct` 均存在 |
| program.md 内容 | PASS | 三组各有独立的实验协议（Baseline / Static CT / Adaptive CT） |
| results.tsv | PASS | 模板分支上不含 results.tsv（由 `setup_branch()` 在创建 run 分支时初始化） |
| 端口 8796 | PASS | 无残留进程 |
| GPU | PASS | NVIDIA RTX 5090 D, 32GB VRAM, 30.9GB 空闲 |
| 磁盘 | PASS | WSL 文件系统 945GB 可用 |
| 训练数据 | PASS | `~/.cache/autoresearch/` 含 `data/` 和 `tokenizer/` 目录 |
| Dry-run 残留 | PASS | 无 e2e-test 分支残留，logs 目录已清空 |
| 仓库同步 | PASS | WSL 和 Windows 仓库 master HEAD 一致（`228791f`） |

### 注意事项

- **Windows 仓库没有模板分支**：但不影响运行——`setup_branch()` 通过 `wsl_cmd()` 在 WSL 仓库中操作 git，Cursor Agent 通过 `//wsl$/...` UNC 路径读写文件
- **命名不一致**：`run_experiment.py` 用连字符（`static-ct`），`programs/` 目录用下划线（`static_ct.md`），但 `programs/` 仅是本地参考副本，Agent 读的是 WSL 分支上的 `program.md`

---

## 6. Round 1 正式启动

### 启动命令

```bash
cd "D:\github\fork\autoresearch\work_dir\experiment"
python run_experiment.py round1 --max-iter 200
```

### 启动确认

```
================================================
  Round 1: 3 groups x 3 runs = 9 runs
  Started: 2026-04-05 14:31:23
================================================
[round1] Remaining: 9 runs — baseline-1, static-ct-1, adaptive-ct-1, ...

================================================================
  Experiment: baseline-1
  Max iterations: 200
  Log: D:\github\fork\autoresearch\work_dir\experiment\logs\baseline-1.log
  Started: 2026-04-05 14:31:23
================================================================
[setup] Creating branch autoresearch/baseline-1 from autoresearch/baseline...
[setup] Initialized results.tsv
[setup] On branch: autoresearch/baseline-1

--- Session 1 | Iterations: 0/200 | 14:31:26 ---
[agent] Sending prompt to Cursor Agent...
[cursor_acp] starting MCP shell server...
[cursor_acp] MCP server on port 8796
[cursor_acp] spawning agent...
[cursor_acp] agent pid=26644
[cursor_acp] initialize...
[cursor_acp] handshake ok
[cursor_acp] session: 61f7bdb2-300b-41...
```

Agent 成功启动后：
1. 读取 `program.md` → 理解 Baseline 实验协议
2. 检查 git 状态和 `results.tsv` → 确认是 fresh start
3. 读取 `train.py` 和 `prepare.py` → 理解代码
4. 开始首次训练 `uv run train.py > run.log 2>&1`

### 运行参数

| 参数 | 值 |
| ---- | -- |
| Run 顺序 | baseline-1 → static-ct-1 → adaptive-ct-1 → baseline-2 → ... → adaptive-ct-3 |
| 每 run 迭代上限 | 200 |
| Session 重试上限 | 50（每次重启重置） |
| MCP 命令超时 | 600 秒 |
| Agent idle 超时 | 300 秒 |
| Terminal 挂起检测 | 30 秒 |
| 状态文件 | `logs/round_state.json`（每次状态变更原子更新） |
| 备份频率 | 每 5 个 session + run 结束时 |

---

## 7. 后续演化

### 运行中监控

- **查看实时状态**：`type logs\round_state.json`
- **查看当前 run 日志**：`tail -f logs\baseline-1.log`（或对应 run 的 log 文件）
- **查看 Agent 进程**：`tasklist | findstr node`
- **优雅中断**：Ctrl+C（等当前 session 结束），再次 Ctrl+C 强制退出
- **从断点恢复**：重新运行 `python run_experiment.py round1 --max-iter 200`

### Round 1 完成后

- 跨组统计分析（扩展 `analyze_pilot.py` 为正式分析脚本）
- 结果可视化：三组的 BPB 曲线对比
- 论文写作：实验设计、结果、讨论

### 潜在风险

| 风险 | 应对 |
| ---- | ---- |
| Agent 频繁触发 Terminal 工具（浪费 30 秒/次） | 加强 prompt 或换 model |
| 训练超时（>600 秒） | 调大 MCP `run_command` 的 timeout 参数 |
| WSL 内存不足 | 监控 `free -h`，必要时重启 WSL |
| Git 仓库膨胀（200+ commit/run） | Round 1 完成后 squash 或 archive |
