# 安全中止、三处代码修复与 Round 1 断点续跑

> 日期：2026-04-06
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查 / 功能实现
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [问题分析](#2-问题分析)
3. [安全中止流程](#3-安全中止流程)
4. [代码修复](#4-代码修复)
5. [重启与验证](#5-重启与验证)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

Round 1 实验在 2026-04-05 启动后遭遇了双仓库问题和数据事故（详见 [dual-repo-fix-and-data-recovery](../2026-04-05/dual-repo-fix-and-data-recovery.md)）。修复 UNC 路径后实验重启，但运行中又暴露了三个新问题：

1. **baseline-1 在 154/200 迭代时提前终止**——不是目标达成，而是 `MAX_RETRIES=50` 耗尽
2. **分支切换时 results.tsv 会被覆盖**——untracked 文件在 `git checkout` 后不受保护
3. **备份间隔太疏**——每 5 个 session 才备份一次，中断时最多丢 4 个 session 的数据

需要在不丢失已有数据（baseline-1 共 154 行、static-ct-1 共 14 行）的前提下安全中止实验、修复代码、再断点续跑。

---

## 2. 问题分析

### 问题 1：MAX_RETRIES 不够

`run_single()` 的主循环上限是 `MAX_RETRIES=50`（即最多 50 个 Agent session）。baseline-1 的日志显示 50 个 session 平均只推进 ~3 次迭代（154/50 ≈ 3.08），而目标是 200 次。需要至少 ~67 个 session，50 不够。

```
baseline-1.log:
Session 50 | Iterations: 154/200 | ...
[stopped] baseline-1: 154 iterations, best BPB: 1.092322
```

### 问题 2：setup_branch 缺乏 results.tsv 保护

`setup_branch()` 在 `else` 分支（已有分支）中只执行 `git checkout`，没有保存/恢复 untracked 的 `results.tsv`。这导致了 2026-04-05 的数据事故（14 行被 1 行覆盖）。虽然事后做了手动恢复，但代码层面未修复。

```
# 修复前的逻辑
else:
    wsl_cmd(f"git checkout {branch}")   # results.tsv 被上一个分支的版本覆盖
```

### 问题 3：备份间隔过大

原代码每 5 个 session 才备份一次（`if attempt % 5 == 0`），session 间没有保护。中断时最多丢失 4 个 session（约 12 次迭代）的数据。

---

## 3. 安全中止流程

### 3.1 实时备份（不中断进程）

实验进程（PID 5872）仍在运行 static-ct-1 时，先做无损备份：

```bash
# WSL 内操作
cp results.tsv experiment_data/results_static-ct-1.tsv          # 备份 static-ct-1（14 行）
awk -F'\t' 'NR>1 && NF>=4' experiment_data/results_baseline-1.tsv | wc -l  # 确认 baseline-1 备份（154 行）
```

### 3.2 终止进程与清理残留

```bash
# Windows 侧
powershell -Command "Stop-Process -Id 5872 -Force"              # 主实验进程
powershell -Command "Stop-Process -Id 37576 -Force"             # 残留 cursor-agent node.exe

# WSL 侧
kill 235434 235438                                               # uv run train.py + python3 train.py
```

### 3.3 验证清理结果

| 检查项 | 结果 |
|--------|------|
| 主进程 PID 5872 | 已终止 |
| MCP 端口 8796 | 无 LISTENING |
| WSL train.py 进程 | clean |
| cursor-agent node.exe | 已终止（PID 37576） |
| results.tsv 行数 | 14（与备份一致） |
| baseline-1 备份行数 | 154（完整） |

---

## 4. 代码修复

全部改动在 `work_dir/experiment/run_experiment.py`，共 3 处。

### 修复 1：MAX_RETRIES 50 → 100

```python
# 第 37 行
MAX_RETRIES = 100    # 原值 50；baseline-1 实测 50 session 只跑了 154 次，200 次需要约 67 session
```

### 修复 2：setup_branch 加 results.tsv 保存/恢复

在 `else`（分支已存在）分支中，`git checkout` 前后加保护逻辑：

```python
else:
    # 保存当前分支的 results.tsv
    current = wsl_cmd("git branch --show-current").strip()
    if current.startswith("autoresearch/") and current != branch:
        cur_key = current.replace("autoresearch/", "", 1)
        wsl_cmd(f"mkdir -p experiment_data && "
                f"cp results.tsv experiment_data/results_{cur_key}.tsv 2>/dev/null")
        _print(f"[setup] Saved results.tsv for {cur_key}")

    _print(f"[setup] Switching to {branch}...")
    wsl_cmd(f"git checkout {branch}")

    # 恢复目标分支的 results.tsv
    backup = f"experiment_data/results_{group}-{run_num}.tsv"
    wsl_cmd(f"if [ -f {backup} ]; then cp {backup} results.tsv; fi")
    _print(f"[setup] Restored results.tsv for {group}-{run_num}")
```

### 修复 3：每个 session 后无条件备份

移除 `if attempt % 5 == 0` 条件，在 `run_prompt` 返回后立即备份：

```python
# 原来的条件备份（已删除）
# if attempt % 5 == 0:
#     backup_results(group, run_num)

# 现在：每个 session 结束后无条件备份
new_count = get_iter_count()
delta = new_count - iter_count
best = get_best_bpb()

backup_results(group, run_num)
_print(f"[backup] results.tsv backed up ({new_count} rows)")
```

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| MAX_RETRIES 值 | 100 | 实测平均 3 次/session，200 目标需 ~67 session，100 留够余量 |
| 备份时机 | 每 session 后 | results.tsv 是唯一的实验数据载体，无条件备份代价低（一次 cp 约 0.5s） |
| 保存恢复的 key | `experiment_data/results_{group}-{run_num}.tsv` | 与现有备份命名一致，无需新增目录结构 |

---

## 5. 重启与验证

### 启动命令

```bash
cd D:\github\fork\autoresearch\work_dir\experiment
python run_experiment.py round1 --max-iter 200
```

### 验证点

| 验证项 | 期望 | 实际 | 通过 |
|--------|------|------|------|
| round_state.json 加载 | Resumed from... | `[state] Resumed from ...round_state.json` | YES |
| static-ct-1 results.tsv 被保存 | Saved results.tsv for static-ct-1 | `[setup] Saved results.tsv for static-ct-1` | YES |
| 切换到 baseline-1 | Switching to autoresearch/baseline-1 | `[setup] Switching to autoresearch/baseline-1...` | YES |
| baseline-1 results.tsv 恢复 | Restored results.tsv for baseline-1 | `[setup] Restored results.tsv for baseline-1` | YES |
| 迭代数断点续接 | Iterations: 154/200 | `Session 1 \| Iterations: 154/200` | YES |
| Agent 正常工作 | Read File + MCP tool 调用 | 日志可见读文件、执行 shell | YES |
| 数据增长 | >154 | 157（检查时已增长 3 行） | YES |

### round_state.json 状态

```json
{
  "round": "round1",
  "runs": {
    "baseline-1": { "status": "in_progress", "iterations": 156 },
    "static-ct-1": { "status": "in_progress", "iterations": 14 },
    "adaptive-ct-1": { "status": "pending", "iterations": 0 },
    ...
  }
}
```

### 最终状态

| 项目 | 值 |
|------|------|
| 实验进程 | PID 27960，后台运行中 |
| 当前 run | baseline-1，157/200 迭代 |
| baseline-1 最佳 BPB | 1.092322 |
| 下一个 run | static-ct-1（14 次迭代已备份） |
| 代码版本 | MAX_RETRIES=100 + setup_branch 保护 + 每 session 备份 |

---

## 6. 后续演化

1. **观察 baseline-1 → static-ct-1 自动切换**：baseline-1 跑满 200 后，setup_branch 应自动保存 baseline-1 的 results.tsv、恢复 static-ct-1 的 14 行。这是修复 2 的端到端验证。
2. **考虑 results.tsv 纳入 git 管理**：当前设计为 untracked，依赖 `experiment_data/` 备份。如果改为 tracked，分支切换时 git 自动保护，无需手动保存/恢复。但需评估对实验 commit 历史的影响。
3. **增加 round_state.json 的 iterations 更新频率**：目前仅在 session 开始时更新，可以在 backup_results 同时更新。
