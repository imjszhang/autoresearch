# baseline-1 实验结果分析（200 迭代完成）

> 日期：2026-04-06
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：调研分析
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [总体统计](#2-总体统计)
3. [BPB 改进轨迹](#3-bpb-改进轨迹)
4. [发现的问题](#4-发现的问题)
5. [关键观察与结论](#5-关键观察与结论)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

baseline-1 是 Round 1 的第一个 run，已于 2026-04-06 跑满 200 次迭代并标记为 `completed`。该 run 使用纯 baseline 配置（无 cyber-taoist 策略指导），Agent 自主探索超参数和架构变更，通过单次 300 秒训练的 `val_bpb` 来决定 keep/discard。

需要在 static-ct-1 还在跑的时候，回顾 baseline-1 的数据，识别异常模式和潜在问题，为后续 run 解读提供参照基线。

数据来源：`experiment_data/results_baseline-1.tsv`（200 行有效数据），不涉及正在运行的实验文件。

---

## 2. 总体统计

| 指标 | 值 |
|------|------|
| 总迭代 | 200 |
| keep（被保留的改进） | 8（4.0%） |
| discard（被丢弃的尝试） | 184（92.0%） |
| crash（崩溃/中断） | 8（4.0%） |
| 起始 BPB | 1.263888（baseline） |
| 最终最佳 BPB | 1.084914（commit `87faa61`） |
| 总改进幅度 | -14.2% |

### BPB 分布（不含 crash）

| 区间 | 数量 | 比例 |
|------|------|------|
| < 1.09 | 63 | 32.8% |
| 1.09 – 1.10 | 44 | 22.9% |
| 1.10 – 1.15 | 61 | 31.8% |
| 1.15 – 1.20 | 16 | 8.3% |
| > 1.20 | 8 | 4.2% |

---

## 3. BPB 改进轨迹

8 次 keep 中有 7 次是真正的 BPB 改进，1 次是工具修复（perf_counter 计时）：

| 迭代 | Commit | val_bpb | 改进幅度 | 描述 |
|------|--------|---------|---------|------|
| #1 | `154a63f` | 1.263888 | — | baseline 起点 |
| #2 | `be5e774` | 1.166651 | -7.7% | WINDOW_PATTERN L（全层 full attention） |
| #3 | `f747cd8` | 1.154733 | -1.0% | EMBEDDING_LR 0.6→0.75 |
| #6 | `3b82faa` | 1.092322 | -5.4% | 重新启用 torch.compile |
| #77 | `8a38bbd` | 1.144435 | — | perf_counter 计时修复（非 BPB 改进） |
| #78 | `2a9bbde` | 1.087996 | -0.4% | VE gate channels 32→40 |
| #79 | `d1aa769` | 1.087667 | -0.04% | VE gate channels 40→44 |
| #82 | `87faa61` | 1.084914 | -0.3% | SCALAR_LR 0.5→0.45 |

### 两阶段特征

- **快速改进期（#1 – #6）**：6 次迭代，BPB 从 1.264 降到 1.092（-13.6%）。核心改动是架构级（full attention、torch.compile）和关键超参（EMBEDDING_LR）。
- **微调停滞期（#7 – #200）**：194 次迭代，仅改进 1.092→1.085（-0.7%）。**最后一次真正改进在 #82，之后 118 次迭代（59%）零进展。**

---

## 4. 发现的问题

### 问题 1：微调陷阱（Micro-tuning Trap）

迭代 #82 之后，Agent 陷入对超参做极小调整的循环（如 `MATRIX_LR 0.04→0.04003`、`SCALAR_LR 0.45→0.4508`），所有尝试均被 discard。118 次迭代全部失败，说明 Agent 缺乏跳出局部最优的策略。

典型模式（后 50 次迭代的描述摘录）：

```
MATRIX_LR 0.04->0.04008 micro bump
MATRIX_LR 0.04->0.0399 micro (Muon interp)
MATRIX_LR 0.04->0.0401 micro bump
VE_GATE_SCALE 2.0->1.995
VE_GATE_SCALE 2.0->2.005
```

### 问题 2：训练吞吐量波动

正常 run 约 350 步/300 秒，但部分 run 出现严重降速：

| 迭代 | 实际步数 | BPB | 描述 |
|------|---------|-----|------|
| #87 | ~171 | 1.194 | EMBEDDING_LR 微调，训练步数不足正常的一半 |
| #86 | ~198 | 1.162 | UNEMBEDDING_LR 微调，noisy throughput |
| #105 | ~45 | 1.708 | Muon momentum ramp 400 步，严重降速 |
| #107 | ~45 | 1.702 | VE gate 45，同一 artifact |
| #117 | ~170 | 1.195 | RoPE base 微调，slow run |

这些 run 的 BPB 偏高是因为训练不充分（步数不够），而非改动本身差。Agent 正确地 discard 了它们，但浪费了实验预算。吞吐量波动可能是 GPU 热降频、后台进程干扰或 `torch.compile` 缓存问题。

### 问题 3：8 次 Crash（4% 崩溃率）

| 迭代 | 原因 |
|------|------|
| #20 | residual dropout 0.1 → CUDA OOM |
| #22 | MAX_GRAD_NORM clip + torch.compile → OOM |
| #23 | label smoothing + compiled forward → OOM |
| #43 | ASPECT_RATIO 65 → n_head=5 dynamo error |
| #157 | torch.compile max-autotune → autotune timeout |
| #177 | UNEMBEDDING_LR run 被中断（重复训练进程） |
| #184 | learnable RMSNorm → train loss stuck（无学习） |
| #186 | MATRIX_LR run 被中断（session timeout + 重复训练进程） |

多数 crash 与 `torch.compile` 的兼容性有关。两次（#177、#186）是进程管理问题（重复 train 进程未清理）。

### 问题 4：可复现性差距

迭代 #185 尝试精确复现最佳配置 `87faa61`，结果：

| | 原始 (87faa61) | 复现 (9c2d2bf) | 差异 |
|---|---|---|---|
| val_bpb | 1.084914 | 1.093068 | +0.75% |
| 步数 | ~350 | 336 | -4% |

同一 `train.py`、同一硬件的 run-to-run 方差约 0.8%。这意味着 **BPB 差异 < ~0.008 的比较没有统计意义**——而后期大量微调尝试的 BPB 差距恰好在这个范围内。

### 问题 5：重复 BPB 值

19 组重复 BPB（部分样本）：

| BPB | 出现次数 | 说明 |
|-----|---------|------|
| 1.148341 | 3× | iter #12–14，三个不同改动得到相同 BPB |
| 1.133760 | 3× | iter #25–26，两个不同超参得到相同 BPB |
| 1.089011 | 3× | iter #143–145 |
| 1.801284 | 2× | iter #4–5，早期两个探索 |

完全相同的 BPB 出现在不同改动上，可能是：训练未充分收敛就输出了 checkpoint 的 val_bpb；或 run.log 解析到了上一次的残留值。

---

## 5. 关键观察与结论

### 关键决策

| 观察 | 影响 | 建议 |
| ---- | ---- | ---- |
| 最后 59% 迭代零改进 | 58.5% 实验预算浪费 | 需要 stagnation 检测——连续 N 次失败后切换到更大胆的探索 |
| 0.8% run-to-run 方差 | 微调在噪声中无法区分 | BPB 改进阈值应 ≥ 0.01（约 1%） |
| 4% crash 率 | 每 25 次迭代 1 次崩溃 | torch.compile 兼容性需 pre-check 或 fallback |
| 吞吐量波动 | 部分 run 训练不充分 | 可考虑按步数而非时间终止训练 |
| 重复 BPB | 结果可能不反映实际改动效果 | run.log 解析逻辑需检查是否读到残留值 |

### baseline-1 最终配置（commit `87faa61`）相对 baseline 的核心改动

1. **WINDOW_PATTERN L**（全层 full attention）
2. **EMBEDDING_LR 0.75**（从 0.6 提升）
3. **torch.compile**（重新启用）
4. **VE gate channels 44**（从 32 增加）
5. **SCALAR_LR 0.45**（从 0.5 下调）

总计 BPB 从 **1.264 → 1.085**，改进 **14.2%**，全部来自 8 次 keep 中的 7 次真正改进。

---

## 6. 后续演化

1. **static-ct-1 / adaptive-ct-1 对比**：这两个 run 使用 cyber-taoist 策略指导，观察它们是否能更高效地探索（更少迭代达到同等 BPB，或跳出微调陷阱）。
2. **stagnation 检测机制**：如果连续 30+ 次 discard 且 BPB 差距 < 0.01，prompt 中可以提示 Agent 切换到架构级探索。
3. **训练步数归一化**：用步数/BPB 而非纯时间预算来控制训练，减少吞吐量波动的影响。
4. **run.log 解析审计**：检查重复 BPB 值是否因 log 文件残留导致。
