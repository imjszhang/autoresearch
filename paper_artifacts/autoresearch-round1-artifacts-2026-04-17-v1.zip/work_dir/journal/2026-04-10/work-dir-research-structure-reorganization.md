# `work_dir` 研究目录重组与资料迁移整理

> 日期：2026-04-10
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：架构设计 / 升级迁移 / 调研分析
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

本轮实验推进过程中，`work_dir/docs` 逐渐暴露出一个典型问题：目录名过于宽泛，既装原始理论文本，也装论文稿、设计草案、环境说明和临时设想，导致文档职责混杂，后续引用越来越不清楚。

在实际讨论中，逐步形成了几个共识：

- 研究资料不应继续按笼统的“docs”聚合；
- 应按研究职责分层，而不是按“想到什么就放哪”来堆积；
- 需要保留一个临时入口，用来承接尚未归类、但确定属于本次研究的内容；
- 迁移应尽量安全，优先采用“复制迁移、保留原件”的方式，避免一次性破坏原始资料入口。

因此，本次工作的目标不是简单改名，而是为 `work_dir` 建立一套可持续使用的研究目录结构，并把原来散放在 `docs/` 中的核心资料迁移到更合适的位置。

## 2. 分析过程

### 原始问题识别

最初的 `work_dir/docs` 中包含至少以下几类不同性质的文档：

| 文件 | 主要内容 | 问题 |
| ---- | ---- | ---- |
| `CONSTITUTION.md` | 理论原文 | 与论文稿、草案平放，不利于作为稳定理论基准 |
| `paper.md` | 论文主稿 | 与原始理论和临时想法混放，职责不清 |
| `idea.md` | 方向性提案 | 名称过泛，难以判断是否为研究设计、灵感还是方法稿 |
| `paper_idea*.md` | 论文设计草稿 | 和正式稿关系不清，版本语义不明确 |
| `skill.md` | 理论应用指南 | 与理论原文相关，但不属于同一种文档角色 |
| `wsl_guide.md` | 环境与运行说明 | 实际上更接近实验运行资产，而不是研究论文文档 |

这说明问题不在于“文件太多”，而在于“目录语义太弱”。

### 讨论中形成的分层思路

在多轮讨论后，研究资料被抽象成几类稳定角色：

1. 理论源文件；
2. 研究设计与方法；
3. 论文稿件；
4. 实验运行资产；
5. 过程记录。

同时又意识到，现实中总会不断出现“暂时不知道如何归类”的内容，因此还需要保留一个临时入口，用于先收纳、后判断。

### 最终转向 `inbox` 思路

一开始讨论的是是否彻底废弃 `docs/`。后续进一步明确：

- `docs` 这个名字本身过于宽泛；
- 但“临时入口”这个角色客观存在，不能消失；
- 因此更合适的做法不是保留 `docs/`，而是把它改造成语义更清晰的 `inbox/`。

`inbox/` 的定位因此被确定为：

- 待分拣入口；
- 原始资料备份区；
- 暂时不知道如何归类、但确定与本次研究相关的内容的收纳位置。

## 3. 方案设计

本次目录整理采用“**新结构承接正式工作，`inbox/` 保留入口和备份角色**”的策略。

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 顶层文档目录是否继续使用 `docs/` | 否 | 名称过宽，无法表达研究职责 |
| 是否保留临时入口 | 是，改名为 `inbox/` | 现实中仍需要一个先收纳后归类的位置 |
| 迁移策略 | `copy_only` | 先复制到正式目录，保留 `inbox/` 原件，风险最低 |
| 理论原文去向 | `foundations/` | 作为稳定基准文件，便于引用 |
| 研究设计去向 | `research_design/` | 用于承接方向性提案、设计说明与方法草案 |
| 论文稿去向 | `manuscript/` | 将正文与设计稿统一放入稿件区 |
| 环境说明去向 | `experiment/` | 更接近实验运行资产，不应留在理论/论文目录中 |
| 是否记录迁移状态 | 是，新增 `inbox-migration-status.json` | 明确哪些文件已归位，避免反复判断 |

### 新结构的核心语义

| 目录 | 语义 |
| ---- | ---- |
| `foundations/` | 理论源文件、稳定基础材料 |
| `research_design/` | 研究问题、设计方案、方法草案 |
| `manuscript/` | 论文主稿、设计稿、写作草稿 |
| `experiment/` | 运行脚本、日志、环境说明、辅助工具 |
| `journal/` | 按日期归档的过程记录与复盘 |
| `inbox/` | 待分拣入口与原始资料备份区 |

## 4. 实现要点

### 项目结构

```text
work_dir/
├── foundations/
│   ├── constitution.md
│   └── application-guide.md
├── research_design/
│   └── cyber-taoist-application-directions.md
├── manuscript/
│   ├── paper.md
│   ├── paper-design-notes.md
│   └── paper-design-notes-v1.md
├── experiment/
│   ├── run_experiment.py
│   ├── cursor_acp.py
│   ├── logs/
│   └── wsl-environment-guide.md
├── journal/
│   └── 2026-04-10/
│       ├── round1-first-three-runs-checkpoint.md
│       ├── constitution-theory-reflection-on-adaptive-ct.md
│       └── work-dir-research-structure-reorganization.md
├── inbox/
├── inbox-migration-status.json
└── README.md
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/README.md` | 定义 `work_dir` 顶层目录职责、命名原则与推荐工作流 |
| `work_dir/inbox-migration-status.json` | 记录 `inbox` 中文件迁移到正式目录的目标与状态 |
| `work_dir/foundations/constitution.md` | 当前使用的理论基础文本 |
| `work_dir/foundations/application-guide.md` | 理论应用指南，与宪章形成“原理 + 用法”配对 |
| `work_dir/research_design/cyber-taoist-application-directions.md` | 方向性设计文档 |
| `work_dir/manuscript/paper.md` | 论文主稿 |
| `work_dir/manuscript/paper-design-notes*.md` | 论文设计过程中的中文方案草稿 |
| `work_dir/experiment/wsl-environment-guide.md` | WSL 实验环境与运行指南 |

### 实际迁移映射

本轮已经完成的正式副本迁移如下：

| 原入口文件 | 新位置 |
| ---- | ---- |
| `work_dir/inbox/CONSTITUTION.md` | `work_dir/foundations/constitution.md` |
| `work_dir/inbox/idea.md` | `work_dir/research_design/cyber-taoist-application-directions.md` |
| `work_dir/inbox/paper.md` | `work_dir/manuscript/paper.md` |
| `work_dir/inbox/paper_idea.md` | `work_dir/manuscript/paper-design-notes.md` |
| `work_dir/inbox/paper_idea_v1.md` | `work_dir/manuscript/paper-design-notes-v1.md` |
| `work_dir/inbox/skill.md` | `work_dir/foundations/application-guide.md` |
| `work_dir/inbox/wsl_guide.md` | `work_dir/experiment/wsl-environment-guide.md` |

### 本轮同步调整

在完成目录重组后，又补做了几项同步收口工作：

1. 将 `work_dir/docs` 正式改名为 `work_dir/inbox`；
2. 更新 `work_dir/README.md`，补充目录职责、推荐工作流和迁移清单入口；
3. 检查 `journal/` 与 `experiment/` 中是否仍引用旧 `docs/` 路径；
4. 将 `journal/` 中相关文档引用更新为新位置，尤其是：
   - `work_dir/manuscript/paper.md`
   - `work_dir/foundations/constitution.md`

## 5. 验证与测试

### 已验证事实

| 验证项 | 结果 |
| ---- | ---- |
| `work_dir/docs` 已改名为 `work_dir/inbox` | 是 |
| `inbox` 中全部 7 份核心文件均已有正式副本 | 是 |
| `inbox-migration-status.json` 已记录所有迁移映射 | 是 |
| `work_dir/README.md` 已反映新目录语义 | 是 |
| `journal/` 中旧 `docs/` 路径引用已清理 | 是 |
| `experiment/` 中无旧 `docs/` 路径引用 | 是 |

### 当前状态检查

根据 `inbox-migration-status.json`，当前采用的策略为：

- `strategy = copy_only`
- `note = 保留 inbox 原件作为备份；新目录中的副本作为后续正式工作位置。`

这意味着：

- `inbox/` 仍保留原始入口文件；
- 正式编辑与引用应优先指向新目录中的文件；
- `inbox/` 当前不是“未迁移区”，而是“入口 + 备份区”。

### 质量检查

本轮新建与更新的 Markdown/JSON 文件都进行了快速诊断检查，未发现明显问题。

## 6. 后续演化

### 短期建议

- 以后新增研究资料，优先遵循 `inbox -> 判断 -> 迁移` 的工作流；
- 对正式引用，尽量直接使用新目录中的文件路径，不再引用 `inbox/` 原件；
- 若某篇文档已经在正式目录稳定维护，应避免继续把它的修改回写到 `inbox/` 原始副本。

### 中期建议

- 当 `inbox/` 中出现新文件时，定期检查其是否已经完成归类；
- 若后续 `research_design/` 或 `manuscript/` 继续膨胀，可再进一步拆分子目录；
- 可考虑在未来给 `README.md` 补一个“当前核心文件索引”，让 `work_dir` 更像统一研究入口。

### 当前阶段结论

1. 本轮目录整理已经把 `work_dir` 从“宽泛文档堆积区”转成了“按研究职责分层的工作区”。
2. `inbox/` 的引入解决了“现实中总会有暂时无法归类的内容”这一问题。
3. 通过 `copy_only` + `inbox-migration-status.json`，迁移过程兼顾了安全性与可追踪性。
4. 目录重构已经不仅是结构调整，还包括对说明文档、journal 引用和工作流约定的同步收口。

---
