# Round 1 前三次 Run 完成阶段检查

> 日期：2026-04-10
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：调研分析
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

Round 1 预定共执行 9 个 run，顺序为：

1. `baseline-1`
2. `static-ct-1`
3. `adaptive-ct-1`
4. `baseline-2`
5. `static-ct-2`
6. `adaptive-ct-2`
7. `baseline-3`
8. `static-ct-3`
9. `adaptive-ct-3`

截至 2026-04-10 下午，前三个 run 已全部完成，实验已自动进入 `baseline-2`。需要在中途做一次阶段检查，确认：

- 前三个 run 的完成情况；
- 当前最好结果落在哪个策略上；
- 修复过的 WSL 僵尸进程防护是否在长时间运行中生效；
- 后续 6 个 run 还有多少实验预算待消耗。

> 注：本文只记录阶段事实、进度与稳定性观察；围绕 `work_dir/manuscript/paper.md` 与 `work_dir/foundations/constitution.md` 的理论对照，另见 `constitution-theory-reflection-on-adaptive-ct.md`。

---

## 2. 分析过程

### 当前 round 状态

直接读取 `work_dir/experiment/logs/round_state.json`，当前状态如下：

| Run | 状态 | 迭代数 |
|-----|------|--------|
| `baseline-1` | completed | 200 |
| `static-ct-1` | completed | 203 |
| `adaptive-ct-1` | completed | 201 |
| `baseline-2` | in_progress | 147 |
| `static-ct-2` | pending | 0 |
| `adaptive-ct-2` | pending | 0 |
| `baseline-3` | pending | 0 |
| `static-ct-3` | pending | 0 |
| `adaptive-ct-3` | pending | 0 |

可以确认：

- **前三个 run 确实已跑完**；
- `adaptive-ct-1` 最终停在 **201**，与此前 `static-ct-1` 的 **203** 一样，说明 `max_iter=200` 在当前 runner 中仍然是“软上限”；
- 当前正在运行的是 **`baseline-2` 第 147 / 200 次迭代**。

### 前三个 run 的阶段结果

结合已有分析日记与恢复记录，可以得到前三个 run 的关键结果：

| Run | 迭代 | 最佳 BPB | 备注 |
|-----|------|----------|------|
| `baseline-1` | 200 | **1.084914** | 无策略基线，后期停滞明显 |
| `static-ct-1` | 203 | **1.070910** | 当前前三者中最优，BREAK 驱动效果最强 |
| `adaptive-ct-1` | 201 | **1.094849** | 完成了全程自适应实验，但最终劣于前两者 |

### 运行稳定性观察

从长期运行终端日志看，修复后的 runner 已连续推进多个 session。`baseline-2` 的会话记录中已经出现：

- `"[cleanup] Killing 2 orphaned wsl.exe process(es)..."`；
- session 间 `results.tsv` 持续被 backup；
- `baseline-2` 从 123、125、129、132、134、136、138、141、144 推进到 **147**。

这说明新加的 **WSL 僵尸清理逻辑不是空转**，而是真正清理到了会在长时运行中积累的残留进程。

---

## 3. 方案设计

本次阶段检查采用“轻量检查、不中断实验”的方式，不去直接碰 WSL 内训练进程，只读取 Windows 侧状态文件与终端快照。

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 状态来源 | `round_state.json` + 终端快照 | 这两者都在 Windows 侧，读取安全，不会打断训练 |
| 不直接查 WSL `results.tsv` | 只在必要时才查 | 避免新增 `wsl.exe` 调用，与正在运行实验竞争资源 |
| 阶段总结范围 | 只覆盖前三个 run + 当前 `baseline-2` | 用户关注的是“已经跑完 3 个 run”的阶段状态，不需要提前展开后续 6 个 run |
| 指标呈现 | 以 run 级结果为主，少量加入稳定性信息 | 阶段总结重点是整体走向，而不是逐迭代细节 |

---

## 4. 实现要点

### 项目结构

```text
work_dir/
├── experiment/
│   ├── logs/
│   │   ├── round_state.json
│   │   ├── adaptive-ct-1.log
│   │   └── ...
│   ├── run_experiment.py
│   └── cursor_acp.py
└── journal/
    ├── 2026-04-06/baseline-1-results-analysis.md
    ├── 2026-04-08/static-ct-1-results-analysis.md
    ├── 2026-04-09/wsl-zombie-fix-and-experiment-recovery.md
    └── 2026-04-10/round1-first-three-runs-checkpoint.md
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/experiment/logs/round_state.json` | 记录 Round 1 各 run 的状态与迭代数 |
| `work_dir/experiment/run_experiment.py` | round 调度、session 循环、backup 与恢复控制 |
| `work_dir/experiment/cursor_acp.py` | ACP client 与本地 MCP shell server |
| `work_dir/journal/2026-04-06/baseline-1-results-analysis.md` | baseline-1 结果分析 |
| `work_dir/journal/2026-04-08/static-ct-1-results-analysis.md` | static-ct-1 结果分析 |
| `work_dir/journal/2026-04-09/wsl-zombie-fix-and-experiment-recovery.md` | 第二次中断、修复与恢复记录 |

### 当前阶段结论

1. **`static-ct-1` 目前是绝对领先者**  
   在前三个 run 中，`static-ct-1` 的最佳 BPB **1.070910** 明显好于 `baseline-1` 的 **1.084914** 和 `adaptive-ct-1` 的 **1.094849**。

2. **`adaptive-ct-1` 的可观测结果暂未体现优势**  
   就当前阶段结果看，`adaptive-ct-1` 不仅未超过 `static-ct-1`，也未超过 `baseline-1`。关于这一现象的理论解释，需与 `work_dir/manuscript/paper.md` 和 `work_dir/foundations/constitution.md` 联动分析，不在本文展开。

3. **WSL 防护修复已进入“真实验证期”**  
   `adaptive-ct-1` 完成后，runner 没有再次因资源泄漏中断，而是顺利推进到 `baseline-2` 的 147 迭代，说明修复至少在首个长时间窗口内有效。

---

## 5. 验证与测试

### 已验证事实

| 验证项 | 结果 |
|--------|------|
| 前三个 run 已全部完成 | 是 |
| 当前正在运行 `baseline-2` | 是 |
| `baseline-2` 当前进度 | 147 / 200 |
| WSL 僵尸清理日志出现 | 是 |
| runner 仍在运行 | 是 |

### 阶段性数字汇总

| 维度 | 数值 |
|------|------|
| 已完成 run 数 | 3 / 9 |
| 当前进行中 run | `baseline-2` |
| 剩余完整 run | 5 个待开始 + 1 个进行中 |
| Round 1 已完成迭代 | 200 + 203 + 201 + 147 = **751** |
| Round 1 总目标迭代（按 9×200 估算） | **1800** |
| 当前理论完成度 | **约 41.7%** |

> 注：这里按每个 run 目标 200 次迭代粗略估算；实际由于软上限，最终总迭代数可能略高于 1800。

---

## 6. 后续演化

### 短期关注点

- **`baseline-2` 是否能逼近或超越 `baseline-1`**：这是验证 run-to-run 方差的重要样本；
- **修复后的 runner 能否连续跑完整个 Round 1**：真正的考验不在 `adaptive-ct-1` 收尾，而在后续还有约 1000+ 迭代待执行；
- **static-ct 是否具备稳定优势**：若 `static-ct-2`、`static-ct-3` 仍持续领先，可基本确认 static 规则在当前实验设置下优于 adaptive。

### 中期建议

- 在 `baseline-2`、`static-ct-2`、`adaptive-ct-2` 都完成后，再做一次 **中场汇总**，比较“第二轮三组”的稳定性与方差；
- 针对 `Adaptive-CT` 暂未体现优势这一点，单独维护理论反思文档，避免把阶段事实与理论解释混写；
- 等 Round 1 全部结束后，补写一篇 **Round 1 总结日记**，统一比较 9 个 run 的最优值、keep/crash 率、尾部浪费与策略收益。

---

