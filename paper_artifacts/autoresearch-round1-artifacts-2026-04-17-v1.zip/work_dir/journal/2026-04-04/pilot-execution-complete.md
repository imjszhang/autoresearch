# Cyber-Taoist Pilot 预实验：三组完整执行与分析

> 日期：2026-04-04
> 项目：autoresearch / cyber-taoist
> 类型：功能实现 / 调研分析
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [关键洞察与讨论](#6-关键洞察与讨论)
7. [后续演化](#7-后续演化)

---

## 1. 背景与动机

### 前置工作

本次工作是 Cyber-Taoist 实验管道的第三阶段。前两个阶段已在同日完成：

| 阶段 | 日志 | 内容 |
|------|------|------|
| 阶段 1 | `cyber-taoist-paper-and-wsl-setup.md` | 论文四层论证 + WSL2/RTX 5090 D 环境适配 |
| 阶段 2 | `experiment-setup-and-theory-mapping.md` | 实验设计 + CT 理论映射 + program.md 三变体 |
| 阶段 3（本篇） | 本文 | Pilot 预实验执行 + 跨组分析 + 方法论反思 |

### 动机

在阶段 2 中，我们设计了三组实验（Baseline / Static-CT / Adaptive-CT），编写了对应的 `program.md`、初始化脚本、验证脚本和分析脚本。但这些都还停留在"设计"层面——没有实际跑过。

Pilot 预实验的目的不是得出"哪个框架更好"的结论，而是：

1. **验证管道完整性**：train.py → run.log → results.tsv → git keep/discard 的闭环
2. **暴露脚本 bug**：在短运行中发现并修复问题
3. **校准时间估算**：测量每次迭代实际耗时，规划 200 迭代正式实验
4. **建立数据分析基线**：确认 `validate_pilot.sh` 和 `analyze_pilot.py` 能正确处理数据

---

## 2. 分析过程

### 2.1 三组 program.md 的差异

| 特性 | Baseline | Static-CT | Adaptive-CT |
|------|----------|-----------|-------------|
| 决策框架 | 无 | 固定 δ 阈值 | 自适应 δ 阈值 |
| results.tsv 列数 | 5 列 | 8 列 (含 δ/strategy/rationale) | 8 列 |
| θ_guard / θ_break | N/A | 0.3 / 0.7（固定） | 0.3 / 0.7（初始），每 50 迭代调参 |
| 策略集 | 自由探索 | GUARD / BREAK / SIMPLIFY | GUARD / BREAK / SIMPLIFY / ADAPT |
| δ 公式 | N/A | 0.5·S + 0.3·RR + 0.2·(1-ID) | 同 Static-CT |

### 2.2 Pilot 执行策略

由于 pilot 是**脚本自动化执行**（不是真正的 AI agent），需要：
- 预编程修改序列（每组 14 个超参调整 + 1 个 baseline）
- 对 CT 组：动态计算 δ 并选择策略，从对应策略的修改池中取下一个
- 共用 `run_iter.sh` 辅助脚本处理 commit → train → log → keep/discard 的内循环

### 2.3 修改池设计

三组使用相似的超参修改空间以保证可比性：

| 修改类型 | 涵盖的超参 | 对应策略 |
|----------|-----------|----------|
| 增量调整 | MATRIX_LR, EMBEDDING_LR, WEIGHT_DECAY, warmdown, Adam betas | GUARD |
| 架构变革 | 激活函数(SiLU), MLP扩展(6x), depth, ASPECT_RATIO, batch size | BREAK |
| 复杂度简化 | WINDOW_PATTERN, HEAD_DIM, 去warmdown, 降depth | SIMPLIFY |

---

## 3. 方案设计

### 3.1 执行架构

```
Windows (Git Bash)
  └── wsl -d Ubuntu-24.04 -- bash -c "..."
       ├── run_baseline_pilot.sh      # Baseline: 固定序列，无 δ
       ├── run_adaptive_ct_pilot.sh   # Adaptive-CT: 动态 δ + 策略选择
       └── run_iter.sh                # 共用内循环：commit → train → log
```

### 3.2 关键决策

| 决策 | 选择 | 理由 |
|------|------|------|
| Pilot 迭代数 | 15 | 足够验证管道，不够触发 Adaptive-CT 调参（需 50 迭代） |
| 执行方式 | 脚本自动化（非 AI agent） | Pilot 目的是验证基础设施，不是验证框架效果 |
| 修改策略 | 预编程修改池 + 策略映射 | 保证 δ→策略→修改的逻辑链完整 |
| 结果保存 | `pilot_data/results_<group>_pilot-1.tsv` | 避免 untracked `results.tsv` 在分支切换时丢失 |

### 3.3 脚本设计

#### run_iter.sh（共用内循环）

```bash
# 接口: bash run_iter.sh "<description>" "<delta>" "<strategy>" "<rationale>"
# 功能:
#   1. git add + commit train.py
#   2. uv run train.py > run.log
#   3. 解析 val_bpb 和 peak_vram_mb
#   4. 比较最佳 BPB → keep 或 discard
#   5. discard 时 git reset --hard HEAD~1
#   6. 追加到 results.tsv
```

#### run_baseline_pilot.sh

- 固定 15 个修改的执行顺序
- 5 列 results.tsv（无 δ/strategy/rationale）
- 每次修改用 `sed -i` 直接操作 train.py

#### run_adaptive_ct_pilot.sh

- 动态 δ 计算（`compute_delta` 函数，纯 awk 实现）
- 策略选择（`choose_strategy` 函数，基于当前 θ 值）
- 修改池分三个策略桶（GUARD/BREAK/SIMPLIFY），循环使用
- 8 列 results.tsv

---

## 4. 实现要点

### 4.1 Static-CT 执行（由前一个对话完成）

- **时间**: ~85 分钟，15 迭代
- **结果**: BPB 1.1955 → 1.1239（改善 6.0%）
- **Keep**: 4/15（baseline + MATRIX_LR + SiLU + MLP 6x）
- **详见**: `pilot-static-ct-complete.md`

### 4.2 Baseline 执行

**启动**：切换到 `autoresearch/baseline-pilot-1` 分支，重置 results.tsv（5列），验证 train.py 为原始状态后启动脚本。

**过程**：

```
Iter  1: baseline                    → 1.2472  KEEP (初始)
Iter  2: MATRIX_LR 0.04→0.05        → 1.1707  KEEP ✓
Iter  3: 激活函数 ReLU²→SiLU        → 1.1531  KEEP ✓
Iter  4: MLP expansion 4x→6x        → 1.1481  KEEP ✓
Iter  5-13: 9 次连续 DISCARD (depth↑, aspect↑, warmdown↓, HEAD_DIM↓, 
            EMBEDDING_LR↑, window简化, weight_decay↓, Adam β1↑, warmup↑)
Iter 14: batch size 2^19→2^18       → 1.1306  KEEP ✓ (打破瓶颈!)
Iter 15: MATRIX_LR→0.06             → 1.2091  DISCARD
```

**特征**：前 4 次连续 keep（快速收益期），中间 9 次连续 discard（停滞期），最后靠降低 batch size 突破。

**指标**：BPB 1.2472 → 1.1306，改善 **9.4%**，keep 率 33.3%，耗时 ~85 分钟。

### 4.3 Adaptive-CT 执行

**启动**：切换到 `autoresearch/adaptive-ct-pilot-1` 分支，重置 results.tsv（8列），验证原始状态。

**δ 动态计算**：每次迭代前从 results.tsv 实时计算 δ = 0.5·S + 0.3·RR + 0.2·(1-ID)，决定策略。

**过程**：

```
Iter  1: δ=0.000 BASELINE            → 1.1636  KEEP (初始)
Iter  2: δ=0.000 GUARD MATRIX_LR↑    → 1.2354  DISCARD
Iter  3: δ=0.600 SIMPLIFY window简化  → 1.2306  DISCARD
Iter  4: δ=0.733 BREAK  SiLU激活     → 1.1392  KEEP ✓ (唯一改善!)
Iter  5-11: δ=0.4~0.64, 全部 SIMPLIFY → 全部 DISCARD
            (HEAD_DIM↓, warmdown去除, depth↓, window简化, HEAD_DIM↓, warmdown去除, depth↓)
Iter 12-15: δ=0.92~1.00, 全部 BREAK   → 全部 DISCARD
            (MLP 6x, depth↑, aspect↑, batch↓)
```

**特征**：δ 从 0.0 跳到 0.6（iter 3），短暂突破 0.7 成功一次（iter 4），然后陷入 **SIMPLIFY 死循环**（iter 5-11, 占 47% 迭代），最终 δ 突破 0.7 但 BREAK 也全部失败。

**指标**：BPB 1.1636 → 1.1392，改善 **2.1%**，keep 率 13.3%，耗时 ~80 分钟。

### 4.4 执行过程中解决的问题

本次对话承接了前一对话中已修复的基础设施问题：

| 问题 | 在哪个阶段发现 | 修复方案 |
|------|---------------|---------|
| bash `GROUPS` 保留变量冲突 | Static-CT 初始化 | 改名 `EXP_GROUPS` |
| `((count++))` 与 `set -e` 冲突 | validate_pilot.sh | `count=$((count + 1))` |
| `git log \| head -1` SIGPIPE | validate_pilot.sh | `git log -1` |
| Git Bash→WSL 变量展开丢失 | Static-CT 迭代 | 编写 `run_iter.sh` 辅助脚本 |
| results.tsv 在分支切换时丢失 | 分析阶段 | 每组完成后 cp 到 `pilot_data/` |
| analyze_pilot.py 时间估算用了全仓库 git log | 分析阶段 | 手动修正为实测值 |

---

## 5. 验证与测试

### 5.1 跨组分析报告

运行 `analyze_pilot.py` 生成了完整的跨组对比报告（`pilot_report.md`）。

**三组对比**：

| 指标 | Baseline | Static-CT | Adaptive-CT |
|------|----------|-----------|-------------|
| 迭代数 | 15 | 15 | 15 |
| Keep / Discard | 5 / 10 | 4 / 11 | 2 / 13 |
| 初始 BPB | 1.2472 | 1.1955 | 1.1636 |
| 最佳 BPB | 1.1306 | **1.1239** | 1.1392 |
| 改善率 | **9.4%** | 6.0% | 2.1% |
| Keep 率 | **33.3%** | 26.7% | 13.3% |
| δ→策略对齐率 | N/A | 100% | 100% |
| 0 Crash | ✅ | ✅ | ✅ |

### 5.2 Pilot 验证项

| 验证项 | 目标 | 结果 |
|--------|------|------|
| V1 管道完整性 | 三组 0 crash | ✅ PASS |
| V2 结果记录格式 | TSV 列数/格式正确 | ✅ PASS |
| V3 δ 计算合规 | CT 组 δ 值有效 | ✅ 100% |
| V4 策略遵从 | δ→策略映射正确 | ✅ 100% (14/14) |
| V5 Git 工作流 | keep/discard 逻辑 | ✅ PASS |
| V6 时间估算 | 可预测正式实验耗时 | ✅ ~5.5 min/iter |
| V7 跨组可比性 | 三组数据格式统一 | ⚠️ 起始 BPB 差异需注意 |

**综合判定：PASS——可以启动正式实验。**

### 5.3 数据归档

```
pilot_data/
├── results_baseline_pilot-1.tsv      # 16 行 (1 header + 15 data)
├── results_static-ct_pilot-1.tsv     # 16 行
├── results_adaptive-ct_pilot-1.tsv   # 16 行
└── pilot_report.md                   # 跨组分析报告
```

---

## 6. 关键洞察与讨论

### 6.1 "Baseline 最好"是错觉吗？

表面上 Baseline 改善率最高（9.4%），但这个结论**不成立**，原因如下：

#### 原因 1：起始 BPB 差异

三组起始 BPB 不同（1.2472 / 1.1955 / 1.1636），源于训练的随机性。起始 BPB 越高，可改善空间越大。如果看**绝对最优 BPB**，排名是 Static-CT (1.1239) > Baseline (1.1306) > Adaptive-CT (1.1392)。

#### 原因 2：Pilot 是脚本执行，不是 AI Agent

这是最根本的问题。Pilot 的每个修改都是**预编程在 bash 脚本中的固定操作**，不是真正的 AI agent 阅读 `program.md` 后自主决策的结果。

正式实验中的真正差异来自：
- Baseline agent 读到"完全自由探索"→ 可能做出更多样/更激进的尝试
- CT agent 读到"必须按 δ 决定策略"→ 决策受到框架约束

脚本化的 pilot 只验证了**管道**，完全没有测试**框架对 AI 决策质量的影响**。

#### 原因 3：Adaptive-CT 的核心机制未激活

自适应调参设计在第 50 迭代触发。15 次迭代中，Adaptive-CT 退化为"无调参的 Static-CT"，而且不幸陷入了 SIMPLIFY 陷阱——这恰好论证了自适应机制存在的必要性。

#### 原因 4：修改池偏差

脚本中 SIMPLIFY 池的修改（降 HEAD_DIM、去 warmdown、降 depth）天生较弱。真正的 AI agent 做 SIMPLIFY 时拥有更灵活的选择（代码重构、合并冗余模块、优化内存布局等）。

### 6.2 "SIMPLIFY 陷阱"现象

Adaptive-CT 暴露了 CT 框架的一个重要结构性特征：

```
δ 进入 [0.3, 0.7] → SIMPLIFY 策略
  → SIMPLIFY 失败 → S 和 RR 上升 → δ 缓慢增长
    → δ 仍在 [0.3, 0.7] → 继续 SIMPLIFY
      → 正反馈死循环
        → 直到足够多次失败使 δ > 0.7 → 转 BREAK
```

这在 Adaptive-CT 中持续了 7 次迭代（iter 5-11），占总迭代的 47%。

**论文层面的意义**：这个现象恰恰是 Adaptive-CT 设计的理论动机——通过分析历史数据调整 θ_guard 和 θ_break，压缩 SIMPLIFY 区间，更快进入 BREAK 策略。15 迭代 pilot 没有给自适应机制表现的机会。

### 6.3 共性发现：哪些修改有效

跨三组对比，修改的有效性呈现明显的一致性：

| 修改 | Baseline | Static-CT | Adaptive-CT | 一致性 |
|------|----------|-----------|-------------|--------|
| SiLU 激活函数 | ✅ keep | ✅ keep | ✅ keep | **三组全成功** |
| MATRIX_LR 上调 | ✅ keep | ✅ keep | ❌ discard | 2/3 |
| MLP 6x 扩展 | ✅ keep | ✅ keep | ❌ discard | 2/3 |
| Batch size 减半 | ✅ keep | — | ❌ discard | 1/2 |
| HEAD_DIM 128→64 | ❌ | ❌ | ❌ | **三组全失败** |
| ASPECT_RATIO 64→80 | ❌ | ❌ | ❌ | **三组全失败** |
| Depth 增加到 10 | ❌ | ❌ | ❌ | **三组全失败** |

SiLU 激活函数是唯一在所有三组中都带来改善的修改——这可能指向 autoresearch 基线架构中 ReLU² 不是最优选择。

### 6.4 时间规划验证

| 指标 | 实测值 |
|------|--------|
| 单次迭代 | ~5.5 分钟（训练 5 分钟 + 编译/评估开销） |
| 15 迭代 pilot | ~80-85 分钟 |
| 200 迭代预估 | ~18-19 小时 |
| Round 1（3组×3runs=9runs）| ~7 天（串行） |
| 全量实验（3组×10runs=30runs）| ~24 天（串行） |

RTX 5090 D 的训练性能稳定，无 OOM 或 crash，SDPA fallback 工作正常。

---

## 7. 后续演化

### 近期：正式实验准备

1. **解决起始 BPB 差异问题**：
   - 方案 A：所有组共用同一个 baseline commit 和 BPB（推荐）
   - 方案 B：用相对改善率而非绝对 BPB 作为主要指标
   - 方案 C：增加 run 数量，通过统计检验消除随机性

2. **从脚本自动化切换到 AI Agent 执行**：
   - 正式实验必须由真正的 AI agent（如 Cursor Agent）阅读 `program.md` 后自主决策
   - 这才是实验的核心——测试 CT 框架对 AI 决策质量的影响
   - 需要设计 agent 启动/停止/恢复的自动化流程

3. **优化 SIMPLIFY 修改池**（或完全交给 AI agent）：
   - Pilot 暴露的 SIMPLIFY 陷阱部分源于修改池太弱
   - 真正的 AI agent 不受预设修改池限制

### 中期：Round 1 实验

- 每组 3 runs × 200 迭代 = 9 runs
- 预估 ~171 小时（~7 天串行）
- 收集足够数据进行初步统计分析

### 长期：论文所需的完整实验

- 每组 10 runs × 200 迭代 = 30 runs
- 统计检验（Wilcoxon / bootstrap CI）
- δ 分布热力图、策略成功率曲线等可视化
- Adaptive-CT 阈值自演化轨迹分析

---

## 附录：文件清单

### 本次创建/修改的文件

| 文件 | 类型 | 用途 |
|------|------|------|
| `work_dir/experiment/run_baseline_pilot.sh` | 新建 | Baseline 组 15 迭代自动化脚本 |
| `work_dir/experiment/run_adaptive_ct_pilot.sh` | 新建 | Adaptive-CT 组 15 迭代自动化脚本（含动态 δ） |
| `work_dir/experiment/pilot_report.md` | 新建 | 跨组分析报告（analyze_pilot.py 输出 + 手动修正） |
| `pilot_data/results_baseline_pilot-1.tsv` | 新建 | Baseline 结果数据 |
| `pilot_data/results_adaptive-ct_pilot-1.tsv` | 新建 | Adaptive-CT 结果数据 |
| `work_dir/journals/2026-04-04/pilot-baseline-complete.md` | 新建 | Baseline 完成日志 |
| `work_dir/journals/2026-04-04/pilot-adaptive-ct-complete.md` | 新建 | Adaptive-CT 完成日志 |

### Git 分支状态

| 分支 | 状态 | Keep commits |
|------|------|-------------|
| `autoresearch/baseline-pilot-1` | ✅ 完成 | 5 (baseline + 4 improvements) |
| `autoresearch/static-ct-pilot-1` | ✅ 完成 | 4 (baseline + 3 improvements) |
| `autoresearch/adaptive-ct-pilot-1` | ✅ 完成 | 2 (baseline + 1 improvement) |
