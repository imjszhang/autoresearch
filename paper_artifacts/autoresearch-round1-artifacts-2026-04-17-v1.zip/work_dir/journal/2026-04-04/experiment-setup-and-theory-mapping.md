# Cyber-Taoist 实验准备：分支搭建、Program 设计与理论映射分析

> 日期：2026-04-04
> 项目：autoresearch / cyber-taoist
> 类型：架构设计 / 功能实现 / 调研分析
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [理论映射深度分析](#6-理论映射深度分析)
7. [实验预期梳理](#7-实验预期梳理)
8. [产出文件清单](#8-产出文件清单)
9. [后续演化](#9-后续演化)

---

## 1. 背景与动机

在前一轮对话中完成了论文设计（`paper.md`）和 WSL2 实验环境搭建。本次工作的目标是**将论文方案落地为可执行的实验基础设施**——即根据论文 Appendix A 的三组 `program.md` 设计，在 WSL 内搭建完整的 Git 分支结构、编写三个 program 变体、创建实验初始化脚本，并深入分析 Cyber-Taoist 理论概念在 program 中的映射关系和实验预期。

核心问题：论文已经设计好了三组对照实验（Baseline / Static-CT / Adaptive-CT），但实际的分支、文件、脚本都还没有创建。本次工作是从"纸上方案"到"可执行环境"的最后一步。

---

## 2. 分析过程

### 2.1 当前状态审查

通过检查 WSL 内项目状态，确认：

| 项目 | 状态 |
| ---- | ---- |
| WSL 发行版 | Ubuntu 24.04 (WSL2)，运行中 |
| 项目路径 | `/root/projects/autoresearch/` |
| GPU | RTX 5090 D, 32GB VRAM, PyTorch 2.9.1+cu128 |
| 训练数据 | 11 个 parquet 分片 + 分词器，已就绪 |
| train.py | 4 处硬件适配修改已完成但未提交 |
| 实验分支 | 尚未创建 |
| results.tsv | 不存在 |
| program.md | 仍为原始版本，未替换为实验版本 |

### 2.2 实验自变量确认

经过讨论确认：三组实验之间**唯一的自变量是 `program.md`**。`train.py` 从同一基线出发，`prepare.py` 不可修改，训练数据和评估标准完全相同。program.md 是指导 AI agent 行为的"决策策略文件"。

### 2.3 实验数据审查

审查了 `prepare.py` 的数据管线：

| 参数 | 值 |
| ---- | ---- |
| 数据集 | karpathy/climbmix-400b-shuffle (HuggingFace) |
| 下载量 | 10 训练分片 + 1 固定验证分片 (~963MB) |
| 分词器 | BPE (rustbpe), 词表 8192, GPT-4 风格切分 |
| 上下文长度 | 2048 |
| 时间预算 | 300 秒 (5 分钟) |
| 评估指标 | BPB (Bits Per Byte), 与词表大小无关 |

5 分钟内约处理 ~70M tokens，10 个分片数据量远超此数，不构成瓶颈。

---

## 3. 方案设计

### 3.1 分支策略

采用"模板分支 + 运行分支"的两层结构：

```
experiment/base  ← 共享基线（train.py 硬件适配）
    │
    ├── autoresearch/baseline     ← Baseline 模板
    │       └── autoresearch/baseline-1 ~ baseline-10  ← 各次运行
    │
    ├── autoresearch/static-ct    ← Static-CT 模板
    │       └── autoresearch/static-ct-1 ~ static-ct-10
    │
    └── autoresearch/adaptive-ct  ← Adaptive-CT 模板
            └── autoresearch/adaptive-ct-1 ~ adaptive-ct-10
```

### 3.2 三组 program.md 设计原则

三个 program 共享相同的**操作基础设施**（运行方式、输出格式、超时处理、崩溃处理、NEVER STOP 规则），仅在**决策策略部分**不同：

| 特性 | Baseline | Static-CT | Adaptive-CT |
| ---- | -------- | --------- | ----------- |
| 决策方式 | 完全自主，无框架约束 | δ 公式 + 固定阈值 θ_guard=0.3, θ_break=0.7 | δ 公式 + 每 50 次迭代自适应阈值 |
| results.tsv 列数 | 5 列 | 8 列 (+delta, strategy, rationale) | 8 列 + 适应行 |
| 定期回顾 | 无 | 每 10/50 次 | 每 10/50 次 + 参数适应 |
| 总行数 | 103 行 | 126 行 | 157 行 |

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 是否在 program 中使用 CT 理论术语 | 否 | 避免对 agent 产生暗示偏差，保证实验客观性 |
| Baseline 是否沿用原始 program.md | 否，重写 | 原始版本有过多操作细节（如 git 操作说明），需与 CT 组保持相同的基础设施，仅去掉策略部分 |
| 分支命名 | autoresearch/{group}-{N} | 与原项目 `autoresearch/<tag>` 命名惯例一致 |
| 实验初始化方式 | Shell 脚本 init_run.sh | 一键创建运行分支 + 初始化 results.tsv，减少人工错误 |

---

## 4. 实现要点

### 4.1 Git 操作序列

```bash
# 1. 从 githubforker 分支创建实验基线，提交 train.py 适配
git checkout -b experiment/base
git add train.py
git commit -m "adapt train.py for RTX 5090 D / Blackwell SM 12.0"

# 2. 从基线创建三个模板分支，各自放入对应的 program.md
git checkout -b autoresearch/baseline experiment/base
# 复制 baseline program.md，提交

git checkout -b autoresearch/static-ct experiment/base
# 复制 static-ct program.md，提交

git checkout -b autoresearch/adaptive-ct experiment/base
# 复制 adaptive-ct program.md，提交
```

### 4.2 初始化脚本 init_run.sh

用法：`bash init_run.sh <group> <run_number>`

功能：
1. 验证模板分支存在
2. 检查运行分支不重复
3. 从模板分支创建运行分支
4. 初始化 results.tsv（Baseline 5 列 / CT 组 8 列）
5. 输出就绪状态（分支名、program.md 标题、数据缓存状态）

注意：从 Windows 复制的脚本需要 `sed -i "s/\r$//"` 转换换行符。

### 4.3 三个 program.md 的核心差异

**Baseline (program_baseline.md)**
- Decision Strategy 一节仅有三行：完全自主，无规则，凭直觉

**Static-CT (program_static_ct.md)**
- Cyber-Taoist Decision Framework 一节包含：
  - 5 个量化指标（S, RR, ID, δ, ΔC）
  - 4 条固定决策规则（SIMPLIFY / GUARD / BREAK / SIMPLIFY）
  - "You MUST always compute δ and follow the prescribed strategy. Do not override."

**Adaptive-CT (program_adaptive_ct.md)**
- 在 Static-CT 基础上增加 Parameter Adaptation 子节：
  - 每 50 次迭代分析累积数据
  - 按 δ 区间 [0,0.2)~[0.8,1.0] 统计 GUARD/BREAK 成功率
  - 找到交叉点更新 θ_guard 和 θ_break
  - 约束 θ_guard ∈ [0.1, 0.6], θ_break ∈ [θ_guard+0.1, 0.9]

---

## 5. 验证与测试

### 5.1 分支结构验证

```
experiment/base    → f138133 (train.py 适配)
autoresearch/baseline    → 84a5ec1 (Baseline program.md)
autoresearch/static-ct   → 882d2e0 (Static-CT program.md)
autoresearch/adaptive-ct → fbffd4c (Adaptive-CT program.md)
```

- 三个模板分支的 train.py 完全一致（648 行）✓
- program.md 行数各不相同（103 / 126 / 157）✓
- 三个分支共享同一个父提交 f138133 ✓

### 5.2 初始化脚本测试

```bash
bash init_run.sh baseline 1
# → 成功创建 autoresearch/baseline-1
# → results.tsv 含正确 5 列表头
# → program.md 标题为 "# autoresearch — Baseline"
# → 数据缓存 11 shards, 2 tokenizer files
```

测试后清理：`git branch -D autoresearch/baseline-1` ✓

---

## 6. 理论映射深度分析

对三个 program 的具体指令逐一追踪 Cyber-Taoist 理论概念的映射情况。

### 6.1 映射全景图

| 理论概念 | Baseline | Static-CT | Adaptive-CT |
| -------- | :------: | :-------: | :---------: |
| N（天道） | 隐含 | 隐含 | 隐含 |
| R（法则） | 显式缺失 | 存在但未命名 | 存在 + 可进化 |
| T（交易） | 隐含 | 隐含 | 两层（隐含） |
| EC（生态） | 隐含 | 隐含 | 隐含 |
| NI（生态位） | 隐含 | 隐含 | 隐含 |
| 守（Guard） | 无 | **显式量化** | **显式量化** |
| 破（Break） | 无 | **显式量化** | **显式量化** |
| 法则繁则交易稀 | 无 | **显式量化**（ΔC） | **显式量化**（ΔC） |
| 偏差函数 δ | 无 | **显式量化** | **显式量化** |
| 五阶段循环 | 隐含（1-4） | 隐含（1-4） | 显式（1-5） |
| 分形自相似 | 无 | 无 | 存在但未命名 |
| CT 理论术语 | 无 | 无 | 无 |

### 6.2 关键发现

**显式映射最完整的概念：守/破决策**

| 理论（skill.md） | Program 实现 |
| ----------------- | ------------ |
| R 与 N 偏差小 → 守 | δ < 0.3 → GUARD |
| R 严重滞后 → 破 | δ > 0.7 → BREAK |
| R 过度繁复 → 简化 R | ΔC > 10% → SIMPLIFY |

**偏差函数 δ 的成分与宪章对应**

| δ 的成分 | 权重 | 宪章条款 | 捕捉的信号 |
| -------- | ---- | -------- | ---------- |
| S（停滞分数） | 0.5 | 第四条（交易反馈模糊） | "感知滞后" |
| RR（回滚率） | 0.3 | 第九条（交易失败率） | "法则可能失效" |
| ID（改进衰减） | 0.2 | 第六条（生态位提升放缓） | "旧法则内接近天花板" |
| ΔC（复杂度） | 独立 | 第八条（法则繁则交易稀） | "法则臃肿化" |

**五阶段覆盖差异**

只有 Adaptive-CT 完整覆盖宪章第十三条的五阶段进化循环（常规 → 感知滞后 → 试探性突破 → 成败筛选 → **规则更新**）。Static-CT 缺少第 5 阶段（规则永不更新），Baseline 各阶段均为隐含。

**Adaptive-CT 的分形自相似**

| 层次 | 主体 | 法则 R | 交易 T | 进化结果 |
| ---- | ---- | ------ | ------ | -------- |
| 微观 | 每次实验 | 守/破决策规则 | 修改 train.py 并运行 | val_bpb 改进 |
| 中观 | 守/破框架本身 | 阈值参数 θ | 分析 50 次决策-结果数据 | θ 参数漂移 |

但这个分形关系在 program 中从未被显式说明——这是有意为之（避免暗示偏差）。

### 6.3 设计意图：为什么剥离哲学术语

1. **避免暗示偏差**：agent 不知道自己在验证 CT 理论，不会为了"配合理论"做出不自然的选择
2. **保证可复现性**：纯量化规则比哲学指引更明确，不同 agent 对同一状态的判断更一致
3. **符合实验设计**：自变量是"决策规则的存在形式"，而非"agent 对理论的理解程度"

---

## 7. 实验预期梳理

根据论文 §8 整理的三大假设和预期：

### 假设

| 假设 | 内容 | 比较 |
| ---- | ---- | ---- |
| H1（框架有效性） | CT 组的最终 val_bpb 显著低于 Baseline (p<0.05) | Static-CT & Adaptive-CT vs Baseline |
| H2（自进化优势） | Adaptive-CT 在后 100 次迭代的改进速率显著高于 Static-CT | Adaptive-CT vs Static-CT |
| H3（复杂度管理） | CT 组代码复杂度增长更慢、崩溃更少 | CT 组 vs Baseline |

### 8 个量化指标

最终 val_bpb、收敛速度、探索效率（keep 比例）、代码复杂度增长、崩溃次数、学习曲线 AUC、决策对齐分数（CT 组）、参数收敛轨迹（Adaptive-CT）。

### 四层风险对冲

即使实验结果不如预期，论文仍有独立贡献：
- 全部验证 → 四层完整论证
- H1 过但 H2 不显著 → 三层论证
- 结果平平 → 理论映射 + 操作化仍有学术价值
- CT 组更差 → 阴性结果同样有价值

---

## 8. 产出文件清单

### Windows 侧 (work_dir/experiment/)

| 文件 | 用途 |
| ---- | ---- |
| `program_baseline.md` | Baseline 组 program.md（无决策框架，103 行） |
| `program_static_ct.md` | Static-CT 组 program.md（固定守/破阈值，126 行） |
| `program_adaptive_ct.md` | Adaptive-CT 组 program.md（自适应阈值，157 行） |
| `init_run.sh` | 实验运行初始化脚本 |
| `README.md` | 实验整体说明（概述、数据、硬件、分支、研究问题） |
| `design_rationale.md` | 三组 program 的 CT 理论映射深度分析 |
| `expected_results.md` | 实验预期结果（假设、指标、分析方法、风险对冲） |

### WSL 侧 (Git 分支)

| 分支 | 提交 | 用途 |
| ---- | ---- | ---- |
| `experiment/base` | f138133 | 共享基线（train.py 硬件适配） |
| `autoresearch/baseline` | 84a5ec1 | Baseline 模板分支 |
| `autoresearch/static-ct` | 882d2e0 | Static-CT 模板分支 |
| `autoresearch/adaptive-ct` | fbffd4c | Adaptive-CT 模板分支 |

### 本次日志

| 文件 | 用途 |
| ---- | ---- |
| `work_dir/journals/2026-04-04/experiment-setup-and-theory-mapping.md` | 本文件 |

---

## 9. 后续演化

### 近期

- [ ] 跑小规模预实验（每组 1 次 × 20 迭代），验证 program.md 指令是否被 agent 正确执行
- [ ] 确认 CT 组 agent 是否真正计算 δ 并遵循决策规则（而非忽略指令）
- [ ] 尝试预热 torch.compile 编译缓存，若可行则重新启用以提升每步性能
- [ ] 完成 30 次完整实验运行（3 组 × 10 次 × 200 迭代）

### 长期

- [ ] 用真实数据替换论文 §8 预期结果
- [ ] 将论文从 Markdown 迁移到 LaTeX（NeurIPS/ICML 模板）
- [ ] 补充真实的 AutoML/NAS 文献引用
- [ ] 探索多 agent 生态实验（论文 Future Work 第 4 条）
