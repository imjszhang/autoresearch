# Cyber-Taoist 论文设计与 WSL2 实验环境搭建

> 日期：2026-04-04
> 项目：autoresearch / cyber-taoist
> 类型：调研分析 / 架构设计 / 问题排查
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [论文设计过程](#2-论文设计过程)
3. [论文方案定稿](#3-论文方案定稿)
4. [硬件兼容性排查](#4-硬件兼容性排查)
5. [WSL2 环境搭建与验证](#5-wsl2-环境搭建与验证)
6. [产出文件清单](#6-产出文件清单)
7. [后续演化](#7-后续演化)

---

## 1. 背景与动机

基于 `autoresearch` 项目实证验证 cyber-taoist 进化学理论的价值。目标是写一篇学术论文，利用 `autoresearch` 平台作为实验环境，通过对照实验检验 cyber-taoist 框架（特别是"守/破"决策启发式）能否提升 AI 代理的自动化研究效率。

输入材料：
- `work_dir/docs/CONSTITUTION.md` — cyber-taoist 宪章，定义 N/R/T/EC/NI 核心概念
- `work_dir/docs/skill.md` — 七步分析框架和守/破决策启发式
- `work_dir/docs/idea.md` — 将 cyber-taoist 嵌入 autoresearch 的五个优化方向
- `work_dir/docs/paper_idea.md` — 初始论文大纲（v1）

---

## 2. 论文设计过程

### 2.1 初版方案审视（paper_idea_v1.md）

初版采用**五组对比实验**（A:无策略 / B:贪婪 / C:守破框架 / D:分形+守破 / E:守破+法则简化），每组 5 次运行，200 次迭代。

发现的问题：

| 问题 | 影响 |
| ---- | ---- |
| 5 组 × 5 次 = 25 个数据点，统计力不足 | 结果可能不显著，论文风险极高 |
| 贡献维度单一（纯 benchmark） | 如果效果不好，论文没有价值 |
| `idea.md` 利用率低（约 30%） | 最精彩的"框架自进化"思路完全缺失 |
| 未挖掘 autoresearch 本身就是 cyber-taoist 实例 | 错失了不依赖实验数据的独立贡献 |

### 2.2 改进方向确定

核心思路转变：从"单一实验验证"升级为"四层递进论证"，每层独立成立。

**四层结构：**
1. **理论映射**（描述力）— autoresearch 设计元素 ↔ cyber-taoist 概念的形式化对应
2. **操作化**（算法化）— 守/破决策从哲学启发式 → 可计算的偏差函数 δ(R,N) + 阈值算法
3. **实验验证**（有效性）— 3 组 × 10 次，统计力更强
4. **框架自进化**（自指性）— Adaptive-CT 组的参数漂移证明框架自身也遵循 cyber-taoist 进化

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 实验分组数 | 5 组 → 3 组 | 减少组数、增加每组运行次数（5→10），统计力更强 |
| 论文风险结构 | 单层 → 四层 | 即使实验结果平平，理论映射和操作化仍是独立贡献 |
| 是否形式化守/破决策 | 是 | 偏差函数 δ = w₁·S + w₂·RR + w₃·(1-ID) 使理论可计算 |
| 是否加入自进化组 | 是 | Adaptive-CT 是论文最大差异化卖点，来自 idea.md 第四部分 |
| 论文语言 | 英文 | 学术惯例 |
| 论文格式 | Markdown（后续迁移 LaTeX） | 当前阶段优先完成内容 |

---

## 3. 论文方案定稿

### 3.1 文件版本管理

- `paper_idea_v1.md` — 原始大纲备份
- `paper_idea.md` — 改进后的四层递进大纲
- `paper.md` — **完整论文正文**（642 行）

### 3.2 论文结构

| 章节 | 内容 | 状态 |
| ---- | ---- | ---- |
| Abstract | 四层递进论证摘要 | 完成 |
| §1 Introduction | 背景、研究空白、RQ1-RQ3、四项贡献 | 完成 |
| §2 Related Work | cyber-taoist 理论、AI 自动化研究、探索-利用权衡 | 完成 |
| §3 Theoretical Mapping | autoresearch ↔ cyber-taoist 形式化映射、设计解读、五阶段动态 | 完成 |
| §4 Operationalization | 偏差函数 δ(R,N) 定义、Guard/Break 算法伪代码、分形多尺度 | 完成 |
| §5 Experimental Design | 3 组（Baseline/Static-CT/Adaptive-CT）× 10 次 × 200 迭代 | 完成 |
| §6 Evaluation Metrics | 8 个指标（val_bpb、收敛速度、探索效率等） | 完成 |
| §7 Analysis Methods | 统计检验、学习曲线、决策质量、自进化分析 | 完成 |
| §8 Expected Results | H1-H3 假设及推理、理论/实践/哲学意义、局限性 | 完成（预期） |
| §9 Conclusion | 总结 + 五个未来方向 | 完成 |
| References | 9 篇核心文献 | 完成 |
| Appendix A | 三组 program.md 完整文本 | 完成 |
| Appendix B | 偏差函数 Python 实现 | 完成 |
| Appendix C | 自适应阈值更新算法 | 完成 |

### 3.3 三个研究问题

- **RQ1**：cyber-taoist 能否自洽描述 autoresearch 的设计逻辑与运行动态？（描述力）
- **RQ2**：操作化的守/破决策是否提升代理研究效率？（有效性）
- **RQ3**：框架决策参数能否通过实验数据自优化？（自进化）

---

## 4. 硬件兼容性排查

### 4.1 设备信息

| 项目 | 规格 |
| ---- | ---- |
| GPU | NVIDIA GeForce RTX 5090 D, 32GB VRAM |
| GPU 架构 | Blackwell, Compute Capability 12.0 |
| CPU | Intel Core Ultra 9 285K, 24 核 |
| RAM | 96 GB |
| PyTorch | 2.9.1 + CUDA 12.8 |
| 驱动 | 591.74, CUDA 13.1 |

### 4.2 兼容性问题排查

**问题一：Flash Attention 3 无 Windows 预编译包**

`kernels-community/flash-attn3` 在 HuggingFace 上仅提供 Linux 构建：
```
build/torch29-cxx11-cu128-x86_64-linux/  ✓
build/torch29-cu128-x86_64-windows/      ✗ 不存在
```
→ 决策：使用 WSL2 运行

**问题二：FA3 预编译内核不含 Blackwell (SM 12.0)**

即使在 WSL Linux 环境下，FA3 内核也不支持 SM 12.0：
```
CUDA error: no kernel image is available for execution on the device
```
→ 决策：用 PyTorch 原生 SDPA 替代

**问题三：torch.compile 在 Blackwell 上首次编译极慢**

Triton JIT 为 SM 12.0 编译内核，单步需 5-12 分钟：
```
step 00000: dt: 754899ms
step 00001: dt: 326189ms
```
→ 决策：暂时禁用 torch.compile

**问题四：无 torch.compile 时 DEVICE_BATCH_SIZE=128 导致 OOM**

```
torch.OutOfMemoryError: Tried to allocate 1024.00 MiB. 51.59 GiB allocated by PyTorch
```
→ 决策：DEVICE_BATCH_SIZE 从 128 降至 32

### 4.3 最终适配方案

| 适配项 | 原始 | 调整后 | 影响 |
| ---- | ---- | ---- | ---- |
| 注意力实现 | Flash Attention 3 | PyTorch SDPA | 不支持滑动窗口，val_bpb 绝对值略有差异 |
| torch.compile | 启用 | 禁用 | 每步略慢，但功能等价 |
| DEVICE_BATCH_SIZE | 128 | 32 | 梯度累积步数 2→8，总 batch size 不变 |
| MFU 报告 | 基于 H100 峰值 | 数值无参考价值 | 纯显示问题，不影响训练 |

---

## 5. WSL2 环境搭建与验证

### 5.1 搭建步骤

| 步骤 | 命令 | 耗时 |
| ---- | ---- | ---- |
| 安装 Ubuntu-24.04 | `wsl --install Ubuntu-24.04 --no-launch` | ~53s |
| 安装 uv | `curl -LsSf https://astral.sh/uv/install.sh \| sh` | ~5s |
| 安装 build-essential | `apt-get install -y build-essential` | ~44s |
| 复制项目到 WSL | `cp -r /mnt/d/.../autoresearch /root/projects/` | ~150s |
| uv sync 安装依赖 | `uv sync` | ~472s |
| prepare.py 下载数据 | `uv run prepare.py` | ~107s |
| **总计** | | **~14 分钟** |

### 5.2 验证运行结果

```
val_bpb:          1.234435
training_seconds: 300.2
total_seconds:    264.1
peak_vram_mb:     23092.0 (23GB / 32GB, 72% 利用率)
total_tokens_M:   69.7
num_steps:        133
num_params_M:     50.3
depth:            8
```

训练完整跑通，loss 从 9.0 稳步降至 3.54，val_bpb 1.234，显存有 9GB 余量。

### 5.3 WSL 内 train.py 修改点汇总

三处修改均在 WSL 内的 `/root/projects/autoresearch/train.py`，Windows 侧原始 `train.py` 未改动。

1. FA3 导入块替换为按 SM 版本跳过加载
2. 注意力前向传播增加 SDPA 分支
3. `torch.compile` 注释掉
4. `DEVICE_BATCH_SIZE` 从 128 改为 32

详见 `work_dir/docs/wsl_guide.md`。

---

## 6. 产出文件清单

| 文件 | 用途 |
| ---- | ---- |
| `work_dir/docs/paper_idea_v1.md` | 原始论文大纲备份 |
| `work_dir/docs/paper_idea.md` | 改进后的四层递进大纲 |
| `work_dir/docs/paper.md` | 完整论文正文（英文，642 行） |
| `work_dir/docs/wsl_guide.md` | WSL2 实验环境操作指引 |
| `work_dir/journals/2026-04-04/cyber-taoist-paper-and-wsl-setup.md` | 本日记 |

WSL 内：

| 路径 | 用途 |
| ---- | ---- |
| `/root/projects/autoresearch/` | 实验用项目副本（含适配后的 train.py） |
| `/root/.cache/autoresearch/` | 训练数据和分词器缓存 |

---

## 7. 后续演化

### 近期

- [ ] 编写实验自动化脚本：自动循环 200 次迭代、记录 results.tsv、根据 program.md 策略选择修改方向
- [ ] 为三组实验（Baseline / Static-CT / Adaptive-CT）分别创建 Git 分支和 program.md
- [ ] 尝试预热 torch.compile 编译缓存（`TORCHINDUCTOR_CACHE_DIR`），若可行则重新启用以提升每步性能
- [ ] 跑小规模预实验（每组 3 次 × 20 迭代）验证 program.md 指令是否被代理正确执行

### 长期

- [ ] 完成 30 次完整实验运行（3 组 × 10 次 × 200 迭代）
- [ ] 用真实数据替换论文 §8 预期结果
- [ ] 将论文从 Markdown 迁移到 LaTeX（NeurIPS/ICML 模板）
- [ ] 补充真实的 AutoML/NAS 文献引用
