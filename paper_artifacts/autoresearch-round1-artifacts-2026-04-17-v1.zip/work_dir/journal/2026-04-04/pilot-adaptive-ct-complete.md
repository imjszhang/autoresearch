# Adaptive-CT Pilot 完成报告

**时间**: 2026-04-04 22:36 – 23:56（约 80 分钟）
**分支**: `autoresearch/adaptive-ct-pilot-1`
**迭代数**: 15
**阈值**: θ_guard=0.3, θ_break=0.7（初始值，未触发自适应调参）

## 关键指标

| 指标 | 值 |
|------|-----|
| 起始 val_bpb | 1.163585 |
| 最终 val_bpb | 1.139196 |
| 改善幅度 | **2.1%** |
| Keep / Discard | 2 / 13 |
| Keep 率 | 13.3% |

## 逐次迭代记录

| # | δ | Strategy | val_bpb | 状态 | 描述 |
|---|---|----------|---------|------|------|
| 1 | 0.000 | BASELINE | 1.1636 | keep | 初始运行 |
| 2 | 0.000 | GUARD | 1.2354 | discard | MATRIX_LR 0.04→0.05 |
| 3 | 0.600 | SIMPLIFY | 1.2306 | discard | WINDOW_PATTERN SSSL→SL |
| 4 | 0.733 | BREAK | 1.1392 | **keep** | 激活函数 ReLU²→SiLU |
| 5 | 0.400 | SIMPLIFY | 1.1637 | discard | HEAD_DIM 128→64 |
| 6 | 0.480 | SIMPLIFY | 1.2013 | discard | 移除 warmdown |
| 7 | 0.533 | SIMPLIFY | 1.1570 | discard | depth 8→6 |
| 8 | 0.571 | SIMPLIFY | 1.2150 | discard | WINDOW_PATTERN SSSL→SL |
| 9 | 0.600 | SIMPLIFY | 1.1747 | discard | HEAD_DIM 128→64 |
| 10 | 0.622 | SIMPLIFY | 1.1619 | discard | 移除 warmdown |
| 11 | 0.640 | SIMPLIFY | 1.1990 | discard | depth 8→6 |
| 12 | 0.920 | BREAK | 1.2561 | discard | MLP 4x→6x |
| 13 | 0.920 | BREAK | 1.1966 | discard | depth 8→10 |
| 14 | 0.920 | BREAK | 1.1889 | discard | ASPECT_RATIO 64→80 |
| 15 | 1.000 | BREAK | 1.1609 | discard | batch size 2^19→2^18 |

## δ 动态分析

### "SIMPLIFY 陷阱"现象

δ 的演变轨迹暴露了一个有趣的动态：

1. **Iter 2**：δ=0.000 → GUARD（失败），推动 δ 上升
2. **Iter 3**：δ=0.600 → 直接跳入 SIMPLIFY 区间
3. **Iter 4**：δ=0.733 → BREAK（成功！SiLU 改善 2.1%）
4. **Iter 5-11**：δ 稳定在 0.4-0.64 → 持续 SIMPLIFY，全部失败
5. **Iter 12-15**：δ 突破 0.7 → BREAK，但 4 次全部失败

SIMPLIFY 策略占总迭代的 **60%**（9/15），但 **0% 成功率**。
这表明当修改池中 SIMPLIFY 类操作较弱时，框架会陷入 "SIMPLIFY 死循环"。

### 关键洞察

- 在 15 次 pilot 中，自适应机制**未激活**（需 50 迭代）
- 如果在 iter 10 触发自适应，系统可能会：
  - 将 θ_guard 上调（因 SIMPLIFY 成功率=0）
  - 将 θ_break 下调（因 BREAK 有 1/5 成功率）
  - 从而让更多迭代进入 GUARD 或 BREAK 区间

## 三组 Pilot 初步对比

| 指标 | Baseline | Static-CT | Adaptive-CT |
|------|----------|-----------|-------------|
| 起始 BPB | 1.2472 | 1.1955 | 1.1636 |
| 最终 BPB | 1.1306 | 1.1239 | 1.1392 |
| 改善率 | 9.4% | 6.0% | 2.1% |
| Keep 率 | 33.3% | 26.7% | 13.3% |
| 唯一突破修改 | batch size↓ | SiLU, MLP 6x | SiLU |

> **注意**: 起始 BPB 因随机种子差异不同。Adaptive-CT 表现最差
> 的主要原因是陷入了 SIMPLIFY 死循环，这恰恰说明 15 迭代 pilot
> 太短，自适应机制来不及纠偏。

## 保留文件

- `pilot_data/results_adaptive-ct_pilot-1.tsv`：完整结果数据
- Git 分支 `autoresearch/adaptive-ct-pilot-1`：保留 2 个 keep 的 commit

## 下一步

- [x] 三组 pilot 全部完成
- [ ] 运行 `analyze_pilot.py` 生成跨组对比报告
