# Baseline Pilot 完成报告

**时间**: 2026-04-04 20:26 – 21:52（约 85 分钟）
**分支**: `autoresearch/baseline-pilot-1`
**迭代数**: 15

## 关键指标

| 指标 | 值 |
|------|-----|
| 起始 val_bpb | 1.247235 |
| 最终 val_bpb | 1.130568 |
| 改善幅度 | **9.4%** |
| Keep / Discard | 5 / 10 |
| Keep 率 | 33.3% |

## 逐次迭代记录

| # | Commit | val_bpb | 状态 | 描述 |
|---|--------|---------|------|------|
| 1 | 84a5ec1 | 1.2472 | keep | baseline（初始运行） |
| 2 | a150b30 | 1.1707 | **keep** | MATRIX_LR 0.04→0.05 |
| 3 | e8a5c1e | 1.1531 | **keep** | 激活函数 ReLU² → SiLU |
| 4 | 1965134 | 1.1481 | **keep** | MLP expansion 4x→6x |
| 5 | d11bfd7 | 1.2008 | discard | depth 8→10 |
| 6 | 708ab24 | 1.1916 | discard | ASPECT_RATIO 64→80 |
| 7 | 188b168 | 1.1543 | discard | warmdown 0.5→0.3 |
| 8 | 9290a8e | 1.2511 | discard | HEAD_DIM 128→64 |
| 9 | 32dd350 | 1.1611 | discard | EMBEDDING_LR 0.6→0.8 |
| 10 | f5f5da1 | 1.1602 | discard | WINDOW_PATTERN SSSL→SL |
| 11 | 5654beb | 1.1597 | discard | WEIGHT_DECAY 0.2→0.1 |
| 12 | 57d3de2 | 1.1494 | discard | Adam beta1 0.8→0.9 |
| 13 | 33ab083 | 1.2893 | discard | warmup 0.0→0.05 |
| 14 | 410b176 | 1.1306 | **keep** | batch size 2^19→2^18 |
| 15 | 2cd73b0 | 1.2091 | discard | MATRIX_LR→0.06 |

## 行为特征

- **早期连续改善**：前 4 次迭代全部 keep，快速收益
- **中期停滞**：iter 5–13 连续 9 次 discard，难以突破 1.148
- **最终突破**：iter 14 通过降低 batch size 打破瓶颈，达到 1.131
- **无框架约束**：Baseline 的修改策略完全随机/直觉驱动，无 δ 指导

## 与 Static-CT 初步对比

| 指标 | Baseline | Static-CT |
|------|----------|-----------|
| 起始 BPB | 1.2472 | 1.1955 |
| 最终 BPB | 1.1306 | 1.1239 |
| 改善率 | 9.4% | 6.0% |
| Keep 率 | 33.3% | 26.7% |
| 最长连续 discard | 9 次 (iter 5-13) | 待确认 |

> **注意**：起始 BPB 不同（1.2472 vs 1.1955），可能因随机种子或初始 train.py 微差异。
> 绝对 BPB 对比需在分析阶段标准化。

## 保留文件

- `pilot_data/results_baseline_pilot-1.tsv`：完整结果数据
- Git 分支 `autoresearch/baseline-pilot-1`：保留 5 个 keep 的 commit

## 下一步

- [ ] 执行 Adaptive-CT pilot run
- [ ] 三组数据齐全后运行 `analyze_pilot.py`
