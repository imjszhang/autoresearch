# Pilot 预实验进展：Static-CT 组完成

> 日期：2026-04-04
> 项目：autoresearch / cyber-taoist
> 类型：实验执行
> 来源：Cursor Agent 对话

---

## 一、完成状态

Static-CT 组 Pilot 预实验 **15 次迭代已完成**，验证结果为 **CONDITIONAL PASS**（10 PASS / 1 WARN / 0 FAIL）。

Baseline 组和 Adaptive-CT 组尚未开始。

---

## 二、Static-CT Pilot 结果概览

### 迭代记录

| # | δ | 策略 | 修改 | val_bpb | 状态 |
|---|---|------|------|---------|------|
| 1 | 0.000 | BASELINE | 基线运行 | 1.195496 | keep |
| 2 | 0.200 | GUARD | MATRIX_LR 0.04→0.05 | 1.132377 | keep |
| 3 | 0.000 | GUARD | EMBEDDING_LR 0.6→0.8 | 1.166098 | discard |
| 4 | 0.267 | GUARD | DEPTH 8→10 | 1.835994 | discard |
| 5 | 0.400 | SIMPLIFY | WINDOW_PATTERN SSSL→SL | 1.143109 | discard |
| 6 | 0.480 | SIMPLIFY | WARMDOWN 0.5→0.3 | 1.230520 | discard |
| 7 | 0.533 | SIMPLIFY | WARMUP 0.0→0.1 | 1.728306 | discard |
| 8 | 0.771 | BREAK | ReLU²→SiLU | 1.125747 | **keep** |
| 9 | 0.662 | SIMPLIFY | VE gate 32→16 | 1.156423 | discard |
| 10 | 0.695 | SIMPLIFY | WEIGHT_DECAY 0.2→0.1 | 1.161931 | discard |
| 11 | 0.722 | BREAK | MLP 扩展 4x→6x | 1.123856 | **keep** |
| 12 | 0.724 | BREAK | BATCH_SIZE 2^19→2^20 | 1.344659 | discard |
| 13 | 0.804 | BREAK | ASPECT_RATIO 64→80 | 1.234428 | discard |
| 14 | 0.804 | BREAK | Adam β1 0.8→0.9 | 1.212695 | discard |
| 15 | 0.820 | BREAK | HEAD_DIM 128→64 | 1.249017 | discard |

### 关键数据

- **BPB 改进**: 1.195496 → 1.123856（降低 6.0%）
- **成功率**: 4/15 = 26.7%（含 baseline 的 keep）
- **策略分布**: GUARD 3 / SIMPLIFY 5 / BREAK 6 / BASELINE 1
- **策略成功率**: GUARD 33% / SIMPLIFY 0% / BREAK 33%
- **δ 轨迹**: 0.0 → 0.2 → 0.0 → 0.27 → 0.4 → 0.48 → 0.53 → **0.77** → 0.66 → 0.7 → **0.72** → 0.72 → 0.8 → 0.8 → 0.82

### 验证项通过情况

| 验证项 | 结果 | 备注 |
|--------|------|------|
| V1 δ 合规性 | **PASS (100%)** | 14/14 行有有效 δ 值 |
| V2 策略执行 | **PASS (100%)** | 14/14 行有有效策略标签 |
| V3 数据格式 | **PASS** | 8 列格式正确 |
| V4 δ→策略对齐 | **PASS (100%)** | 0 行不对齐 |
| V5 迭代耗时 | **受限** | git 只记录 keep 的 commit，估算不准确 |
| V6 上下文窗口 | **未验证** | 需要观察更长运行 |
| V7 训练正确性 | **PASS** | 0 crash，val_bpb 正常 |

---

## 三、实验过程中发现的问题

### 已修复

| 问题 | 影响 | 修复 |
|------|------|------|
| `GROUPS` 是 bash 保留变量 | pilot_init.sh 无法创建分支 | 改名为 `EXP_GROUPS` |
| `((count++))` 在 count=0 时返回退出码 1 | validate_pilot.sh 的 `set -e` 导致提前退出 | 改用 `count=$((count + 1))` |
| `git log | head -1` 触发 SIGPIPE | `set -o pipefail` 导致脚本失败 | 改用 `git log -1` |
| Git Bash 多层 shell 转义 | commit hash 变量在 WSL 内丢失 | 编写 `run_iter.sh` 辅助脚本 |

### 已知限制

- V5 时间估算：git rev-list 只计算 keep 的 commit（discard 被 reset 掉了），导致估算偏差
- Git Bash → WSL 的 `$()` 变量展开问题：需要通过脚本文件传递，不能在 `bash -c "..."` 中直接使用

---

## 四、关键观察

### δ 动态演化

δ 的轨迹清晰地展示了"守→简→破"的策略切换：
1. **冷启动期**（iter 1-3）：δ 低（0-0.27），策略为 GUARD
2. **停滞期**（iter 4-7）：连续 discard 导致 δ 上升到 0.4-0.53，策略切换到 SIMPLIFY
3. **突破期**（iter 8）：SIMPLIFY 无效，δ 达到 0.77，触发 BREAK，成功（SiLU）
4. **再停滞**（iter 9-10）：继续 discard，δ 回到 0.66-0.70
5. **再突破**（iter 11）：δ=0.72 触发 BREAK，又成功（MLP 6x）
6. **持续 BREAK**（iter 12-15）：δ 维持高位（0.72-0.82），但后续 BREAK 不再成功

这完美对应了 Cyber-Taoist 的五阶段进化循环理论。

### SIMPLIFY 策略的问题

5 次 SIMPLIFY 全部失败（0% 成功率）。可能原因：
- 当前 δ 处于上升趋势时，小改动（如调参）和简化都无法突破，只有真正的架构变更（BREAK）才有效
- SIMPLIFY 的定义（0.3 ≤ δ ≤ 0.7）可能过宽，导致该策略在"应该 BREAK"的区间被调用

这恰好是 Adaptive-CT 组要解决的问题——根据实验数据自适应调整阈值。

---

## 五、后续步骤

- [ ] 运行 Baseline Pilot（15 迭代）
- [ ] 运行 Adaptive-CT Pilot（15 迭代）
- [ ] 验证并生成跨组分析报告
- [ ] 根据 Pilot 结果决定是否直接进入正式实验
