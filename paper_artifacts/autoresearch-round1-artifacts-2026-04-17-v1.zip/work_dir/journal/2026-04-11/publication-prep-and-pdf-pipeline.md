# 论文发布准备与 PDF 生成流水线搭建

> 日期：2026-04-11
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：调研分析 / 功能实现
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

实验 Round 1 仍在进行中（static-ct-2 进行到 93/200，后续还有 5 个 run 待完成，全部 30 个 run 完成约 15%），但距离最终发布还有大量非实验性的准备工作。

目标是利用实验等待期间，把**不依赖实验数据的发布准备**全部推进到位，使得实验跑完后能快速收尾发布。

具体问题：
- 论文稿 `paper.md` 中的硬件信息写的是 H100，实际使用的是 RTX 5090 D
- 没有从 Markdown 到学术 PDF 的自动化流水线
- 作者信息、通讯邮箱未确定
- 补充材料（代码包、README）、传播物料（Reddit 帖子）未准备
- 收到的一份 Zenodo 发布攻略需要结合项目实际情况做校正

---

## 2. 分析过程

### 2.1 攻略评估

收到一份"以个人身份在 Zenodo 发布预印本"的 6 步攻略，逐条分析后发现：

**需要纠正的问题：**
- 理论名称全部写错（"Cyber-Taoisy" → 正确是 **Cyber-Taoist**）
- 建议的作者名不对——应使用 **JS Zhang**（个人品牌）
- "30 分钟完成"严重低估准备工作量

**攻略遗漏的关键项：**
- GitHub 代码仓库准备（可复现性的核心）
- Karpathy 的 autoresearch 作为实验平台的传播价值
- Reddit 发帖不只是传播，更是建立学术连接、寻找 arXiv endorser

**攻略中值得保留的：**
- CC BY 4.0 许可证选择
- Zenodo → ResearchGate → 社媒的发布顺序
- 补充材料一起上传

### 2.2 发布方案选择

| 方案 | 描述 | 评估 |
| ---- | ---- | ---- |
| A: 预注册发布 | 现在就发，标注为 pre-registration | 关注度低，AI 领域不常见 |
| B: 等实验完成 | 30 个 run 跑完后发完整论文 | **选定** —— 说服力最强 |
| C: 先发 v1 再迭代 | 现在发框架版，后续更新数据版 | 可行但不如 B 干净 |

最终选择**方案 B**：等实验跑完再发，但提前完成所有非数据依赖的准备工作。

### 2.3 PDF 工具链选型

| 工具 | 状态 | 评估 |
| ---- | ---- | ---- |
| Pandoc 3.9 | 已安装 ✅ | Markdown 转换引擎 |
| LaTeX (TinyTeX/MiKTeX) | 未安装 | 传统方案，安装重、依赖多 |
| Typst 0.14.2 | **已安装** ✅ | 轻量级（单二进制文件），原生数学公式支持，学术排版质量好 |
| WeasyPrint | 未安装 | CSS → PDF，排版不够学术 |

选择 **Pandoc + Typst** 组合：Pandoc 处理 Markdown 解析，Typst 作为 PDF 引擎输出排版。

### 2.4 作者信息确定

| 项目 | 决定 |
| ---- | ---- |
| 笔名 | JS Zhang |
| Affiliation | Independent Researcher |
| 通讯邮箱 | js.zhang.research@gmail.com |
| 选择 Zenodo 原因 | 作为独立研究者无法获得 arXiv endorsement |
| Reddit 策略 | 通过 r/MachineLearning 建立学术连接，寻找潜在 endorser |

---

## 3. 方案设计

### 三阶段发布准备计划

| 阶段 | 时机 | 内容 |
| ---- | ---- | ---- |
| A: 实验进行中（当前） | 现在 | 修正论文、搭 PDF 流水线、准备传播物料 |
| B: 实验完成后 | 30 个 run 跑完 | 替换实际结果、统计分析、生成图表、定稿 |
| C: 发布 | 定稿后 | Zenodo 上传 → ResearchGate → Reddit/X |

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 邮箱域名 | Gmail | 学术领域更常见，比 Outlook 更通用 |
| 邮箱命名 | js.zhang.research@ | 与笔名一致，含 research 表明用途 |
| PDF 引擎 | Typst（via winget） | 比 LaTeX 轻量 100 倍，排版质量相当 |
| 许可证 | CC BY 4.0 | 允许引用和改编，最大化传播 |
| Reddit 标签 | `[R]` (Research) | 表明是严肃研究，非 show-and-tell |

---

## 4. 实现要点

### 产出文件结构

```
work_dir/manuscript/
├── paper.md                   # 论文主稿（已修正硬件+作者）
├── paper.pdf                  # 自动生成的 PDF（501KB）
├── paper-meta.yaml            # Pandoc 元数据（标题/作者/日期）
├── academic-template.typ      # Typst 学术排版模板
├── build-pdf.sh               # 一键构建脚本
├── publication-prep.md        # 发布准备清单（三阶段）
├── supplementary-README.md    # 代码包 README 草稿
├── reddit-post-draft.md       # Reddit 帖子草稿
├── paper-design-notes.md      # 中文设计笔记（未改动）
└── paper-design-notes-v1.md   # 早期设计笔记（未改动）
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `paper.md` | 论文主稿，Sec 1-9 + Appendix A-C，英文，~630 行 |
| `paper-meta.yaml` | 驱动 PDF 标题页的元数据（作者、日期等） |
| `academic-template.typ` | 自定义 Typst 模板：Palatino Linotype 字体、章节编号、表格条纹、页眉、代码块样式 |
| `build-pdf.sh` | 构建脚本：去掉 paper.md 前 8 行手写标题块 → Pandoc + Typst → PDF |
| `publication-prep.md` | 三阶段检查清单，含 Zenodo 元数据预填模板 |
| `supplementary-README.md` | 代码包 README，含仓库结构、硬件环境、复现步骤、BibTeX 引用 |
| `reddit-post-draft.md` | r/MachineLearning 帖子草稿，`[R]` 标签，聚焦实验设计和可复现性 |

### paper.md 修正内容

1. **添加作者块**（第 3-5 行）：

   ```
   **JS Zhang**
   Independent Researcher
   Email: js.zhang.research@gmail.com
   ```

2. **修正硬件信息**（原 Sec 5.1）：

   H100 → RTX 5090 D (32 GB VRAM, Blackwell, SM 12.0)，并补充了三项硬件适配说明：
   - Flash Attention 3 → PyTorch SDPA
   - torch.compile 禁用
   - DEVICE_BATCH_SIZE 128 → 32（梯度累积补偿）

### PDF 流水线排障记录

| 问题 | 原因 | 解决 |
| ---- | ---- | ---- |
| 自定义模板输出仅 2.3KB | 模板未包含 `$body$` 变量 | 在模板末尾添加 Pandoc 变量绑定和 `$body$` |
| `unknown variable: horizontalrule` | Pandoc 将 `---` 转为 `#horizontalrule`，模板未定义 | 添加 `#let horizontalrule = line(...)` 定义 |
| Keywords 含空格导致 Typst 语法错误 | Pandoc Typst 模板的 keywords 处理 bug | 从 YAML 中移除 keywords，在正文中处理 |
| 字体 `serif`/`monospace` 警告 | Typst 不识别通用族名 | 仅保留具体字体名（Palatino Linotype、Consolas） |

---

## 5. 验证与测试

### PDF 构建验证

| 验证项 | 结果 |
| ------ | ---- |
| `bash build-pdf.sh` 执行成功 | ✅ exit code 0 |
| 输出文件 `paper.pdf` | ✅ 501,848 bytes |
| 无 Typst 编译错误 | ✅ |
| 无 Typst 编译警告 | ✅（修复字体警告后） |
| paper.md 作者信息正确 | ✅ JS Zhang, js.zhang.research@gmail.com |
| paper.md 硬件信息正确 | ✅ RTX 5090 D + 三项适配 |
| paper-meta.yaml 与 paper.md 一致 | ✅ |
| publication-prep.md 邮箱正确 | ✅ |

### 文件一致性

所有涉及作者信息的文件已统一更新：
- `paper.md`（正文头部）
- `paper-meta.yaml`（Pandoc 元数据）
- `publication-prep.md`（发布清单）
- `supplementary-README.md`（代码包 README）

---

## 6. 后续演化

### 实验完成后的工作（阶段 B）

1. 收集全部 30 个 run 的 `results_*.tsv`
2. 编写统计分析脚本（Kruskal-Wallis、Dunn 事后检验等）
3. 生成图表（学习曲线、决策边界图、参数漂移轨迹）
4. 将 paper.md Sec 8 从 "Expected Results" 替换为实际数据与分析
5. 更新 Abstract 中的"anticipate"等预期措辞为实证措辞
6. 全文校对后重新 `bash build-pdf.sh` 生成最终 PDF

### 发布后的工作（阶段 C）

1. 上传 Zenodo → 获取 DOI
2. 更新 `supplementary-README.md` 中的 DOI 占位符
3. 发布 Reddit r/MachineLearning 帖子（建议美东时间 Tue-Thu 上午）
4. 通过 Reddit 互动寻找 arXiv endorser
5. 根据社区反馈迭代论文 → Zenodo v2

### 待注册账号

- [ ] Gmail: js.zhang.research@gmail.com
- [ ] Zenodo 账号：使用常用个人邮箱 `ortle3x3@gmail.com` 注册
- [ ] 确认论文投稿邮箱与 Zenodo 邮箱可以不一致，但作者姓名、GitHub、ORCID（如有）等身份信息保持一致
- [ ] 在论文、Zenodo 记录、GitHub 仓库中统一作者展示名与联系说明，避免被看作两个独立身份

---
