# static-ct-2 卡死诊断与断点恢复

> 日期：2026-04-11
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查 / 升级迁移
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

在 `baseline-2` 正常完成、实验切换到 `static-ct-2` 之后，用户要求检查当前实验进度。初步只读核查时发现：

- `round_state.json` 中 `static-ct-2` 停在 **99 / 200**
- runner 进程仍然存活
- 实验没有继续向前推进

这类状态很危险，因为它不是“程序退出”，而是**看起来在运行、实际上已经不再产生有效迭代**。如果不先诊断直接恢复，很容易造成：

- 重复启动多个 runner；
- 覆盖当前断点；
- 错误回滚到较早状态；
- 或在不确定 `results.tsv` 是否完整的前提下继续实验。

因此，这次工作的目标是：

1. 判断 `static-ct-2` 是否真的卡死；
2. 确认当前断点是否干净；
3. 以最小风险恢复到 `static-ct-2` 的第 99 次迭代；
4. 继续 Round 1 后续实验。

---

## 2. 分析过程

### 2.1 第一轮只读检查：进度不动

最先读取到的 `round_state.json` 状态为：

| Run | 状态 | 迭代 |
|-----|------|------|
| `baseline-1` | completed | 200 |
| `static-ct-1` | completed | 203 |
| `adaptive-ct-1` | completed | 201 |
| `baseline-2` | completed | 200 |
| **`static-ct-2`** | **in_progress** | **99** |
| 其余 | pending | 0 |

仅从这个文件还无法判断是真卡死还是单轮训练较慢，因此继续检查 runner 终端快照与进程状态。

### 2.2 终端快照：反复空转

通过读取旧 runner 的终端快照，发现它已经进入一种“活着但不推进”的循环：

```text
[backup] results.tsv backed up (99 rows)
[agent] stopReason=end_turn | +0 iterations (total: 99/200)
[warn] No new iterations. Waiting 30s before retry...

--- Session 61 | Iterations: 99/200 | ...
...
--- Session 62 | Iterations: 99/200 | ...
...
--- Session 63 | Iterations: 99/200 | ...
```

连续多个 session 都是：

- `Iterations: 99/200`
- `+0 iterations`
- 然后重试下一次 session

这已经不是“实验慢”，而是**runner 在自旋重试**。

### 2.3 错误模式：`WinError 10038` 与 `Connection stalled`

日志中出现了两类典型错误：

1. `static-ct-2.log` 末尾反复出现：
   - `Error: S: Connection stalled`
2. 终端快照中出现：
   - `OSError: [WinError 10038]`

这两者都集中指向同一类问题：**`cursor_acp.py` 的 ACP / MCP 通信链路异常断开**。

更具体地说，runner 还在外层循环里运行，但内部 agent session 已经无法正常收尾并产生新一轮实验结果，导致：

- `cursor_acp.run_prompt()` 快速返回；
- `get_iter_count()` 一直读到同一个值 `99`；
- `backup_results()` 一直覆盖同一个断点；
- runner 误以为只是“这轮没有新迭代”，于是继续重试。

### 2.4 断点数据是否干净

在真正执行恢复前，对 `static-ct-2` 做了完整只读核查：

| 核查项 | 结果 |
|--------|------|
| 当前分支 | `autoresearch/static-ct-2` |
| `results.tsv` 总行数 | 100（1 header + 99 data） |
| `experiment_data/results_static-ct-2.tsv` | 存在，且也是 100 行 |
| 当前最佳 commit | `c675fe7` |
| 当前最佳 BPB | `1.077644` |
| `round_state.json` | `static-ct-2: in_progress, iterations: 99` |

最近 3 条结果为：

| commit | val_bpb | 结论 |
|--------|---------|------|
| `e5cc5dd` | 1.079293 | discard |
| `3be1ae3` | 1.080035 | discard |
| `4c5827f` | 1.079042 | discard |

而 `static-ct-2.log` 的最后有效摘要明确写着：

- **当前最佳：`c675fe7`，val_bpb = 1.077644**
- **仓库 HEAD：已 `git reset --hard c675fe7`**

这说明断点是**干净的**：

- `results.tsv` 已写完；
- backup 已同步；
- HEAD 已回到最佳提交；
- 卡死发生在“下一轮 session 启动阶段”，不是在写结果中途。

---

## 3. 方案设计

既然确认 `static-ct-2` 的 99 次迭代断点是干净的，就不需要复杂的数据修复。恢复方案应遵循“最少动作”原则：

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 是否保留旧 runner | 否，直接终止 | 旧进程已进入无效自旋，不会自行恢复 |
| 是否回滚 `results.tsv` | 否 | 当前 99 次数据完整，回滚会丢失有效实验记录 |
| 是否修改 `round_state.json` | 否 | 它与 `results.tsv` 和 backup 一致 |
| 是否重置 HEAD | 是，显式对齐 `c675fe7` | 确保从最佳提交而非不确定工作树状态继续 |
| 恢复粒度 | 从 `static-ct-2` 第 99 次迭代继续 | 保持断点最小损失 |

---

## 4. 实现要点

### 项目结构

```text
work_dir/
├── experiment/
│   ├── logs/
│   │   ├── round_state.json
│   │   └── static-ct-2.log
│   ├── run_experiment.py
│   └── cursor_acp.py
└── journal/
    └── 2026-04-11/
        ├── pause-misalignment-and-static-ct-2-recovery.md
        └── static-ct-2-stall-diagnosis-and-recovery.md
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/experiment/logs/round_state.json` | Round 1 的断点状态 |
| `work_dir/experiment/logs/static-ct-2.log` | `static-ct-2` 会话日志与卡死前最后摘要 |
| `results.tsv` | 当前 run 的核心实验结果表 |
| `experiment_data/results_static-ct-2.tsv` | 当前 run 的备份快照 |
| `run_experiment.py` | 恢复 Round 1 的主入口 |

### 实际执行动作

1. **停止旧 runner**

   终止卡死的 `python.exe`（`run_experiment.py round1`）：

   ```bash
   taskkill /F /PID 20352
   ```

2. **核对 `static-ct-2` 断点**

   确认：

   - `results.tsv` 共 99 条实验记录；
   - backup 与当前文件一致；
   - 最佳提交为 `c675fe7`；
   - 当前最佳 BPB 为 `1.077644`。

3. **重新对齐工作树**

   在 WSL 中显式切到：

   - 分支：`autoresearch/static-ct-2`
   - HEAD：`c675fe7`

   并重新同步一次备份：

   ```bash
   cp results.tsv experiment_data/results_static-ct-2.tsv
   ```

4. **清理暂停标记**

   删除可能残留的 `PAUSE_REQUEST`，避免刚恢复就被立即暂停。

5. **重启 Round 1**

   ```bash
   python run_experiment.py round1
   ```

   runner 自动跳过已完成的：

   - `baseline-1`
   - `static-ct-1`
   - `adaptive-ct-1`
   - `baseline-2`

   然后从：

   - `static-ct-2`
   - `Iterations: 99/200`

   继续。

---

## 5. 验证与测试

### 恢复前验证

| 验证项 | 结果 |
|--------|------|
| 旧 runner 进程是否存在 | 是 |
| 旧 runner 是否在推进 | 否，连续 `+0 iterations` |
| `results.tsv` 是否完整 | 是 |
| backup 是否存在且同步 | 是 |
| 最佳 commit 是否可确定 | 是，`c675fe7` |

### 恢复后验证

新 runner 启动后的终端输出：

```text
[round1] Remaining: 5 runs — static-ct-2, adaptive-ct-2, baseline-3, static-ct-3, adaptive-ct-3
[skip] baseline-1 already completed (200 iters)
[skip] static-ct-1 already completed (203 iters)
[skip] adaptive-ct-1 already completed (201 iters)
[skip] baseline-2 already completed (200 iters)

Experiment: static-ct-2
[setup] On branch: autoresearch/static-ct-2
--- Session 1 | Iterations: 99/200 | ...
[agent] Sending prompt to Cursor Agent...
[cursor_acp] handshake ok
```

这说明：

- 恢复点正确；
- 前四个 run 被正确跳过；
- `static-ct-2` 成功从 99 迭代继续；
- ACP 会话已重新建立。

### 当前结论

| 项目 | 状态 |
|------|------|
| `static-ct-2` 断点 | 已修复 |
| `results.tsv` / backup | 一致 |
| 工作树 | 已对齐 `c675fe7` |
| 新 runner | 已成功启动 |

---

## 6. 后续演化

### 这次问题的性质

这次不是“结果文件损坏”，也不是“实验代码逻辑错误”，而是：

- **ACP / MCP 通信链路局部失效**
- 导致外层 runner 进入“空转重试”模式

也就是说，当前恢复策略正确的关键是：

- **不要回滚有效数据**
- **只替换失效的调度进程**

### 后续可改进的点

1. **识别“连续 N 次 `+0 iterations`”作为硬故障**
   - 目前 runner 只会 `warn` 然后继续重试；
   - 未来可增加阈值，比如连续 3~5 次 `+0` 就自动退出并标记需要人工恢复。

2. **把 `WinError 10038` / `Connection stalled` 提升为恢复信号**
   - 现在这些错误散落在日志里，但不会触发 runner 自动中止；
   - 可以考虑让它们进入“自动停止并保存断点”的分支。

3. **在每轮恢复时自动记录诊断上下文**
   - 如断点迭代数、最佳 commit、最后 3 条结果、最近异常摘要等；
   - 这样以后恢复可以更快完成。

---

