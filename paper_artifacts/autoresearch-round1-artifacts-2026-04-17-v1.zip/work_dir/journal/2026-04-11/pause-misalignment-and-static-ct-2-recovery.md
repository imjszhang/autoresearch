# 暂停错位后的断点校正与 static-ct-2 恢复

> 日期：2026-04-11
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查 / 升级迁移
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

在 Round 1 长时间运行过程中，用户希望“安全暂停实验，日后断点续传”。原本目标是让 runner 在 `baseline-2` 的某个安全边界停下，保留完整断点，再在之后继续 `static-ct-2`。

实际发生的情况比预期复杂：

- 当时观察到的中间进度是 `baseline-2` **196/200**；
- 为了避免直接强杀导致半条结果或未备份状态，选择继续等待 session 边界；
- 在等待窗口中，`baseline-2` 继续推进到 **200/200** 并自然完成；
- runner 自动切入 **`static-ct-2` 初始化阶段**；
- 之后才将进程停下。

因此，这次暂停并不是“恰好停在 `baseline-2` 结束前”，而是停在了：

1. `baseline-2` 已完成；
2. `static-ct-2` 已在状态文件中标记为 `in_progress`；
3. 但 `static-ct-2` 尚未真正产生任何实验迭代。

这带来了一个新的问题：需要把当前状态**安全校正为 `static-ct-2` 的可续跑断点**，而不是简单地重新启动实验。

---

## 2. 分析过程

### 2.1 为什么会出现“196 之后又跑完”

暂停时最初读取到的 `round_state.json` 确实只显示：

- `baseline-2: in_progress`
- `iterations: 196`

但这是**中途快照**，不是最终停止时刻的状态。后续继续等待 session 自然结束时，runner 终端输出显示：

```text
--- Session 73 | Iterations: 196/200 | ...
[backup] results.tsv backed up (200 rows)
[agent] stopReason=end_turn | +4 iterations (total: 200/200)

--- Session 74 | Iterations: 200/200 | ...
[done] Target reached!
[complete] baseline-2: 200 iterations, best BPB: N/A
~~~ Completed baseline-2 ...
```

也就是说：

- `196` 是**观察点**；
- runner 在被真正停下前，又完整跑完了 **最后 4 次迭代**；
- 所以 `baseline-2` 最终是 **正常完成**，不是中途被截断。

### 2.2 对 `baseline-2` 数据完整性的核查

恢复前对 `baseline-2` 做了只读核查：

| 核查项 | 结果 |
|--------|------|
| `round_state.json` | `baseline-2: completed, 200` |
| `experiment_data/results_baseline-2.tsv` | **201 行**（1 header + 200 实验记录） |
| `baseline-2.log` | 存在完整长日志，末尾仍能看到后期实验摘要 |
| TSV 末尾几行 | 列数正常、格式完整、无损坏迹象 |

因此可以确认：**`baseline-2` 已正常完成，且数据文件完整。**

### 2.3 真正的问题：交接状态错位

虽然 `baseline-2` 本身没问题，但 runner 停下后出现了一个“状态前移、工作树未完全对齐”的断点：

| 项目 | 状态 |
|------|------|
| `round_state.json` | `static-ct-2: in_progress, iterations: 0` |
| `static-ct-2.log` | 空文件 |
| WSL 当前 `results.tsv` | 只有表头 1 行 |
| `experiment_data/results_static-ct-2.tsv` | 不存在（初始时） |

这说明：

- Round 状态机已经推进到 `static-ct-2`；
- 但 `static-ct-2` 尚未开始任何有效实验；
- 当前最合理的恢复目标不是“回退到 baseline-2”，而是把断点整理成一个**干净的 static-ct-2 起点**。

### 2.4 当前工作树状态讨论

恢复前的核查还发现一处容易混淆的信息：

- WSL 命令输出里 `CURRENT_BRANCH=githubforker`
- 但 `git branch --list` 中 `* autoresearch/static-ct-2`

这反映的是命令替换与输出拼接带来的显示混乱，不影响最终判断。后续真正续跑时，`run_experiment.py` 明确输出：

- `[setup] Switching to autoresearch/static-ct-2...`
- `[setup] On branch: autoresearch/static-ct-2`

说明 runner 已成功把工作树重新对齐到目标分支。

---

## 3. 方案设计

本次恢复目标不是“回滚到更早状态”，而是把当前实验整理成一个**逻辑一致、文件一致、可继续运行的 `static-ct-2` 起点**。

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 是否回滚 `baseline-2` | 不回滚 | 已完成 200 次，备份完整，回滚只会破坏已确认的数据 |
| 是否把 `static-ct-2` 记为未开始 | 保持 `in_progress, iterations=0` | 这与“已切入该 run 但还未产生实验记录”的真实状态一致 |
| 是否创建 `static-ct-2` 备份 | 是 | 即便只有表头，也作为“干净起点快照”保存 |
| 是否直接重启整个 Round 1 | 是 | 让 runner 按既有状态机自然跳过前面四个 run，继续 `static-ct-2` |

---

## 4. 实现要点

### 项目结构

```text
work_dir/
├── experiment/
│   ├── logs/
│   │   ├── round_state.json
│   │   ├── baseline-2.log
│   │   └── static-ct-2.log
│   ├── run_experiment.py
│   └── ...
└── journal/
    └── 2026-04-11/
        └── pause-misalignment-and-static-ct-2-recovery.md
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/experiment/logs/round_state.json` | Round 1 的状态机断点 |
| `work_dir/experiment/logs/baseline-2.log` | `baseline-2` 全部实验日志 |
| `work_dir/experiment/logs/static-ct-2.log` | `static-ct-2` 当前日志（恢复前为空） |
| `experiment_data/results_baseline-2.tsv` | `baseline-2` 的最终备份 |
| `experiment_data/results_static-ct-2.tsv` | 恢复时新建的 `static-ct-2` 起点快照 |
| `run_experiment.py` | 基于 `round_state.json` 继续调度实验 |

### 实际执行动作

1. **确认没有残留实验进程**
   - 检查 `python.exe`，确认没有旧的 `run_experiment.py` 还在运行。

2. **确认 `static-ct-2` 尚未产生任何有效实验**
   - `static-ct-2.log` 为空；
   - `results.tsv` 只有表头；
   - `iterations = 0`。

3. **为 `static-ct-2` 创建干净起点备份**
   - 在 WSL 中执行：
     ```bash
     mkdir -p experiment_data
     cp results.tsv experiment_data/results_static-ct-2.tsv
     ```
   - 结果是 `results_static-ct-2.tsv` 只有 **1 行表头**，作为未来恢复的标准起点。

4. **清理可能残留的暂停请求**
   - 删除 `logs/PAUSE_REQUEST`，避免刚恢复就被新的 runner 立刻停住。

5. **重新启动 Round 1**
   - 执行：
     ```bash
     python run_experiment.py round1
     ```
   - runner 自动跳过：
     - `baseline-1`
     - `static-ct-1`
     - `adaptive-ct-1`
     - `baseline-2`
   - 并从 `static-ct-2` 的 **Session 1 / Iterations 0/200** 开始继续。

---

## 5. 验证与测试

### 恢复前验证

| 验证项 | 结果 |
|--------|------|
| `baseline-2` 备份文件存在 | 是 |
| `baseline-2` 行数正确（201 行） | 是 |
| `static-ct-2.log` 为空 | 是 |
| `static-ct-2` 当前无备份 | 是（恢复前） |
| 当前无残留 `python.exe` 实验进程 | 是 |

### 恢复后验证

新 runner 启动后，终端日志显示：

```text
[state] Resumed from .../round_state.json
[round1] Remaining: 5 runs — static-ct-2, adaptive-ct-2, baseline-3, static-ct-3, adaptive-ct-3
[skip] baseline-1 already completed (200 iters)
[skip] static-ct-1 already completed (203 iters)
[skip] adaptive-ct-1 already completed (201 iters)
[skip] baseline-2 already completed (200 iters)

Experiment: static-ct-2
[setup] Switching to autoresearch/static-ct-2...
[setup] Restored results.tsv for static-ct-2
[setup] On branch: autoresearch/static-ct-2
--- Session 1 | Iterations: 0/200 | ...
```

这说明：

- runner 已正确识别并跳过前四个已完成 run；
- `static-ct-2` 作为当前断点被正确恢复；
- 当前确实从一个**干净的 0/200 起点**重新开始。

### 最终状态

| Run | 状态 |
|-----|------|
| `baseline-1` | completed |
| `static-ct-1` | completed |
| `adaptive-ct-1` | completed |
| `baseline-2` | completed |
| `static-ct-2` | in_progress（已恢复运行） |
| 其余 | pending |

---

## 6. 后续演化

### 这次讨论得到的经验

1. **“安全暂停”不等于“立即停”**  
   如果选择等待 session 边界，就必须接受实验在等待窗口内继续推进。像这次一样，从 196 到 200 的最后几轮可能会在等待时被自然跑完。

2. **断点恢复要区分“数据问题”和“交接问题”**  
   这次不是 `baseline-2` 数据坏了，而是 `baseline-2 → static-ct-2` 的切换停在了一个半完成状态。

3. **起点备份非常有价值**  
   即使 `results.tsv` 只有表头，把它备份成 `results_static-ct-2.tsv` 也能让未来恢复逻辑更简单、更清晰。

### 后续建议

- 若未来还需要“尽量停在某个 run 结束前”，可以在观察到 `iterations` 接近目标值时，提前通过 `PAUSE_REQUEST` 请求停机，而不是再等待多个 session；
- 当前的暂停逻辑已经支持“下一个 session 边界停止”，但**不能保证精确停在某个具体迭代数**；
- 可以考虑进一步在 `run_single()` 中加入“当某 run 达到 `max_iter - N` 时自动缩短 session 尺寸”的机制，让接近收尾时更容易精确暂停。

---

