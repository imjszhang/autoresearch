# adaptive-ct-3 意外中断诊断与断点恢复

> 日期：2026-04-15
> 项目：autoresearch / cyber-taoist 论文实验
> 类型：问题排查 / 升级迁移
> 来源：Cursor Agent 对话

---

## 目录

1. [背景与动机](#1-背景与动机)
2. [分析过程](#2-分析过程)
3. [方案设计](#3-方案设计)
4. [实现要点](#4-实现要点)
5. [验证与测试](#5-验证与测试)
6. [后续演化](#6-后续演化)

---

## 1. 背景与动机

Round 1 已接近尾声，前 8 个 run 都已完成：

| Run | 状态 | 迭代 |
|-----|------|------|
| `baseline-1` | completed | 200 |
| `static-ct-1` | completed | 203 |
| `adaptive-ct-1` | completed | 201 |
| `baseline-2` | completed | 200 |
| `static-ct-2` | completed | 202 |
| `adaptive-ct-2` | completed | 203 |
| `baseline-3` | completed | 201 |
| `static-ct-3` | completed | 202 |

仅剩最后一个 run：`adaptive-ct-3`。

但在查看当前实验进度时，发现 `adaptive-ct-3` 处于一种异常状态：

- `round_state.json` 显示其仍为 `in_progress`
- 迭代数停在 **40**
- 没有任何 `python.exe` runner 还在运行
- WSL 工作树处于不一致状态，根目录显示的是与实验无关的分支内容

这表明实验不是“慢”，而是已经**意外中断**。本次工作的目标是：

1. 判断中断位置与数据是否完整；
2. 确认 `adaptive-ct-3` 的真实断点；
3. 将工作树安全修正到可续跑状态；
4. 从第 40 次迭代继续实验。

---

## 2. 分析过程

### 2.1 初始现象：状态还在，但进程没了

最先读取到的 `round_state.json` 内容显示：

| 字段 | 值 |
|------|------|
| `adaptive-ct-3.status` | `in_progress` |
| `adaptive-ct-3.iterations` | `40` |

与此同时，系统进程检查结果为：

- 没有运行中的 `python.exe` runner

这说明：

- 状态文件没有收尾；
- 但负责跑实验的外层调度进程已经退出；
- 属于“断点还在，执行器没了”的典型中断。

### 2.2 误导性现象：WSL 根目录看起来像 `githubforker`

最初直接读取 WSL 根目录时，看到的是：

- `BRANCH=githubforker`
- `results.tsv` 有 41 行

这与 `round_state.json` 中“当前应在 `adaptive-ct-3`”看起来不一致。继续分析后确认，这个现象不能直接说明实验分支丢失，原因是：

- 根目录工作树可能停在与实验无关的默认分支；
- 真正的实验断点信息应该结合 `adaptive-ct-3.log`、`results.tsv`、backup 以及目标分支来判断；
- 不能因为根目录看起来不对，就贸然回滚 `results.tsv` 或重置到错误分支。

### 2.3 从 `adaptive-ct-3.log` 反推真实断点

读取 `work_dir/experiment/logs/adaptive-ct-3.log` 末尾后，可以确认：

- 当前是在 **第 40 轮附近**中断；
- 最近完成的 4 次实验分别是：

| commit | 改动 | val_bpb | 结论 |
|--------|------|---------|------|
| `0fcba72` | `WARMDOWN_RATIO 0.5→0.45` | 1.158458 | discard |
| `5676ee3` | `ROPE_BASE=10500` | 1.160455 | discard |
| `6f2c0a0` | `ADAM_BETAS beta1 0.8→0.85` | 1.163981 | discard |
| `a2eb19c` | `x0_lambdas` 初始值 0.1→0.12 | 1.205632 | discard |

日志还给出两个关键信息：

1. **历史最佳**是：
   - commit：`8625c38`
   - `val_bpb = 1.131210`
2. **当前工作树已按协议 reset 到**：
   - `HEAD = a92b9d3`

这非常重要。它说明在中断前：

- 最新 4 条 discard 已成功写入 `results.tsv`
- 工作树已经从这些 discard commit 回退到了 `a92b9d3`
- 中断发生在“下一轮准备阶段”，不是写结果中途

### 2.4 核对 `results.tsv` 与 backup

进一步精确检查 `adaptive-ct-3`：

| 检查项 | 结果 |
|--------|------|
| `results.tsv` 总行数 | 41（1 header + 40 data） |
| `experiment_data/results_adaptive-ct-3.tsv` | 存在，且也是 41 行 |
| 最后 3 行 | 与日志末尾 discard 记录一致 |
| 最佳 keep | `8625c38`, `1.131210` |
| 当前 HEAD | `a92b9d3` |
| 当前分支 | `autoresearch/adaptive-ct-3`（复位后确认） |

这说明：

- `results.tsv` 没有半行、缺列、重复尾写等损坏；
- backup 和当前文件同步；
- 当前断点是一个**干净断点**，并非坏断点。

---

## 3. 方案设计

既然确认 `adaptive-ct-3` 的 40 次迭代数据已完整写入，而且工作树原本就应该在 `a92b9d3`，恢复策略就可以很直接：

### 关键决策

| 决策 | 选择 | 理由 |
| ---- | ---- | ---- |
| 是否回滚 `results.tsv` | 否 | 40 次实验已完整写入，回滚会丢失有效记录 |
| 是否把 HEAD 对齐到最佳 `8625c38` | 否 | 日志明确说明协议上已 reset 到 `a92b9d3`，应该延续中断时的真实状态 |
| 是否更新 `round_state.json` | 否 | `adaptive-ct-3 = 40` 与当前 `results.tsv` 一致 |
| 恢复粒度 | 从 `adaptive-ct-3` 第 40 次迭代继续 | 与已有断点完全一致，风险最小 |

---

## 4. 实现要点

### 项目结构

```text
work_dir/
├── experiment/
│   ├── logs/
│   │   ├── round_state.json
│   │   └── adaptive-ct-3.log
│   ├── run_experiment.py
│   └── ...
└── journal/
    └── 2026-04-15/
        └── adaptive-ct-3-interruption-and-recovery.md
```

### 关键模块

| 文件 | 职责 |
| ---- | ---- |
| `work_dir/experiment/logs/round_state.json` | 记录 Round 1 当前断点 |
| `work_dir/experiment/logs/adaptive-ct-3.log` | 记录 `adaptive-ct-3` 最近的有效实验与中断前上下文 |
| `results.tsv` | 当前 run 的核心实验结果表 |
| `experiment_data/results_adaptive-ct-3.tsv` | 当前 run 的备份快照 |
| `run_experiment.py` | 负责恢复并继续剩余 run |

### 实际执行动作

1. **确认没有残留 runner**
   - 检查 `python.exe`，确认没有旧的 `run_experiment.py` 还在运行。

2. **核对断点一致性**
   - `round_state.json`：`adaptive-ct-3 = 40`
   - `results.tsv`：40 条数据
   - backup：40 条数据
   - `adaptive-ct-3.log`：最后 4 条实验已完整记录

3. **对齐工作树**
   - 显式切回 `autoresearch/adaptive-ct-3`
   - 显式 `git reset --hard a92b9d3`
   - 重新同步一次：
     ```bash
     cp results.tsv experiment_data/results_adaptive-ct-3.tsv
     ```
   - 清理可能残留的 `PAUSE_REQUEST`

4. **重启 Round 1**
   - 执行：
     ```bash
     python run_experiment.py round1
     ```
   - runner 自动跳过前 8 个已完成 run，仅继续最后一个：
     - `adaptive-ct-3`
     - `Iterations: 40/200`

---

## 5. 验证与测试

### 恢复前验证

| 验证项 | 结果 |
|--------|------|
| 旧 runner 是否存在 | 否 |
| `round_state.json` 是否与 TSV 对齐 | 是 |
| backup 是否存在 | 是 |
| 当前 run 是否有半写结果 | 否 |
| 当前工作树目标提交是否明确 | 是，`a92b9d3` |

### 恢复后验证

新 runner 启动后，终端输出显示：

```text
[round1] Remaining: 1 runs — adaptive-ct-3
[skip] baseline-1 already completed (200 iters)
[skip] static-ct-1 already completed (203 iters)
[skip] adaptive-ct-1 already completed (201 iters)
[skip] baseline-2 already completed (200 iters)
[skip] static-ct-2 already completed (202 iters)
[skip] adaptive-ct-2 already completed (203 iters)
[skip] baseline-3 already completed (201 iters)
[skip] static-ct-3 already completed (202 iters)

Experiment: adaptive-ct-3
[setup] On branch: autoresearch/adaptive-ct-3
--- Session 1 | Iterations: 40/200 | ...
[cursor_acp] handshake ok
```

这说明：

- 只剩最后一个 run；
- `adaptive-ct-3` 成功从第 40 次迭代接上；
- ACP / MCP 链路已经重新建立；
- 实验已经重新开始推进。

### 当前状态总结

| 项目 | 状态 |
|------|------|
| Round 1 完成情况 | 前 8/9 个 run 已完成 |
| 当前 run | `adaptive-ct-3` |
| 恢复断点 | `40/200` |
| 当前最佳 | `8625c38 / 1.131210` |
| 当前工作树 | `a92b9d3` |

---

## 6. 后续演化

### 这次中断的特点

这次不是“坏断点”，而是典型的：

- 外层 runner 没在运行；
- 状态文件和实验结果都还完整；
- 只需要把执行器重新接回断点。

因此，这类恢复的关键不是“修数据”，而是：

1. **先确认断点干净**
2. **再恢复执行链路**

### 后续建议

1. **最后一个 run 也应继续沿用“先读断点，再恢复”的流程**
   - 不要根据根目录一眼看到的分支名就判断断点；
   - 仍应优先参考 `round_state.json + run log + results.tsv + backup`。

2. **当 round 已接近尾声时，更适合增加更频繁的断点观察**
   - 因为最后一个 run 一旦成功完成，就能直接收口整个 Round 1。

3. **可以考虑在下一次收尾时补一篇 Round 1 总结**
   - 统一比较 9 个 run 的最优 BPB、keep/crash 率、策略收益与恢复稳定性。

---

